/* include/config.h.  Generated from config.h.in by configure.  */
#ifndef NDO_CONFIG_H
#define NDO_CONFIG_H


/* #undef DEBUG */


#endif
