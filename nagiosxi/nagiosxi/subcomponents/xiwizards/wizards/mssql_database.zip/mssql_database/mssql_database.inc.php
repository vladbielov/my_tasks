<?php
//
// MSSQL Database Config Wizard
// Copyright (c) 2010-2020 Nagios Enterprises, LLC. All rights reserved.
//

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

mssqldatabase_configwizard_init();

// NOTE: This wizard now uses the check_mssql_server.php plugin (under the covers).
function mssqldatabase_configwizard_init()
{
    $name = "mssql_database";
    $args = array(
        CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "2.0.0",
        CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
        CONFIGWIZARD_DESCRIPTION => _("Monitor a MSSQL Database"),
        CONFIGWIZARD_DISPLAYTITLE => _("MSSQL Database"),
        CONFIGWIZARD_FUNCTION => "mssqldatabase_configwizard_func",
        CONFIGWIZARD_PREVIEWIMAGE => "mssqldatabase.png",
        CONFIGWIZARD_FILTER_GROUPS => array('windows','database'),
        CONFIGWIZARD_REQUIRES_VERSION => 500
    );
    register_configwizard($name, $args);
}


/**
 * @param string $mode
 * @param null   $inargs
 * @param        $outargs
 * @param        $result
 *
 * @return string
 */
function mssqldatabase_configwizard_func($mode = "", $inargs = null, &$outargs, &$result)
{
    $wizard_name = "mssql_database";

    // Initialize return code and output
    $result = 0;
    $output = "";

    // Initialize output args - pass back the same data we got
    $outargs[CONFIGWIZARD_PASSBACK_DATA] = $inargs;

    switch ($mode) {
        case CONFIGWIZARD_MODE_GETSTAGE1HTML:

            $address = grab_array_var($inargs, "ip_address", "");
            $port = grab_array_var($inargs, "port", "1433");
            $instance = grab_array_var($inargs, "instance", "");
            $version = grab_array_var($inargs, "version", "");
            $username = grab_array_var($inargs, "username", "");
            $password = grab_array_var($inargs, "password", "");
            $instancename = grab_array_var($inargs, "instancename", "master");

            $output = '
<h5 class="ul">'._('MSSQL Database').'</h5>
<p>'._('Specify the details for connecting to the MSSQL Database you want to monitor').'.</p>
<table class="table table-condensed table-no-border table-auto-width">
    <tr>
        <td class="vt">
            <label>'._('Address').':</label><br class="nobr" />
        </td>
        <td>
            <input type="text" size="40" name="ip_address" id="ip_address" value="'.encode_form_val($address).'" class="textfield form-control">
            <div class="subtext">'._('The IP address or FQDNS name of the MSSQL server').'.</div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>'._('Instance').':</label>
        </td>
        <td>
            <input type="text" size="40" name="instance" id="instance" value="'.encode_form_val($instance).'" class="textfield form-control">
            <div class="subtext">'._('The Instance Name to connect to MSSQL Server').'.</div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>'._('Port').':</label>
        </td>
        <td>
            <input type="text" size="5" name="port" id="port" value="'.encode_form_val($port).'" class="textfield form-control">
            <div class="subtext">'._('The port to use to connect to MSSQL server. Default is 1433.  NOTE: Delete this entry if you provided an Instance Name.').'.</div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>'._('Version').':</label>
        </td>
        <td>
            <select name="version" id="version" class="form-control">
                <option value="PDW" '.is_selected($version, "PDW").'>'._('Parallel Data Warehouse').'</option>
                <option value="AZURE" '.is_selected($version, "AZURE").'>'._('Azure Synapse Analytics (SQL DW)').'</option>
                <option value="2019-RC" '.is_selected($version, "2019-RC").'>'._('2019 RC (Seattle)').'</option>
                <option value="2017" '.is_selected($version, "2017").'>'._('2017 (Helsinki)').'</option>
                <option value="2016" '.is_selected($version, "2016").'>'._('2016 (SQL16)').'</option>
                <option value="2014" '.is_selected($version, "2014").'>'._('2014 (SQL14)').'</option>
                <option value="2012" '.is_selected($version, "2012").'>'._('2012 (Denali)').'</option>
                <option value="2008-R2" '.is_selected($version, "2008-R2").'>'._('2008 R2 (Kilimanjaro)').'</option>
                <option value="2008" '.is_selected($version, "2008").'>'._('2008 (Katmai)').'</option>
                <option value="2005" '.is_selected($version, "2005").'>'._('2005 (Yukon)').'</option>
                <option value="2000-64" '.is_selected($version, "2000-64").'>'._('2000 64-bit (Liberty)').'</option>
                <option value="2000" '.is_selected($version, "2000").'>'._('2000 (Shiloh)').'</option>
                <option value="other" '.is_selected($version, "other").'>'._('Other').'</option>
            </select>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>'._('Username').':</label>
        </td>
        <td>
            <input type="text" size="20" name="username" id="username" value="'.encode_form_val($username).'" class="textfield form-control">
            <div class="subtext">'._('The username used to connect to the MSSQL server').'.</div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>'._('Password').':</label>
        </td>
        <td>
            <input type="password" size="20" name="password" id="password" value="'.encode_form_val($password).'" class="textfield form-control">
            <div class="subtext">'._('The password used to connect to the MSSQL server').'.</div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>'._('Database').':</label>
        </td>
        <td>
            <input type="text" size="20" name="instancename" id="instancename" value="'.encode_form_val($instancename).'" class="textfield form-control">
            <div class="subtext">'._('Get performance data for this database (instance_name)').'.</div>
        </td>
    </tr>
</table>';
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:

            // Get variables that were passed to us
            $address = grab_array_var($inargs, "ip_address", "");
            $instance = grab_array_var($inargs, "instance", "");
            $port = grab_array_var($inargs, "port", "");
            $version = grab_array_var($inargs, "version", "");
            $username = grab_array_var($inargs, "username", "");
            $password = grab_array_var($inargs, "password", "");
            $instancename = grab_array_var($inargs, "instancename", "");

            $address = nagiosccm_replace_user_macros($address);
            $port = nagiosccm_replace_user_macros($port);
            $username = nagiosccm_replace_user_macros($username);
            $password = nagiosccm_replace_user_macros($password);

            $use_2008_deprecated_stats = false;     # Tests that are deprecated (not available) after 2008
            $use_2008_plus_stats = true;            # Tests available in 2008 and newer.
            
            // Check for errors
            $errors = 0;
            $errmsg = array();

            if (have_value($address) == false)
                $errmsg[$errors++] = _("No address specified.");
            if (have_value($version) == false)
                $errmsg[$errors++] = _("No version specified.");
            if (have_value($port) == false and have_value($instance) == false)
                $errmsg[$errors++] = _("No port number or instance name specified.\nOne must be specified.");
            if (have_value($username) == false)
                $errmsg[$errors++] = _("No username specified.");
            if (have_value($password) == false)
                $errmsg[$errors++] = _("No password specified.");
            if (have_value($instancename) == false) # This is hardcoded, above.
                $errmsg[$errors++] = _("No database specified.");
            if ($port && $instance) {
                // instance overrides port
                $inargs["port"] = "";   // This is also handled in the plugin.
            }

            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }

            break;

        case CONFIGWIZARD_MODE_GETSTAGE2HTML:

            // Get variables that were passed to us
            $address = grab_array_var($inargs, "ip_address");
            $port = grab_array_var($inargs, "port", "");
            $version = grab_array_var($inargs, "version", "");
            $instance = grab_array_var($inargs, "instance", "");
            $username = grab_array_var($inargs, "username", "");
            $password = grab_array_var($inargs, "password", "");
            $instancename = grab_array_var($inargs, "instancename", "master");

            $use_2008_deprecated_stats = false;
            $use_2008_plus_stats = true;

            switch ($version) {
                
                // Log Cache Hitrate should work for these versions (2008 R2 has been verified)
                case "2000":
                case "2000-64":
                case "2005":
                    $use_2008_plus_stats = false;       # Works with 2008+
                case "2008":
                case "2008-R2":
                    $use_2008_deprecated_stats = true;  # Works with 2008 or lower
                    break;
            }
            
            $ha = @gethostbyaddr($address);

            if ($ha == "")
                $ha = $address;

            $hostname = grab_array_var($inargs, "hostname", $ha);

            $services = grab_array_var($inargs, "services", array_merge(
                array(
                    "activetransactions" => "on",
                    "connectiontime" => "on",
                    "datafilesize" => "on",
                    "logbytesflushed" => "on",  # new
                    "logfilesize" => "on",      # new
                    "logfilesusedsize" => "on", # new
                    "logfileusage" => "on",
                    "logflushes" => "on",
                    "logflushwaits" => "on",    # new
                    "loggrowths" => "on",
                    "logshrinks" => "on",
                    "logtrunct" => "on",
                    "logwait" => "on",
                    "transactionspersec" => "on",
                ),
                (($use_2008_deprecated_stats) ? array("logcachehitrate" => "on") : array())
            ));

            $serviceargs = grab_array_var($inargs, "serviceargs", array_merge(
                array(
                    "activetransactions_warning" => "10",       # standard
                    "activetransactions_critical" => "20",
                    "connectiontime_warning" => "1",            # standard (time2connect)
                    "connectiontime_critical" => "5",
                    "datafilesize_warning" => "10000",          # standard
                    "datafilesize_critical" => "100000",
                    "logbytesflushed_warning" => "10000",       # delta - new
                    "logbytesflushed_critical" => "50000",
                    "logfilesize_warning" => "40000",           # standard - new
                    "logfilesize_critical" => "60000",
                    "logfilesusedsize_warning" => "4400",       # standard - new
                    "logfilesusedsize_critical" => "5000",
                    "logfileusage_warning" => array("0", "80"), # standard
                    "logfileusage_critical" => array("0", "90"),
                    "logflushes_warning" => "20",               # delta
                    "logflushes_critical" => "30",
                    "logflushwaits_warning" => "500",           # delta - new
                    "logflushwaits_critical" => "1000",
                    "loggrowths_warning" => "20",               # standard
                    "loggrowths_critical" => "30",
                    "logshrinks_warning" => "20",               # standard
                    "logshrinks_critical" => "30",
                    "logtrunct_warning" => "20",                # standard
                    "logtrunct_critical" => "30",
                    "logwait_warning" => "100",                 # delta
                    "logwait_critical" => "1000",
                    "transactionspersec_warning" => "10",       # delta
                    "transactionspersec_critical" => "20",
                ),
                (($use_2008_deprecated_stats) ?
                    array(
                        "logcachehitrate_warning" => array("30", "50"),  # ratio
                        "logcachehitrate_critical" => array("0", "30")
                    ) : array()
                )
            ));

            $services_serial = grab_array_var($inargs, "services_serial");

            if ($services_serial != "") {
                $services = unserialize(base64_decode($services_serial));
            }

            $serviceargs_serial = grab_array_var($inargs, "serviceargs_serial");

            if ($serviceargs_serial != "") {
                $serviceargs = unserialize(base64_decode($serviceargs_serial));
            }

            // Create only one default process to monitor... we will add more via JS if someone wants to add more
            $default_services['process'][0]['monitor'] = 'off';
            $default_services['process'][0]['counter_name'] = '';
            $default_services['process'][0]['display_name'] = '';
            $default_services['process'][0]['unit'] = '';
            $default_services['process'][0]['modifier'] = '';
            $default_services['process'][0]['ring_buffer_type'] = '';
            $default_services['process'][0]['xpath'] = '';
            $default_services['process'][0]['warning'] = 60;
            $default_services['process'][0]['critical'] = 100;

            if (!isset($services['process'])) {
                $services = array_merge($services, $default_services);
            }

            $output = '
<input type="hidden" name="ip_address" value="'.encode_form_val($address).'">
<input type="hidden" name="instance" value="'.encode_form_val($instance).'">
<input type="hidden" name="port" value="'.encode_form_val($port).'">
<input type="hidden" name="version" value="'.encode_form_val($version).'">
<input type="hidden" name="username" value="'.encode_form_val($username).'">
<input type="hidden" name="password" value="'.encode_form_val($password).'">
<input type="hidden" name="instancename" value="'.encode_form_val($instancename).'">

<h5 class="ul">'._('MSSQL Server').'</h5>
<table class="table table-condensed table-no-border table-auto-width">
    <tr>
        <td>
            <label>'._('Address').':</label>
        </td>
        <td>
            <input type="text" size="20" name="ip_address" id="ip_address" value="'.encode_form_val($address).'" class="textfield form-control" disabled>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>'._('Host Name').':</label>
        </td>
        <td>
            <input type="text" size="20" name="hostname" id="hostname" value="'.encode_form_val($hostname).'" class="textfield form-control">
            <div class="subtext">'._('The name you\'d like to have associated with this MSSQL Database').'.</div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>'._('Version').':</label>
        </td>
        <td>
            <input type="text" size="20" name="version" id="version" value="'.encode_form_val($version).'" class="textfield form-control" disabled>
            <div class="subtext">'._('Version of MSSQL server').'.</div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>'._('Instance').':</label>
        </td>
        <td>
            <input type="text" size="20" name="instance" id="instance" value="'.encode_form_val($instance).'" class="textfield form-control" disabled>
        </td>
    </tr>
    <tr>
        <td>
            <label>'._('Port').':</label>
        </td>
        <td>
            <input type="text" size="5" name="port" id="port" value="'.encode_form_val($port).'" class="textfield form-control" disabled>
        </td>
    </tr>
    <tr>
        <td>
            <label>'._('Username').':</label>
        </td>
        <td>
            <input type="text" size="20" name="username" id="username" value="'.encode_form_val($username).'" class="textfield form-control" disabled>
        </td>
    </tr>
    <tr>
        <td>
            <label>'._('Password').':</label>
        </td>
        <td>
            <input type="password" size="20" name="password" id="password" value="'.encode_form_val($password).'" class="textfield form-control" disabled>
        </td>
    </tr>
    <tr>
        <td>
            <label>'._('Database').':</label>
        </td>
        <td>
            <input type="text" size="20" name="instancename" id="instancename" value="'.encode_form_val($instancename).'" class="textfield form-control" disabled>
        </td>
    </tr>
</table>

<h5 class="ul">'._('MSSQL Database Metrics').'</h5>
<p>'._('Specify the metrics you\'d like to monitor on the MSSQL Database').'.</p>
<table class="table table-no-border table-auto-width">
    <tr>
        <td class="vt">
            <input type="checkbox" id="oc" class="checkbox" name="services[activetransactions]" '.is_checked(grab_array_var($services, "activetransactions"), "on").'>
        </td>
        <td>
            <label class="normal" for="oc">
                <b>'._('Active Transactions').'</b><br>
                '._('Monitor the number of active tranactions').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[activetransactions_warning]" value="'.encode_form_val($serviceargs["activetransactions_warning"]).'" class="form-control condensed">&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[activetransactions_critical]" value="'.encode_form_val($serviceargs["activetransactions_critical"]).'" class="form-control condensed">
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="ct" class="checkbox" name="services[connectiontime]" '.is_checked(grab_array_var($services, "connectiontime"), "on").'>
        </td>
        <td>
            <label class="normal" for="ct">
                <b>'._('Connection Time').'</b><br>
                '._('Monitor the time it takes to connect to the database').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="1" name="serviceargs[connectiontime_warning]" value="'.encode_form_val($serviceargs["connectiontime_warning"]).'" class="form-control condensed"> sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="1" name="serviceargs[connectiontime_critical]" value="'.encode_form_val($serviceargs["connectiontime_critical"]).'" class="form-control condensed"> sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="ds" class="checkbox" name="services[datafilesize]" '.is_checked(grab_array_var($services, "datafilesize"), "on").'>
        </td>
        <td>
            <label class="normal" for="ds">
                <b>'._('Database Size').'</b><br>
                '._('Monitor the size of the database. Value is in KB.').'
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="5" name="serviceargs[datafilesize_warning]" value="'.encode_form_val($serviceargs["datafilesize_warning"]).'" class="form-control condensed"> KB&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="5" name="serviceargs[datafilesize_critical]" value="'.encode_form_val($serviceargs["datafilesize_critical"]).'" class="form-control condensed"> KB
            </div>
        </td>
    </tr>';

            if ($use_2008_deprecated_stats) {

                $output .= '
    <tr>
        <td class="vt">
            <input type="checkbox" id="lch" class="checkbox" name="services[logcachehitrate]" '.is_checked(grab_array_var($services, "logcachehitrate"), "on").'>
        </td>
        <td>
            <label class="normal" for="lch">
                <b>'._('Log Cache Hitrate').'</b><br>
                '._('Monitor the log cache hit rate').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> &nbsp;<label>'._('Low').':</label> <input type="text" size="1" name="serviceargs[logcachehitrate_warning][0]" value="'.encode_form_val($serviceargs["logcachehitrate_warning"][0]).'" class="form-control condensed"> % &nbsp;<label>'._('High').':</label> <input type="text" size="1" name="serviceargs[logcachehitrate_warning][1]" value="'.encode_form_val($serviceargs["logcachehitrate_warning"][1]).'" class="form-control condensed"> %
            </div>
            <div class="pad-t5">
                <label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> &nbsp;<label>'._('Low').':</label> <input type="text" size="1" name="serviceargs[logcachehitrate_critical][0]" value="'.encode_form_val($serviceargs["logcachehitrate_critical"][0]).'" class="form-control condensed"> % &nbsp;<label>'._('High').':</label> <input type="text" size="1" name="serviceargs[logcachehitrate_critical][1]" value="'.encode_form_val($serviceargs["logcachehitrate_critical"][1]).'" class="form-control condensed"> %
            </div>
        </td>
    </tr>';
            }

            $output .= '
    <tr>
        <td class="vt">
            <input type="checkbox" id="lfu" class="checkbox" name="services[logfileusage]" '.is_checked(grab_array_var($services, "logfileusage"), "on").'>
        </td>
        <td>
            <label class="normal" for="lfu">
                <b>'._('Log File Usage').'</b><br>
                '._('Monitor how much of the Log File is in use').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> &nbsp;<label>'._('Low').':</label> <input type="text" size="1" name="serviceargs[logfileusage_warning][0]" value="'.encode_form_val($serviceargs["logfileusage_warning"][0]).'" class="form-control condensed"> % &nbsp;<label>'._('High').':</label> <input type="text" size="1" name="serviceargs[logfileusage_warning][1]" value="'.encode_form_val($serviceargs["logfileusage_warning"][1]).'" class="form-control condensed"> %
            </div>
            <div class="pad-t5">
                <label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> &nbsp;<label>'._('Low').':</label> <input type="text" size="1" name="serviceargs[logfileusage_critical][0]" value="'.encode_form_val($serviceargs["logfileusage_critical"][0]).'" class="form-control condensed"> % &nbsp;<label>'._('High').':</label> <input type="text" size="1" name="serviceargs[logfileusage_critical][1]" value="'.encode_form_val($serviceargs["logfileusage_critical"][1]).'" class="form-control condensed"> %
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="lfwt" class="checkbox" name="services[logbytesflushed]" '.is_checked(grab_array_var($services, "logbytesflushed"), "on").'>
        </td>
        <td>
            <label class="normal" for="lfwt">
                <b>'._('Log Bytes Flushed/sec').'</b><br>
                '._('Monitor the log bytes flushed per second').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[logbytesflushed_warning]" value="'.encode_form_val($serviceargs["logbytesflushed_warning"]).'" class="form-control condensed"> ms&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[logbytesflushed_critical]" value="'.encode_form_val($serviceargs["logbytesflushed_critical"]).'" class="form-control condensed"> ms
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="lfwt" class="checkbox" name="services[logfilesize]" '.is_checked(grab_array_var($services, "logfilesize"), "on").'>
        </td>
        <td>
            <label class="normal" for="lfwt">
                <b>'._('Log File(s) Size (KB)').'</b><br>
                '._('Monitor the log files size in KB').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[logfilesize_warning]" value="'.encode_form_val($serviceargs["logfilesize_warning"]).'" class="form-control condensed"> ms&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[logfilesize_critical]" value="'.encode_form_val($serviceargs["logfilesize_critical"]).'" class="form-control condensed"> ms
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="lfwt" class="checkbox" name="services[logfilesusedsize]" '.is_checked(grab_array_var($services, "logfilesusedsize"), "on").'>
        </td>
        <td>
            <label class="normal" for="lfwt">
                <b>'._('Log File(s) Used Size (KB)').'</b><br>
                '._('Monitor the log files used size in KB').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[logfilesusedsize_warning]" value="'.encode_form_val($serviceargs["logfilesusedsize_warning"]).'" class="form-control condensed"> ms&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[logfilesusedsize_critical]" value="'.encode_form_val($serviceargs["logfilesusedsize_critical"]).'" class="form-control condensed"> ms
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="lfwt" class="checkbox" name="services[logflushwaits]" '.is_checked(grab_array_var($services, "logflushwaits"), "on").'>
        </td>
        <td>
            <label class="normal" for="lfwt">
                <b>'._('Log Flush Waits/sec').'</b><br>
                '._('Monitor the log flush waits per second').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[logflushwaits_warning]" value="'.encode_form_val($serviceargs["logflushwaits_warning"]).'" class="form-control condensed"> ms&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[logflushwaits_critical]" value="'.encode_form_val($serviceargs["logflushwaits_critical"]).'" class="form-control condensed"> ms
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="lfwt" class="checkbox" name="services[logflushes]" '.is_checked(grab_array_var($services, "logflushes"), "on").'>
        </td>
        <td>
            <label class="normal" for="lfwt">
                <b>'._('Log Flushes Per Second').'</b><br>
                '._('Monitor the log flush rate per second').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[logflushes_warning]" value="'.encode_form_val($serviceargs["logflushes_warning"]).'" class="form-control condensed"> ms&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[logflushes_critical]" value="'.encode_form_val($serviceargs["logflushes_critical"]).'" class="form-control condensed"> ms
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="lg" class="checkbox" name="services[loggrowths]" '.is_checked(grab_array_var($services, "loggrowths"), "on").'>
        </td>
        <td>
            <label class="normal" for="lg">
                <b>'._('Log Growths').'</b><br>
                '._('Monitor the log growths due to improperly sized partitions').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[loggrowths_warning]" value="'.encode_form_val($serviceargs["loggrowths_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[loggrowths_critical]" value="'.encode_form_val($serviceargs["loggrowths_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="ls" class="checkbox" name="services[logshrinks]" '.is_checked(grab_array_var($services, "logshrinks"), "on").'>
        </td>
        <td>
            <label class="normal" for="ls">
                <b>'._('Log Shrinks').'</b><br>
                '._('Monitor the log shrinks due to improperly sized partitions').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[logshrinks_warning]" value="'.encode_form_val($serviceargs["logshrinks_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[logshrinks_critical]" value="'.encode_form_val($serviceargs["logshrinks_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="lt" class="checkbox" name="services[logtrunct]" '.is_checked(grab_array_var($services, "logtrunct"), "on").'>
        </td>
        <td>
            <label class="normal" for="lt">
                <b>'._('Log Truncations').'</b><br>
                '._('Monitor the log truncations due to malformed tables').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[logtrunct_warning]" value="'.encode_form_val($serviceargs["logtrunct_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[logtrunct_critical]" value="'.encode_form_val($serviceargs["logtrunct_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="lw" class="checkbox" name="services[logwait]" '.is_checked(grab_array_var($services, "logwait"), "on").'>
        </td>
        <td>
            <label class="normal" for="lw">
                <b>'._('Log Waits').'</b><br>
                '._('Monitor the log waits due to small log buffers').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[logwait_warning]" value="'.encode_form_val($serviceargs["logwait_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[logwait_critical]" value="'.encode_form_val($serviceargs["logwait_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="tps" class="checkbox" name="services[transactionspersec]" '.is_checked(grab_array_var($services, "transactionspersec"), "on").'>
        </td>
        <td>
            <label class="normal" for="tps">
                <b>'._('Transactions Per Second').'</b><br>
                '._('Monitor the transactions per second').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[transactionspersec_warning]" value="'.encode_form_val($serviceargs["transactionspersec_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[transactionspersec_critical]" value="'.encode_form_val($serviceargs["transactionspersec_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
</table>';
            $output .= '
<h5 class="ul">'. _('Custom Metrics'). '</h5>
<p>'. _("Other metrics provided by the performance and Ring Buffer tables."). '</p>
<table class="table table-condensed table-no-border table-auto-width table-padded">
    <thead>
        <tr>
            <td></td>
            <td><label class="normal">'._('Counter Name').'</label>&nbsp;<i class="fa fa-question-circle pop" data-content="'._('The counter_name from the sys.sysperfinfo, sys.dm_os_performance_counters, etc. table or the field from the Ring table. ').'"></i></td>
            <td><label class="normal">'._('Display Name').'</label>&nbsp;<i class="fa fa-question-circle pop" data-content="'._('A meaningful name for monitoring.  If left blank, it will be generated from the Counter and Instance Names.').'"></i></td>
            <td><label class="normal">'._('Unit').'</label>&nbsp;<i class="fa fa-question-circle pop" data-content="'._('Optional label for unit of measure, e.g., s, ms, MB.').'"></i></td>
            <td><label class="normal">'._('Mod').'</label>&nbsp;<i class="fa fa-question-circle pop" data-content="'._('Optional multiplication modifier, e.g., 100.').'"></i></td>
            <td><label class="normal">'._('Ring Buffer Type').'</label>&nbsp;<i class="fa fa-question-circle pop" data-content="'._('Required for Ring Buffer queries.  The ring_buffer_type from the sys.dm_os_ring_buffers table.').'"></i></td>
            <td><label class="normal">'._('XPath').'</label>&nbsp;<i class="fa fa-question-circle pop" data-content="'._('Required for Ring Buffer queries.  The xpath to the value you want to monitor.').'"></i></td>
            <td><label class="normal">'._('Warning').'&nbsp;#</label></td>
            <td><label class="normal">'._('Critical').'&nbsp;#</label></td>
        </tr>
    </thead>
    <tbody id="process-list">';

            foreach ($services['process'] as $i => $metrics) {
                $output .= '
                    <tr>
                        <td><input type="checkbox" style="margin-bottom: 5px" class="checkbox deselect" name="services[process]['.$i.'][monitor]" '.is_checked($metrics['monitor'], 'on'). '></td>
                        <td><input type="text" name="services[process]['.$i.'][counter_name]" value="'.encode_form_val($metrics['counter_name']).'" class="form-control condensed"></td>
                        <td><input type="text" name="services[process]['.$i.'][display_name]" value="'.encode_form_val($metrics['display_name']).'" class="form-control condensed"></td>
                        <td><input type="text" size="2" name="services[process]['.$i.'][unit]" value="'.encode_form_val($metrics['unit']).'" class="form-control condensed"></td>
                        <td><input type="text" size="2" name="services[process]['.$i.'][modifier]" value="'.encode_form_val($metrics['modifier']).'" class="form-control condensed"></td>
                        <td><input type="text" name="services[process]['.$i.'][ring_buffer_type]" value="'.encode_form_val($metrics['ring_buffer_type']).'" class="form-control condensed"></td>
                        <td><input type="text" name="services[process]['.$i.'][xpath]" value="'.encode_form_val($metrics['xpath']).'" class="form-control condensed"></td>
                        <td><input type="text" size="2" name="services[process]['.$i.'][warning]" value="'.encode_form_val($metrics['warning']).'" class="form-control condensed"></td>
                        <td><input type="text" size="2" name="services[process]['.$i.'][critical]" value="'.encode_form_val($metrics['critical']).'" class="form-control condensed"></td>
                    </tr>';
            }

            $output .= '
    </tbody>
</table>
<div style="margin: 10px 0 20px 0;">
    <a style="cursor: pointer;" id="add-new-service">'._('Add Another Custom Metric').'</a>
</div>';

            $output .= '
<script type="text/javascript">
    var processnum = ' . (count($services['process']) - 1) . ';

    $(document).ready(function() {

        $("#add-new-service").click(function() {
            processnum++;

            row = "".concat(
\'<tr>\',
\'<td><input type="checkbox" style="margin-bottom: 5px" class="checkbox deselect" name="services[process][\'+processnum+\'][monitor]" checked></td>\',
\'<td><input type="text" class="form-control condensed" name="services[process][\'+processnum+\'][counter_name]" value=""></td>\',
\'<td><input type="text" class="form-control condensed" name="services[process][\'+processnum+\'][display_name]" value=""></td>\',
\'<td><input type="text" size=2 class="form-control condensed" name="services[process][\'+processnum+\'][unit]" value=""></td>\',
\'<td><input type="text" size=2 class="form-control condensed" name="services[process][\'+processnum+\'][modifier]" value=""></td>\',
\'<td><input type="text" class="form-control condensed" name="services[process][\'+processnum+\'][ring_buffer_type]" value=""></td>\',
\'<td><input type="text" class="form-control condensed" name="services[process][\'+processnum+\'][xpath]" value=""></td>\',
\'<td><input type="text" size=2 class="form-control condensed" size="2" name="services[process][\'+processnum+\'][warning]" value="60"></td>\',
\'<td><input type="text" size=2 class="form-control condensed" size="2" name="services[process][\'+processnum+\'][critical]" value="100"></td>\',
\'</tr>\');

            $("#process-list").append(row);
        });
    });

</script>';
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:

            // get variables that were passed to us
            $address = grab_array_var($inargs, "ip_address");
            $hostname = grab_array_var($inargs, "hostname");
            $hostname = nagiosccm_replace_user_macros($hostname);
            $instance = grab_array_var($inargs, "instance", "");
            $port = grab_array_var($inargs, "port", "");
            $version = grab_array_var($inargs, "version", "");
            $username = grab_array_var($inargs, "username", "");
            $password = grab_array_var($inargs, "password", "");
            $instancename = grab_array_var($inargs, "instancename", "");
            $services = grab_array_var($inargs, "services", array());
            $serviceargs = grab_array_var($inargs, "serviceargs", array());


            // check for errors
            $errors = 0;
            $errmsg = array();
            if (is_valid_host_name($hostname) == false)
                $errmsg[$errors++] = "Invalid host name.";

            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }

            break;


        case CONFIGWIZARD_MODE_GETSTAGE3HTML:

            // get variables that were passed to us
            $address = grab_array_var($inargs, "ip_address");
            $hostname = grab_array_var($inargs, "hostname");
            $instance = grab_array_var($inargs, "instance", "");
            $port = grab_array_var($inargs, "port", "");
            $version = grab_array_var($inargs, "version", "");
            $username = grab_array_var($inargs, "username", "");
            $password = grab_array_var($inargs, "password", "");
            $instancename = grab_array_var($inargs, "instancename", "");

            $services = grab_array_var($inargs, "services");
            $serviceargs = grab_array_var($inargs, "serviceargs");

            $output = '
            
        <input type="hidden" name="ip_address" value="'.encode_form_val($address).'" />
        <input type="hidden" name="hostname" value="'.encode_form_val($hostname).'" />
        <input type="hidden" name="port" value="'.encode_form_val($port).'" />
        <input type="hidden" name="version" value="'.encode_form_val($version).'" />
        <input type="hidden" name="instance" value="'.encode_form_val($instance).'" />
        <input type="hidden" name="username" value="'.encode_form_val($username).'" />
        <input type="hidden" name="password" value="'.encode_form_val($password).'" />
        <input type="hidden" name="instancename" value="'.encode_form_val($instancename).'" />
        <input type="hidden" name="services_serial" value="'.base64_encode(serialize($services)).'" />
        <input type="hidden" name="serviceargs_serial" value="'.base64_encode(serialize($serviceargs)).'" />
        
        <!--SERVICES='.serialize($services).'<BR>
        SERVICEARGS='.serialize($serviceargs).'<BR>-->
        
            ';
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:

            break;

        case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:


            $output = '
            ';
            break;

        case CONFIGWIZARD_MODE_GETOBJECTS:

            $hostname = grab_array_var($inargs, "hostname", "");
            $address = grab_array_var($inargs, "ip_address", "");
            $hostaddress = $address;
            $instance = grab_array_var($inargs, "instance", "");
            $port = grab_array_var($inargs, "port", "");
            $version = grab_array_var($inargs, "version", "");
            $username = grab_array_var($inargs, "username", "");
            $password = grab_array_var($inargs, "password", "");
            $instancename = grab_array_var($inargs, "instancename", "");

            $services_serial = grab_array_var($inargs, "services_serial", "");
            $serviceargs_serial = grab_array_var($inargs, "serviceargs_serial", "");

            $services = unserialize(base64_decode($services_serial));
            $serviceargs = unserialize(base64_decode($serviceargs_serial));

            /*
            echo "SERVICES<BR>";
            print_r($services);
            echo "<BR>";
            echo "SERVICEARGS<BR>";
            print_r($serviceargs);
            echo "<BR>";
            */

            // save data for later use in re-entrance
            $meta_arr = array();
            $meta_arr["hostname"] = $hostname;
            $meta_arr["ip_address"] = $address;
            $meta_arr["port"] = $port;
            $meta_arr["instance"] = $instance;
            $meta_arr["version"] = $version;
            $meta_arr["username"] = $username;
            $meta_arr["password"] = $password;
            $meta_arr["instancename"] = $instancename;
            $meta_arr["services"] = $services;
            $meta_arr["serviceargs"] = $serviceargs;
            save_configwizard_object_meta($wizard_name, $hostname, "", $meta_arr);

            $objs = array();

            // NOTE: This wizard now uses the check_mssql_server.php plugin (under the covers).
            if (!host_exists($hostname)) {
                $objs[] = array(
                    "type" => OBJECTTYPE_HOST,
                    "use" => "xiwizard_mssqldatabase_host",
                    "host_name" => $hostname,
                    "address" => $hostaddress,
                    "icon_image" => "mssqldatabase.png",
                    "statusmap_image" => "mssqldatabase.png",
                    "_xiwizard" => $wizard_name,
                );
            }

            $perftype = 'default';

            switch ($version) {
                case "AZURE":
                    $perftype = 'azure';
                    break;

                case "PDW":
                    $perftype = 'pdw';
                    break;

                case "2005":
                case " 2000":
                    $perftype = 'deprecated';
                    break;
            }

            // common plugin opts
            // checktype = "database", because this is the "database" wizard.
            $commonopts = " --checktype 'database' -U '$username' -P '$password' --instancename '$instancename' --perftype $perftype ";
            $instancetext = '';

            if ($instance) {
                $commonopts .= "-I '$instance' ";
                $instancetext = " - $instance";
            }

            if ($port) {
                $commonopts .= "-p $port ";
            }

            foreach ($services as $service => $args) {

                $pluginopts = "";
                $pluginopts .= $commonopts;

                switch ($service) {

                    case "connectiontime":

                        $pluginopts .= "--mode time2connect --warning ".$serviceargs["connectiontime_warning"]." --critical ".$serviceargs["connectiontime_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $instancename." MSSQL Connection Time".$instancetext,
                            "use" => "xiwizard_mssqldatabase_service",
                            "check_command" => "check_xi_mssql_database2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "logfileusage":

                        $pluginopts .= "--mode logfileusage --warning ".$serviceargs["logfileusage_warning"][0].":".$serviceargs["logfileusage_warning"][1]." --critical ".$serviceargs["logfileusage_critical"][0].":".$serviceargs["logfileusage_critical"][1];

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $instancename." MSSQL Log File Usage".$instancetext,
                            "use" => "xiwizard_mssqldatabase_service",
                            "check_command" => "check_xi_mssql_database2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "datafilesize":

                        $pluginopts .= "--mode datasize --warning ".$serviceargs["datafilesize_warning"]." --critical ".$serviceargs["datafilesize_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $instancename." MSSQL Database Size".$instancetext,
                            "use" => "xiwizard_mssqldatabase_service",
                            "check_command" => "check_xi_mssql_database2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "activetransactions":

                        $pluginopts .= "--mode activetrans --warning ".$serviceargs["activetransactions_warning"]." --critical ".$serviceargs["activetransactions_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $instancename." MSSQL Active Transactions".$instancetext,
                            "use" => "xiwizard_mssqldatabase_service",
                            "check_command" => "check_xi_mssql_database2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "logcachehitrate":

                        $pluginopts .= "--mode logcachehit --warning ".$serviceargs["logcachehitrate_warning"][0].":".$serviceargs["logcachehitrate_warning"][1]." --critical ".$serviceargs["logcachehitrate_critical"][0].":".$serviceargs["logcachehitrate_critical"][1];

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $instancename." MSSQL Log Cache Hit Rate".$instancetext,
                            "use" => "xiwizard_mssqldatabase_service",
                            "check_command" => "check_xi_mssql_database2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;


                    case "logwait":

                        $pluginopts .= "--mode logwait --warning ".$serviceargs["logwait_warning"]." --critical ".$serviceargs["logwait_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $instancename." MSSQL Log Flush Wait Time".$instancetext,
                            "use" => "xiwizard_mssqldatabase_service",
                            "check_command" => "check_xi_mssql_database2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "loggrowths":

                        $pluginopts .= "--mode loggrowths --warning ".$serviceargs["loggrowths_warning"]." --critical ".$serviceargs["loggrowths_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $instancename." MSSQL Log Growths".$instancetext,
                            "use" => "xiwizard_mssqldatabase_service",
                            "check_command" => "check_xi_mssql_database2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "logshrinks":

                        $pluginopts .= "--mode logshrinks --warning ".$serviceargs["logshrinks_warning"]." --critical ".$serviceargs["logshrinks_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $instancename." MSSQL Log Shrinks".$instancetext,
                            "use" => "xiwizard_mssqldatabase_service",
                            "check_command" => "check_xi_mssql_database2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "logtrunct":

                        $pluginopts .= "--mode logtruncs --warning ".$serviceargs["logtrunct_warning"]." --critical ".$serviceargs["logtrunct_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $instancename." MSSQL Log Truncations".$instancetext,
                            "use" => "xiwizard_mssqldatabase_service",
                            "check_command" => "check_xi_mssql_database2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "logbytesflushed":

                        $pluginopts .= "--mode logbytesflushed --warning ".$serviceargs["logbytesflushed_warning"]." --critical ".$serviceargs["logbytesflushed_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $instancename." MSSQL Log Bytes Flushed / Sec".$instancetext,
                            "use" => "xiwizard_mssqldatabase_service",
                            "check_command" => "check_xi_mssql_database2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "logfilesize":

                        $pluginopts .= "--mode logfilessize --warning ".$serviceargs["logfilesize_warning"]." --critical ".$serviceargs["logfilesize_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $instancename." MSSQL Log Files Size".$instancetext,
                            "use" => "xiwizard_mssqldatabase_service",
                            "check_command" => "check_xi_mssql_database2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "logfilesusedsize":

                        $pluginopts .= "--mode logfilesused --warning ".$serviceargs["logfilesusedsize_warning"]." --critical ".$serviceargs["logfilesusedsize_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $instancename." MSSQL Log Files Used Size".$instancetext,
                            "use" => "xiwizard_mssqldatabase_service",
                            "check_command" => "check_xi_mssql_database2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "logflushwaits":

                        $pluginopts .= "--mode logflushwaits --warning ".$serviceargs["logflushwaits_warning"]." --critical ".$serviceargs["logflushwaits_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $instancename." MSSQL Log Flush Waits / Sec".$instancetext,
                            "use" => "xiwizard_mssqldatabase_service",
                            "check_command" => "check_xi_mssql_database2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "logflushes":

                        $pluginopts .= "--mode logflushes --warning ".$serviceargs["logflushes_warning"]." --critical ".$serviceargs["logflushes_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $instancename." MSSQL Log Flushes / Sec".$instancetext,
                            "use" => "xiwizard_mssqldatabase_service",
                            "check_command" => "check_xi_mssql_database2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "transactionspersec":

                        $pluginopts .= "--mode transpsec --warning ".$serviceargs["transactionspersec_warning"]." --critical ".$serviceargs["transactionspersec_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => $instancename." MSSQL Transactions / Sec".$instancetext,
                            "use" => "xiwizard_mssqldatabase_service",
                            "check_command" => "check_xi_mssql_database2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "process":
                        foreach ($args as $i => $service) {
                            if (!array_key_exists('monitor', $service) || empty($service['counter_name'])) {
                                continue;
                            }

                            $pluginCustomOpts  = '--mode \'custom\' --warning '.$service["warning"].' --critical '.$service["critical"].' ';
                            $pluginCustomOpts .= '--custom \'("counter_name" : "'.$service["counter_name"].'", "instance_name" : "'.$instancename.'", "unit" : "'.$service["unit"].'", "modifier" : "'.$service["modifier"].'", "ring_buffer_type" : "'.$service["ring_buffer_type"].'", "xpath" : "'.$service["xpath"].'")\'';

                            $serviceDescription = $service['display_name'];

                            if (empty($service['display_name'])) {
                                # e.g. Cache Hit Ratio to 'cachehitratio'
                                $serviceDescription = ucwords(str_replace("%", "Pct", $service["counter_name"]));
                                $serviceDescription = (!empty($instancename) ? $instancename." " : "")."MSSQL ".$serviceDescription;
                            }

                            $objs[] = array(
                                "type" => OBJECTTYPE_SERVICE,
                                "host_name" => $hostname,
                                "service_description" => $serviceDescription,
                                "use" => "xiwizard_mssqlserver_service",
                                "_xiwizard" => $wizard_name,
                                "check_command" => "check_xi_mssql_database2!".$pluginopts.$pluginCustomOpts,
                            );
                        }
                        break;

                    default:
                        break;
                }
            }

            // echo "OBJECTS:<BR>";
            // print_r($objs);
            // exit();

            // return the object definitions to the wizard
            $outargs[CONFIGWIZARD_NAGIOS_OBJECTS] = $objs;

            break;

        default:
            break;
    }

    return $output;
}

?>
