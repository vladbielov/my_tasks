<?php
//
// SNMP Walk Config Wizard
// Copyright (c) 2008-2020 Nagios Enterprises, LLC. All rights reserved.
//

include_once(dirname(__FILE__) . '/../configwizardhelper.inc.php');

snmpwalk_configwizard_init();

function snmpwalk_configwizard_init()
{
    $name = "snmpwalk";
    $args = array(
        CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "2.0.1",
        CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
        CONFIGWIZARD_DESCRIPTION => _("Scan an SNMP-enabled device for elements to monitor."),
        CONFIGWIZARD_DISPLAYTITLE => _("SNMP Walk"),
        CONFIGWIZARD_FUNCTION => "snmpwalk_configwizard_func",
        CONFIGWIZARD_PREVIEWIMAGE => "snmp.png",
        CONFIGWIZARD_FILTER_GROUPS => array('network'),
        CONFIGWIZARD_REQUIRES_VERSION => 500
    );

    register_configwizard($name, $args);
}


/**
 * @param string $mode
 * @param null   $inargs
 * @param        $outargs
 * @param        $result
 *
 * @return string
 */
function snmpwalk_configwizard_func($mode = "", $inargs = null, &$outargs, &$result)
{
    $wizard_name = "snmpwalk";

    // Initialize return code and output
    $result = 0;
    $output = "";

    // Initialize output args - pass back the same data we got
    $outargs[CONFIGWIZARD_PASSBACK_DATA] = $inargs;

    switch ($mode) {
        case CONFIGWIZARD_MODE_GETSTAGE1HTML:

            $address = grab_array_var($inargs, "ip_address", "");
            $port = grab_array_var($inargs, "port", "161");
            $snmpcommunity = grab_array_var($inargs, "snmpcommunity", "public");

            $snmpversion = grab_array_var($inargs, "snmpversion", "2c");
            $timeout = grab_array_var($inargs, "timeout", 15);
            $oid = grab_array_var($inargs, "oid", "");
            $maxresults = grab_array_var($inargs, "maxresults", 200);
            $mibs = grab_array_var($inargs, "mibs", array(''));

            $snmpopts = "";
            $snmpopts_serial = grab_array_var($inargs, "snmpopts_serial", "");
            if ($snmpopts_serial != "")
                $snmpopts = unserialize(base64_decode($snmpopts_serial));
            if (!is_array($snmpopts)) {
                $snmpopts_default = array(
                    "v3_security_level" => "",
                    "v3_username" => "",
                    "v3_auth_password" => "",
                    "v3_privacy_password" => "",
                    "v3_auth_proto" => "",
                    "v3_priv_proto" => "",
                );
                $snmpopts = grab_array_var($inargs, "snmpopts", $snmpopts_default);
            }

            $output = '
<h5 class="ul">'._('SNMP Information').'</h5>
<table class="table table-condensed table-no-border table-auto-width">
    <tr>
        <td class="vt">
            <label>'._('Device Address').':</label>
        </td>
        <td>
            <input type="text" size="40" name="ip_address" id="ip_address" value="' . encode_form_val($address) . '" class="form-control">
            <div class="subtext">'._('The IP address or fully qualified DNS name of the server or device you\'d like to monitor.').'</div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>'._('Device Port').':</label>
        </td>
        <td>
            <input type="text" size="40" name="port" id="port" value="' . encode_form_val($port) . '" class="form-control">
            <div class="subtext">'._('The port on which the SNMP device is listening.').'</div>
        </td>
    </tr>
</table>

<h5 class="ul">'._('SNMP Authentication').'</h5>
<table class="table table-condensed table-no-border table-auto-width">
    <tr>
        <td class="vt" style="width: 170px;">
            <label>'._('SNMP Version').':</label>
        </td>
        <td>
            <select name="snmpversion" id="snmpversion" class="form-control">
                <option value="1" ' . is_selected($snmpversion, "1") . '>1</option>
                <option value="2c" ' . is_selected($snmpversion, "2c") . '>2c</option>
                <option value="3" ' . is_selected($snmpversion, "3") . '>3</option>
            </select>
            <div class="subtext">'._('The SNMP protocol version used to commicate with the device.').'</div>
        </td>
    </tr>
    <tr id="snmpv1-2">
        <td class="vt">
            <label>'._('SNMP Community').':</label>
        </td>
        <td>
            <input type="text" size="20" name="snmpcommunity" id="snmpcommunity" value="' . encode_form_val($snmpcommunity) . '" class="form-control">
            <div class="subtext">'._('The SNMP community string used to query the device.').'</div>
        </td>
    </tr>
    <tr class="snmpv3 hide">
        <td>
            <label>'._('Security Level').':</label>
        </td>
        <td>
            <select name="snmpopts[v3_security_level]" class="form-control security_level">
                <option value="authPriv" ' . is_selected($snmpopts["v3_security_level"], "authPriv") . '>authPriv</option>
                <option value="authNoPriv" ' . is_selected($snmpopts["v3_security_level"], "authNoPriv") . '>authNoPriv</option>
                <option value="noAuthNoPriv" ' . is_selected($snmpopts["v3_security_level"], "noAuthNoPriv") . '>noAuthNoPriv</option>
            </select>
        </td>
    </tr>
    <tr class="snmpv3 hide">
        <td>
            <label>'._('Username').':</label>
        </td>
        <td>
            <input type="text" size="20" name="snmpopts[v3_username]" value="' . encode_form_val($snmpopts["v3_username"]) . '" class="form-control">
        </td>
    </tr>
    <tr class="snmpv3 hide">
        <td>
            <label>'._('Authentication Password').':</label>
        </td>
        <td>
            <input type="text" size="20" name="snmpopts[v3_auth_password]" value="' . encode_form_val($snmpopts["v3_auth_password"]) . '" class="form-control authPriv-enable authNoPriv-enable noAuthNoPriv-disable">
        </td>
    </tr>
    <tr class="snmpv3 hide">
        <td>
            <label>'._('Authentication Protocol').':</label>
        </td>
        <td>
            <select name="snmpopts[v3_auth_proto]" class="form-control authPriv-enable authNoPriv-enable noAuthNoPriv-disable">
                <option value="MD5" ' . is_selected($snmpopts["v3_auth_proto"], "MD5") . '>MD5</option>
                <option value="SHA" ' . is_selected($snmpopts["v3_auth_proto"], "SHA") . '>SHA</option>
            </select>
        </td>
    </tr>
    <tr class="snmpv3 hide">
        <td>
            <label>'._('Privacy Password').':</label>
        </td>
        <td>
            <input type="text" size="20" name="snmpopts[v3_privacy_password]" value="' . encode_form_val($snmpopts["v3_privacy_password"]) . '" class="form-control authPriv-enable authNoPriv-disable noAuthNoPriv-disable">
        </td>
    </tr>
    <tr class="snmpv3 hide">
        <td>
            <label>' . _('Privacy Protocol') . ':</label>
        </td>
        <td>
            <select name="snmpopts[v3_priv_proto]" class="form-control authPriv-enable authNoPriv-disable noAuthNoPriv-disable">
                <option value="des" ' . is_selected($snmpopts["v3_priv_proto"], "des") . '>DES</option>
                <option value="aes" ' . is_selected($snmpopts["v3_priv_proto"], "aes") . '>AES</option>
            </select>
        </td>
    </tr>
</table>

<script type="text/javascript">
$(document).ready(function() {

    $(".add-mib-box").click(function() {
        var test = $(".mib-box:first").clone();
        $(".mib-list").append(test);
        $(".mib-box:last option:selected").removeAttr("selected");
        $(".mib-box:last").val("");
        var l = $(".mib-box:last").find("a");
        l.removeClass("add-mib-box").addClass("rm-mib-box");
        l.html("'._('Remove').'");
    });

    $(".mib-list").on("click", ".rm-mib-box", function() {
        $(this).parent(".mib-box").remove();
    });

});
</script>
<style type="text/css">
.mib-box { margin-bottom: 5px; }
.mib-box:last-child { margin-bottom: 0; }
</style>

<h5 class="ul">'._('SNMP Scan Settings').'</h5>
<p>'._('Specify some specifics to narrow down the SNMP scan results.').'</p>
<table class="table table-condensed table-no-border table-auto-width">
    <tr>
        <td class="vt">
            <label for="mibs">MIBs:</label>
        </td>
        <td>
            <div class="mib-list">';

        $mibs_list = get_mibs();

        foreach ($mibs as $i => $sm) {
            if ($i == 0) {
                $text = ' &nbsp <a class="add-mib-box">+ '._('Add another MIB').'</a>';
            } else {
                $text = ' &nbsp <a class="rm-mib-box">'._('Remove').'</a>';
            }
            $output .= '<div class="mib-box"><select name="mibs[]" class="form-control">';
            $output .= '<option value=""></option>';
            foreach ($mibs_list as $m) {
                $selected = '';
                if ($sm == $m['mib_name']) { $selected = ' selected'; } 
                $output .= '<option value="'.$m['mib_name'].'"'.$selected.'>'.$m['mib_name'].'</option>';
            }
            $output .= '</select>'.$text.'</div>';
        }

        $output .= '
            </div>
        <div class="subtext">'._('Select MIBs whose OIDs you want to see. By default, if no MIBs selected, the scan will show all OIDs for all MIBs.').'</div>
        </td>
    </tr>
</table>

<h5 class="ul">'._('SNMP Advanced Scan Settings').'</h5>
<p>'._('Specify advanced settings for the SNMP scan. Adjusting these settings is <b>optional</b>.').'</p>
<table class="table table-condensed table-no-border table-auto-width">
    <tr>
        <td class="vt">
            <label>OID:</label>
        </td>
        <td>
            <input type="text" size="20" name="oid" id="oid" value="' . encode_form_val($oid) . '" class="form-control">
            <div class="subtext">'._('The top-level OID to use for scanning. If empty, by default, it will scan "private" which should work for most MIBs.').'</div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>'._('Timeout').':</label>
        </td>
        <td>
            <input type="text" size="2" name="timeout" id="timeout" value="' . encode_form_val($timeout) . '" class="form-control">
            <div class="subtext">'._('The maximum number of seconds to wait for the SNMP scan to complete.').'</div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>'._('Max Results').':</label>
        </td>
        <td>
            <input type="text" size="3" name="maxresults" id="maxresults" value="' . encode_form_val($maxresults) . '" class="form-control">
            <div class="subtext">'._('The maximum number of results to process from the SNMP scan.').'</div>
        </td>
    </tr>

</table>

<div id="snmpwalk-throbber" class="hide" style="padding-bottom: 120px; z-index: 10000;">
    <div class="message" style="width: 450px;">
        <ul class="infoMessage">
            <li><b>'._('Scanning device. Please wait...').'</b></li>
        </ul>
    </div>
</div>

<script type="text/javascript">
$(document).ready(function() {
    check_snmpwalk_version();
    $("#configWizardForm").submit(function(e) {
        whiteout();
        $("#snmpwalk-throbber").center().show();
    });
    $("#snmpversion").change(function() {
        check_snmpwalk_version();
    });

    security_level = $(".security_level").val();
    enable_fields_by_security_level(security_level);
    $(".security_level").change(function () {
        enable_fields_by_security_level($(this).val());
    });

});

function enable_fields_by_security_level(level) {
    $("." + level + "-enable").attr("disabled", false);
    $("." + level + "-disable").attr("disabled", true);
}

function check_snmpwalk_version() {
    if ($("#snmpversion").val() != "3") {
        $(".snmpv3").hide();
        $("#snmpv1-2").show();
    } else {
        $(".snmpv3").show();
        $("#snmpv1-2").hide();
    }
}
</script>';
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:

            // Get variables that were passed to us
            $address = grab_array_var($inargs, "ip_address", "");
            $address = nagiosccm_replace_user_macros($address);
            $port = grab_array_var($inargs, "port", "161");
            $snmpcommunity = grab_array_var($inargs, "snmpcommunity", "public");
            $snmpversion = grab_array_var($inargs, "snmpversion", "2c");
            $oid = grab_array_var($inargs, "oid", "");
            $maxresults = grab_array_var($inargs, "maxresults", 200);
            $timeout = grab_array_var($inargs, "timeout", 15);

            // Check for errors
            $errors = 0;
            $errmsg = array();
            if (have_value($address) == false)
                $errmsg[$errors++] = "No address specified.";
            if (!is_numeric($port))
                $errmsg[$errors++] = "Port number must be numeric.";
            if (have_value($snmpcommunity) == false && $snmpversion != "3")
                $errmsg[$errors++] = "No SNMP community specified.";
            if (have_value($snmpversion) == false)
                $errmsg[$errors++] = "No SNMP version specified.";

            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }

            break;

        case CONFIGWIZARD_MODE_GETSTAGE2HTML:

            // Get variables that were passed to us
            $address = grab_array_var($inargs, "ip_address");
            $ha = @gethostbyaddr($address);
            if ($ha == "")
                $ha = $address;
            $hostname = grab_array_var($inargs, "hostname", $ha);

            $port = grab_array_var($inargs, "port", "161");
            $snmpcommunity = grab_array_var($inargs, "snmpcommunity", "public");
            $snmpversion = grab_array_var($inargs, "snmpversion", "2c");
            $oid = grab_array_var($inargs, "oid", "");
            $timeout = grab_array_var($inargs, "timeout", 15);
            $maxresults = grab_array_var($inargs, "maxresults", 200);
            $mibs = grab_array_var($inargs, "mibs", array(''));

            $snmpopts_serial = grab_array_var($inargs, "snmpopts_serial", "");
            if ($snmpopts_serial == "") {
                $snmpopts = grab_array_var($inargs, "snmpopts");
            } else {
                $snmpopts = unserialize(base64_decode($snmpopts_serial));
            }

            $services = "";
            $services_serial = grab_array_var($inargs, "services_serial", "");
            if ($services_serial != "") {
                $services = unserialize(base64_decode($services_serial));
            } else {
                $services = grab_array_var($inargs, "services", array());
            }

            $serviceargs_serial = grab_array_var($inargs, "serviceargs_serial");
            if ($serviceargs_serial != "") {
                $serviceargs = unserialize(base64_decode($serviceargs_serial));
            } else {
                $serviceargs = grab_array_var($inargs, "serviceargs", array());
            }

            // Only do the scan if we have no service args already
            if (empty($serviceargs)) {

                $resultfile = get_tmp_dir() . "/snmpwalk-" . escapeshellcmd($oid) . "-" . escapeshellcmd(nagiosccm_replace_user_macros($address));

                // snmp v3 stuff
                $cmdargs = "";
                if ($snmpversion == "3") {

                    $securitylevel = grab_array_var($snmpopts, "v3_security_level");
                    $username = grab_array_var($snmpopts, "v3_username");
                    $authproto = grab_array_var($snmpopts, "v3_auth_proto");
                    $authpassword = grab_array_var($snmpopts, "v3_auth_password");
                    $privacypassword = grab_array_var($snmpopts, "v3_privacy_password");
                    $privproto = grab_array_var($snmpopts, "v3_priv_proto");

                    if ($securitylevel != "")
                        $cmdargs .= " -l " . $securitylevel;
                    if ($username != "")
                        $cmdargs .= " -u " . nagiosccm_replace_user_macros($username);
                    if ($authproto != "")
                        $cmdargs .= " -a " . $authproto;
                    if ($authpassword != "")
                        $cmdargs .= " -A " . nagiosccm_replace_user_macros($authpassword);
                    if ($privacypassword != "")
                        $cmdargs .= " -X " . nagiosccm_replace_user_macros($privacypassword);
                    if ($privproto != "")
                        $cmdargs .= " -x " . $privproto;

                }

                if (empty($oid)) {
                    $useoid = "private";
                } else {
                    $useoid = escapeshellcmd($oid);
                }

                // Clean up empty mibs
                foreach ($mibs as $i => $m) {
                    if (empty($m)) {
                        unset($mibs[$i]);
                    }
                }

                // Replace user macros for fields we can use them in
                $cstring = nagiosccm_replace_user_macros($snmpcommunity);

                // Make command line and escape cmd args
                if ($snmpversion == "3") {
                    $cmdline = "/usr/bin/snmpwalk -m +ALL -v " . escapeshellcmd($snmpversion) . " " . escapeshellcmd($cmdargs) . " " . escapeshellcmd(nagiosccm_replace_user_macros($address)) . ":" . escapeshellcmd(nagiosccm_replace_user_macros($port)) . " " . $useoid . " > " . $resultfile . " 2>&1 & echo $!";
                } else {
                    $cmdline = "/usr/bin/snmpwalk -m +ALL -v " . escapeshellcmd($snmpversion) . " -c " . escapeshellcmd(nagiosccm_replace_user_macros($snmpcommunity)) . escapeshellcmd($cmdargs) . " " . escapeshellcmd(nagiosccm_replace_user_macros($address)) . ":" . escapeshellcmd(nagiosccm_replace_user_macros($port)) . " " . $useoid . " > " . $resultfile . " 2>&1 & echo $!";
                }

                // Run the command
                exec($cmdline, $op);
                $pid = (int)$op[0];

                // Wait until earlier of timeout or completion
                sleep(1);
                for ($x = 0; $x < $timeout; $x++) {

                    // See if process if still running...
                    exec("ps ax | grep $pid 2>&1", $output);
                    $check_pid = "";
                    while (list(, $row) = each($output)) {
                        $row_array = explode(" ", $row);
                        $check_pid = $row_array[0];
                        if ($pid == $check_pid) {
                            break;
                        }
                    }

                    // Process is gone - it must be done!
                    if ($check_pid != $pid)
                        break;

                    // Else process is still running
                    sleep(1);
                }

                // Read the results
                $fcontents = file_get_contents($resultfile);

                $rows = explode("\n", $fcontents);
                $x = 0;
                $hit_max = false;
                foreach ($rows as $row) {

                    // Get mib
                    $parts = explode("::", $row);
                    $mib = $parts[0];

                    if (!empty($mibs)) {
                        if (!empty($mib) && !in_array($mib, $mibs)) {
                            continue;
                        }
                    }

                    array_shift($parts);
                    $newrow = implode("::", $parts);

                    // Get oid
                    $parts = explode(" = ", $newrow);
                    $theoid = $parts[0];

                    array_shift($parts);
                    $newrow = implode(" = ", $parts);

                    // Get type
                    $parts = explode(":", $newrow);
                    $type = $parts[0];

                    array_shift($parts);
                    $newrow = implode(":", $parts);

                    // Get value
                    $val = $newrow;

                    // Skip if there is no value and no type
                    if (empty($val) && strpos($type, "No more variables left in this MIB View") !== false) {
                        continue;
                    }

                    // Make sure we have all the data
                    if ($mib == "" || $theoid == "" || $type == "") {
                        continue;
                    }

                    $x++;
                    if ($x > $maxresults) {
                        $hit_max = true;
                        break;
                    }

                    $serviceargs["oid"][] = array(
                        "oid" => $theoid,
                        "type" => $type,
                        "val" => $val,
                        "name" => "",
                        "label" => "",
                        "units" => "",
                        "matchtype" => "",
                        "warning" => "",
                        "critical" => "",
                        "string" => "",
                        "mib" => $mib,
                    );
                    $services["oid"][] = "";
                }

            }

            // Create mib list for display purposes only
            $miblist = '';
            if (!empty($mibs)) {
                $miblist = implode(', ', $mibs);
            }

            $output = '
<script type="text/javascript">
$(document).ready(function() {

    $(".show-error").click(function() {
        $(".error-out").show();
    });

    $(".match-type").change(function() {
        var match = $(this).val();
        if (match == "none") {
            $(this).parents("tr").find(".numeric").hide();
            $(this).parents("tr").find(".string").hide();
        } else if (match == "numeric") {
            $(this).parents("tr").find(".numeric").show();
            $(this).parents("tr").find(".string").hide();
        } else if (match == "string") {
            $(this).parents("tr").find(".numeric").hide();
            $(this).parents("tr").find(".string").show();
        }
    });

});
</script>

<style type="text/css">
.form-control.hide { display: none; }
.input-group .input-group-addon { height: 29px; }
</style>

<input type="hidden" name="port" value="' . encode_form_val($port) . '">
<input type="hidden" name="ip_address" value="' . encode_form_val($address) . '">
<input type="hidden" name="snmpcommunity" value="' . encode_form_val($snmpcommunity) . '">
<input type="hidden" name="snmpversion" value="' . encode_form_val($snmpversion) . '">
<input type="hidden" name="oid" value="' . encode_form_val($oid) . '">
<input type="hidden" name="miblist" value="' . encode_form_val($miblist) . '">
<input type="hidden" name="timeout" value="' . encode_form_val($timeout) . '">
<input type="hidden" name="snmpopts_serial" value="' . base64_encode(serialize($snmpopts)) . '">';
            
            foreach ($mibs as $m) {
                $output .= '<input type="hidden" name="mibs[]" value="'.encode_form_val($m).'">';
            }

            if (!array_key_exists("oid", $serviceargs) || count($serviceargs["oid"]) == 0) {

                $output .= '
<style>
.error-list > li { padding-bottom: 4px; }
</style>
<p style="margin: 20px 0;"><b>' . _('No results were returned from a scan of the device.') . '</b></p><p>'._('This could be due to one of the following reasons').':</p>
<p>
    <ul class="error-list">';

                $output .= '<li>' . _('No results were found based on the settings provided') . '</li>';
                $output .= '<li>' . sprintf(_('Could not connect to the host (%s) or the port (%s) is unaccessible or blocked by a firewall'), $address, $port) . '</li>';
                $output .= '<li>' . sprintf(_('The snmp scan timed out (timeout currently set to %s seconds)'), $timeout) . '</li>';

                if (!empty($mibs)) {
                    $output .= '<li>' . _('The scan returned results, but did not return any results of the following filtered MIBs you selected (shown below)').'<ul>';
                    foreach ($mibs as $m) {
                        $output .= '<li>'.$m.'</li>';
                    }
                    $output .= '</ul></li>';
                }

                $output .= '</ul></p>';

                // If we returned with an error, display the error message below
                $output .= '<p>' . _('To view the error or full results') . ', <a class="show-error">' . _('view the raw output from the scan') . '</a>.</p>';
                $output .= '<div class="hide error-out"><pre>'.$fcontents.'</pre></div>';

                $output .= '
<p style="margin: 20px 0;">'._('Either').' <a href="javascript: history.go(-1)">'._('go back and change your settings').'</a> '._('or you can').' <a href="javascript:location.reload(true)" id="retry">'._('try re-running the same scan again').'</a>.</p>

<div id="snmpwalk-throbber" class="hide" style="padding-bottom: 120px; z-index: 10000;">
    <div class="message" style="width: 450px;">
        <ul class="infoMessage">
            <li><b>'._('Scanning device. Please wait...').'</b></li>
        </ul>
    </div>
</div>

<script type="text/javascript">
$(document).ready(function() {

    $("#configWizardForm").submit(function(e) {
        whiteout();
        $("#snmpwalk-throbber").center().show();
    });

});
</script>';

            } else {

                $output .= '
<h5 class="ul">'._('Device Details').'</h5>
<table class="table table-condensed table-no-border table-auto-width">
    <tr>
        <td>
            <label>'._('Device Address').':</label>
        </td>
        <td>
            <input type="text" size="40" name="ip_address" id="ip_address" value="' . encode_form_val($address) . '" class="form-control" disabled>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>'._('Host Name').':</label>
        </td>
        <td>
            <input type="text" size="20" name="hostname" id="hostname" value="' . encode_form_val($hostname) . '" class="form-control">
            <div class="subtext">'._('The name you would like to have associated with this server or device.').'</div>
        </td>
    </tr>
</table>

<h5 class="ul">'._('SNMP Services').'</h5>
<p>'._('Select the OIDs you\'d like to monitor via SNMP.').'</p>';

                // Show that we hit the max to the user
                if ($hit_max) {
                    $output .= '<div class="alert alert-info" style="margin: 0;">'.sprintf(_('You have reached the maximum processing limit of %s records. Return to step 1 to adjust the maximum results setting to view more.'), number_format(intval($maxresults))).'</div>';
                }

                // Mib selection
                if (!empty($miblist)) {
                    $output .= '<p>'._('Currently showing OIDs related to the following MIBs:').' <b>'.encode_form_val($miblist).'</b></p>';
                }

                $output .= '
<table class="table table-condensed table-no-border table-auto-width">
    <tr>
        <th>'._('Select').'</th>
        <th>MIB</th>
        <th>OID</th>
        <th>'._('Type').'</th>
        <th>'._('Current Value').'</th>
        <th>'._('Display Name').'</th>
        <th>'._('Data Label').' <i class="fa fa-question-circle fa-14 tt-bind" title="'._('The text that will be displayed before the data (string or number) in the check output.').'"></i></th>
        <th>'._('Data Units').' <i class="fa fa-question-circle fa-14 tt-bind" title="'._('Optional data unit (examples: C, users, load)').'"></i></th>
        <th>'._('Match Type').'</th>
        <th>'._('Thresholds').' <i class="fa fa-question-circle fa-14 tt-bind" title="'._('If a match type is numeric, you must set a warning and critical value. If a match is a string, it must match the string exactly or it will be critical.').'"></i></th>
    </tr>';

                $total = count($serviceargs["oid"]);
                for ($x = 0; $x < $total; $x++) {

                    $string_hide = ' hide';
                    $numeric_hide = ' hide';
                    if ($serviceargs["oid"][$x]["type"] == 'INTEGER') {
                        $serviceargs["oid"][$x]["matchtype"] = 'numeric';
                        $numeric_hide = '';
                    } else if ($serviceargs["oid"][$x]["type"] == 'STRING') {
                        $serviceargs["oid"][$x]["matchtype"] = 'string';
                        $string_hide = '';
                    }

                    $output .= '<tr>
            <td><input type="checkbox" style="margin: 4px auto;" class="checkbox" name="services[oid][' . $x . ']" ' . is_checked($services["oid"][$x]) . '></td>

            <td>'.encode_form_val($serviceargs["oid"][$x]["mib"]).'</td>
            
            <td>
            <input type="text" size="45" name="serviceargs[oid][' . $x . '][oid]" value="' . encode_form_val($serviceargs["oid"][$x]["oid"]) . '" class="form-control">
            <input type="hidden" size="12" name="serviceargs[oid][' . $x . '][mib]" value="' . encode_form_val($serviceargs["oid"][$x]["mib"]) . '">
            </td>

            <td>' . encode_form_val($serviceargs["oid"][$x]["type"]) . '<input type="hidden" name="serviceargs[oid][' . $x . '][type]" value="' . encode_form_val($serviceargs["oid"][$x]["type"]) . '" /></td>
            <td>' . encode_form_val($serviceargs["oid"][$x]["val"]) . '<input type="hidden" name="serviceargs[oid][' . $x . '][val]" value="' . encode_form_val($serviceargs["oid"][$x]["val"]) . '" /></td>
            

            <td><input type="text" size="15" name="serviceargs[oid][' . $x . '][name]" value="' . encode_form_val($serviceargs["oid"][$x]["name"]) . '" class="form-control"></td>
            <td><input type="text" size="10" name="serviceargs[oid][' . $x . '][label]" value="' . encode_form_val($serviceargs["oid"][$x]["label"]) . '" class="form-control"></td>
            <td><input type="text" size="10" name="serviceargs[oid][' . $x . '][units]" value="' . encode_form_val($serviceargs["oid"][$x]["units"]) . '" class="form-control"></td>
            
            <td>
                <select name="serviceargs[oid][' . $x . '][matchtype]" class="form-control match-type">
                    <option value="none" ' . is_selected($serviceargs["oid"][$x]["matchtype"], "none") . '>'._('None').'</option>
                    <option value="numeric" ' . is_selected($serviceargs["oid"][$x]["matchtype"], "numeric") . '>'._('Numeric').'</option>
                    <option value="string" ' . is_selected($serviceargs["oid"][$x]["matchtype"], "string") . '>'._('String').'</option>
                </select>
            </td>
            
            <td>
                <div class="form-inline numeric' . $numeric_hide . '">
                    <div class="input-group">
                        <label class="input-group-addon"><img src="'.theme_image('error.png').'" style="width: 15px;" class="tt-bind" title="'._('Warning Threshold').'"></label>
                        <input type="text" size="4" name="serviceargs[oid][' . $x . '][warning]" value="' . encode_form_val($serviceargs["oid"][$x]["warning"]) . '" class="form-control">
                    </div>
                    <div class="input-group">
                        <label class="input-group-addon"><img src="'.theme_image('critical_small.png').'" style="width: 15px;" class="tt-bind" title="'._('Critical Threshold').'"></label>
                        <input type="text" size="4" name="serviceargs[oid][' . $x . '][critical]" value="' . encode_form_val($serviceargs["oid"][$x]["critical"]) . '" class="form-control">
                    </div>
                </div>
                <input type="text" size="20" name="serviceargs[oid][' . $x . '][string]" value="' . encode_form_val($serviceargs["oid"][$x]["string"]) . '" class="form-control string' . $string_hide . '">
            </td>
            </tr>';
                }

                $output .= '
        </table>';
            }
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:

            // Get variables that were passed to us
            $address = grab_array_var($inargs, "ip_address");
            $hostname = grab_array_var($inargs, "hostname");
            $hostname = nagiosccm_replace_user_macros($hostname);

            $services = grab_array_var($inargs, "services");
            $serviceargs = grab_array_var($inargs, "serviceargs");

            // Check for errors
            $errors = 0;
            $errmsg = array();
            if (is_valid_host_name($hostname) == false) {
                $errmsg[$errors++] = "Invalid host name.";
            }
            if (!array_key_exists("oid", $services) || count($services["oid"]) == 0) {
                $errmsg[$errors++] = "You have not selected any OIDs to monitor.";
            } else {
                foreach ($services["oid"] as $index => $indexval) {
                    // get oid
                    $oid = $index;

                    // skip empty oids
                    if ($oid === "") {
                        continue;
                    }

                    // test match arguments
                    switch ($serviceargs["oid"][$index]["matchtype"]) {
                        case "numeric":
                            if ($serviceargs["oid"][$index]["warning"] == "")
                                $errmsg[$errors++] = "Invalid warning numeric range for OID " . intval($index) . ' (' . encode_form_val($serviceargs["oid"][$index]["oid"]) . ')';
                            if ($serviceargs["oid"][$index]["critical"] == "")
                                $errmsg[$errors++] = "Invalid critical numeric range for OID " . intval($index) . ' (' . encode_form_val($serviceargs["oid"][$index]["oid"]) . ')';
                            break;
                        case "string":
                            if ($serviceargs["oid"][$index]["string"] == "")
                                $errmsg[$errors++] = "Invalid string match for OID " . intval($index) . ' (' . encode_form_val($serviceargs["oid"][$index]["oid"]) . ')';
                            break;
                        default:
                            break;
                    }
                }
            }
            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }

            break;


        case CONFIGWIZARD_MODE_GETSTAGE3HTML:

            // get variables that were passed to us
            $address = grab_array_var($inargs, "ip_address");
            $port = grab_array_var($inargs, "port");
            $hostname = grab_array_var($inargs, "hostname");
            $snmpcommunity = grab_array_var($inargs, "snmpcommunity");
            $snmpversion = grab_array_var($inargs, "snmpversion");
            $oid = grab_array_var($inargs, "oid", "");
            $timeout = grab_array_var($inargs, "timeout", 15);
            $mibs = grab_array_var($inargs, "mibs", array(''));
            $miblist = grab_array_var($inargs, "miblist");

            $services = grab_array_var($inargs, "services");
            $serviceargs = grab_array_var($inargs, "serviceargs");

            $snmpopts_serial = grab_array_var($inargs, "snmpopts_serial", "");
            if ($snmpopts_serial == "")
                $snmpopts = grab_array_var($inargs, "snmpopts");
            else
                $snmpopts = unserialize(base64_decode($snmpopts_serial));

            $output = '
            
        <input type="hidden" name="ip_address" value="' . encode_form_val($address) . '">
        <input type="hidden" name="port" value="' . encode_form_val($port) . '">
        <input type="hidden" name="hostname" value="' . encode_form_val($hostname) . '">
        <input type="hidden" name="snmpcommunity" value="' . encode_form_val($snmpcommunity) . '">
        <input type="hidden" name="snmpversion" value="' . encode_form_val($snmpversion) . '">
        <input type="hidden" name="oid" value="' . encode_form_val($oid) . '">
        <input type="hidden" name="miblist" value="' . encode_form_val($miblist) . '">
        <input type="hidden" name="timeout" value="' . encode_form_val($timeout) . '">
        <input type="hidden" name="services_serial" value="' . base64_encode(serialize($services)) . '">
        <input type="hidden" name="serviceargs_serial" value="' . base64_encode(serialize($serviceargs)) . '">
        <input type="hidden" name="snmpopts_serial" value="' . base64_encode(serialize($snmpopts)) . '">';

            foreach ($mibs as $m) {
                $output .= '<input type="hidden" name="mibs[]" value="'.encode_form_val($m).'">';
            }

            $output .= '<!--SERVICES=' . serialize($services) . '<BR>
                        SERVICEARGS=' . serialize($serviceargs) . '<BR>-->';
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:

            break;

        case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:

            $output = '
            
            ';
            break;

        case CONFIGWIZARD_MODE_GETOBJECTS:

            $hostname = grab_array_var($inargs, "hostname", "");
            $address = grab_array_var($inargs, "ip_address", "");
            $hostaddress = $address;

            $port = grab_array_var($inargs, "port", "");

            $snmpcommunity = grab_array_var($inargs, "snmpcommunity", "");
            $snmpversion = grab_array_var($inargs, "snmpversion", "2c");

            $snmpopts_serial = grab_array_var($inargs, "snmpopts_serial", "");
            $snmpopts = unserialize(base64_decode($snmpopts_serial));

            $services_serial = grab_array_var($inargs, "services_serial", "");
            $serviceargs_serial = grab_array_var($inargs, "serviceargs_serial", "");

            $services = unserialize(base64_decode($services_serial));
            $serviceargs = unserialize(base64_decode($serviceargs_serial));

            // save data for later use in re-entrance
            $meta_arr = array();
            $meta_arr["hostname"] = $hostname;
            $meta_arr["port"] = $port;
            $meta_arr["ip_address"] = $address;
            $meta_arr["snmpcommunity"] = $snmpcommunity;
            $meta_arr["snmpversion"] = $snmpversion;
            $meta_arr["services"] = $services;
            $meta_arr["serivceargs"] = $serviceargs;
            $meta_arr["snmpopts"] = $snmpopts;
            save_configwizard_object_meta($wizard_name, $hostname, "", $meta_arr);

            $objs = array();

            if (!host_exists($hostname)) {
                $objs[] = array(
                    "type" => OBJECTTYPE_HOST,
                    "use" => "xiwizard_genericnetdevice_host",
                    "host_name" => $hostname,
                    "address" => $hostaddress,
                    "icon_image" => "snmp.png",
                    "statusmap_image" => "snmp.png",
                    "_xiwizard" => $wizard_name,
                );
            }

            // see which services we should monitor
            foreach ($services as $svc => $svcstate) {

                //echo "PROCESSING: $svc -> $svcstate<BR>\n";

                switch ($svc) {

                    case "oid":

                        $enabledservices = $svcstate;

                        foreach ($enabledservices as $sid => $sstate) {

                            $oid = $serviceargs["oid"][$sid]["oid"];
                            $name = $serviceargs["oid"][$sid]["name"];
                            $label = $serviceargs["oid"][$sid]["label"];
                            $units = $serviceargs["oid"][$sid]["units"];
                            $matchtype = $serviceargs["oid"][$sid]["matchtype"];
                            $warning = $serviceargs["oid"][$sid]["warning"];
                            $critical = $serviceargs["oid"][$sid]["critical"];
                            $string = $serviceargs["oid"][$sid]["string"];
                            $mib = $serviceargs["oid"][$sid]["mib"];

                            // Strip whitespace from units
                            $units = str_replace(" ", "", $units);

                            $sdesc = $name;

                            $cmdargs = "";
                            // port
                            $cmdargs .= " -p " . intval($port);
                            // oid
                            if ($oid != "")
                                $cmdargs .= " -o " . escapeshellarg($oid);
                            // snmp community
                            if ($snmpcommunity != "" && $snmpversion != "3")
                                $cmdargs .= " -C " . escapeshellarg($snmpcommunity);
                            // snmp version
                            if ($snmpversion != "")
                                $cmdargs .= " -P " . $snmpversion;
                            // snmp v3 stuff
                            if ($snmpversion == "3") {

                                $securitylevel = grab_array_var($snmpopts, "v3_security_level");
                                $username = grab_array_var($snmpopts, "v3_username");
                                $authproto = grab_array_var($snmpopts, "v3_auth_proto");
                                $authpassword = grab_array_var($snmpopts, "v3_auth_password");
                                $privacypassword = grab_array_var($snmpopts, "v3_privacy_password");
                                $privproto = grab_array_var($snmpopts, "v3_priv_proto");

                                if ($securitylevel != "")
                                    $cmdargs .= " --seclevel=" . $securitylevel;
                                if ($username != "")
                                    $cmdargs .= " --secname=" . escapeshellarg($username);
                                if ($authproto != "")
                                    $cmdargs .= " --authproto=" . $authproto;
                                if ($authpassword != "")
                                    $cmdargs .= " --authpasswd=" . escapeshellarg($authpassword);
                                if ($privacypassword != "")
                                    $cmdargs .= " --privpasswd=" . escapeshellarg($privacypassword);
                                if ($privproto != "")
                                    $cmdargs .= " -x " . $privproto;
                            }
                            // label
                            if ($label != "")
                                $cmdargs .= " -l " . escapeshellarg($label);
                            // units
                            if ($units != "")
                                $cmdargs .= " -u " . escapeshellarg($units);
                            // mib
                            if ($mib != "")
                                $cmdargs .= " -m " . $mib;
                            // match type...
                            switch ($matchtype) {
                                case "numeric":
                                    if ($warning != "")
                                        $cmdargs .= " -w " . $warning;
                                    if ($critical != "")
                                        $cmdargs .= " -c " . $critical;
                                    break;
                                case "string":
                                    if ($string != "")
                                        $cmdargs .= " -r " . escapeshellarg($string);
                                    break;
                                default:
                                    break;
                            }

                            // make sure we have a service name
                            if ($sdesc == "")
                                $sdesc = $oid;

                            $objs[] = array(
                                "type" => OBJECTTYPE_SERVICE,
                                "host_name" => $hostname,
                                "service_description" => $sdesc,
                                "use" => "xiwizard_snmp_service",
                                "check_command" => "check_xi_service_snmp!" . $cmdargs,
                                "_xiwizard" => $wizard_name,
                            );
                        }
                        break;


                    default:
                        break;
                }
            }

            //echo "OBJECTS:<BR>";
            //print_r($objs);
            //exit();

            // return the object definitions to the wizard
            $outargs[CONFIGWIZARD_NAGIOS_OBJECTS] = $objs;

            break;

        default:
            break;
    }

    return $output;
}
