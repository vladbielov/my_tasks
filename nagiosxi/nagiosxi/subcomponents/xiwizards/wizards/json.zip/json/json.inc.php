<?php
//
// JSON Config Wizard
// Copyright (c) 2020 Nagios Enterprises, LLC. All rights reserved.
//
// "Party... Party hard" -CD
//


include_once(dirname(__FILE__) . '/../configwizardhelper.inc.php');


json_configwizard_init();

function json_configwizard_init()
{
    $name = "json";
    $args = array(
        CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "1.0.0",
        CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
        CONFIGWIZARD_DESCRIPTION => _("Monitor JSON data output from a URL or API.") . '<div class="hide">REST API</div>',
        CONFIGWIZARD_DISPLAYTITLE => _("JSON"),
        CONFIGWIZARD_FUNCTION => "json_configwizard_func",
        CONFIGWIZARD_PREVIEWIMAGE => "json.png",
        CONFIGWIZARD_COPYRIGHT => "Copyright &copy; 2020 Nagios Enterprises, LLC.",
        CONFIGWIZARD_AUTHOR => "Nagios Enterprises, LLC",
        CONFIGWIZARD_FILTER_GROUPS => array('website', 'xml', 'api'),
        CONFIGWIZARD_REQUIRES_VERSION => 5700
    );
    register_configwizard($name, $args);
}


/**
 * @param string $mode
 * @param        $inargs
 * @param        $outargs
 * @param        $result
 *
 * @return string
 */
function json_configwizard_func($mode = "", $inargs, &$outargs, &$result)
{
    $wizard_name = "json";

    // Initialize return code and output
    $result = 0;
    $output = "";

    // Initialize output args - pass back the same data we got
    $outargs[CONFIGWIZARD_PASSBACK_DATA] = $inargs;

    switch ($mode) {
        case CONFIGWIZARD_MODE_GETSTAGE1HTML:

            $address = grab_array_var($inargs, "address", "");
            $port = grab_array_var($inargs, "port", "");

            $output = '
<h5 class="ul">' . _('Server Information') . '</h5>
<table class="table table-condensed table-no-border table-auto-width">
    <tr>
        <td class="vt">
            <label>' . _('Server Address') . ':</label>
        </td>
        <td>
            <input type="text" size="40" name="address" id="address" value="' . encode_form_val($address) . '" class="form-control">
            <div class="subtext">' . _('The IP address or fully qualified DNS name of the server you\'d like to monitor.') . '</div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>' . _('Server Port') . ':</label>
        </td>
        <td>
            <input type="text" size="5" name="port" id="port" value="' . encode_form_val($port) . '" class="form-control">
            <div class="subtext">' . _('<b>Optional</b> - The port the server is listening on. Defaults to port 80.') . '</div>
        </td>
    </tr>
</table>';
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:

            // Get variables that were passed to us
            $address = grab_array_var($inargs, "address", "");
            $address = nagiosccm_replace_user_macros($address);

            $port = grab_array_var($inargs, "port", "");

            // Check for errors
            $errors = 0;
            $errmsg = array();

            if (empty($address)) {
                $errmsg[$errors++] = _("No address specified.");
            }

            if (!empty($port) && !is_numeric($port)) {
                $errmsg[$errors++] = _("Invalid port number.");
            }

            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }

            break;

        case CONFIGWIZARD_MODE_GETSTAGE2HTML:

            // Get variables that were passed to us
            $address = grab_array_var($inargs, "address");
            $port = grab_array_var($inargs, "port", "");
            $ha = @gethostbyaddr($address);
            if ($ha == "")
                $ha = $address;
            $hostname = grab_array_var($inargs, "hostname", $ha);

            $services = grab_array_var($inargs, "services", array());
            $services_serial = grab_array_var($inargs, "services_serial");
            if ($services_serial != "") {
                $services = unserialize(base64_decode($services_serial));
            }

            // Integer checks
            if (!array_key_exists("integer_check", $services))
                $services["integer_check"] = array();
            for ($x = 0; $x < 1; $x++) {
                if (!array_key_exists($x, $services["integer_check"]))
                    $services["integer_check"][$x] = array();
                if (!array_key_exists("url", $services["integer_check"][$x]))
                    $services["integer_check"][$x]["url"] = "";
                if (!array_key_exists("key", $services["integer_check"][$x]))
                    $services["integer_check"][$x]["key"] = "";
                if (!array_key_exists("warning", $services["integer_check"][$x]))
                    $services["integer_check"][$x]["warning"] = "";
                if (!array_key_exists("critical", $services["integer_check"][$x]))
                    $services["integer_check"][$x]["critical"] = "";
                if (!array_key_exists("header", $services["integer_check"][$x]))
                    $services["integer_check"][$x]["header"] = "";
            }
            
            // String checks
            if (!array_key_exists("string_check", $services))
                $services["string_check"] = array();
            for ($x = 0; $x < 1; $x++) {
                if (!array_key_exists($x, $services["string_check"]))
                    $services["string_check"][$x] = array();
                if (!array_key_exists("url", $services["string_check"][$x]))
                    $services["string_check"][$x]["url"] = "";
                if (!array_key_exists("key", $services["string_check"][$x]))
                    $services["string_check"][$x]["key"] = "";
                if (!array_key_exists("string", $services["string_check"][$x]))
                    $services["string_check"][$x]["string"] = "";
                if (!array_key_exists("result_code_if_match", $services["string_check"][$x]))
                    $services["string_check"][$x]["result_code_if_match"] = 0;
                if (!array_key_exists("result_code_if_no_match", $services["string_check"][$x]))
                    $services["string_check"][$x]["result_code_if_no_match"] = 2;
            }

            $output = '
<input type="hidden" name="address" value="' . encode_form_val($address) . '">
<input type="hidden" name="port" value="' . encode_form_val($port) . '">

<h5 class="ul">' . _('Server Information') . '</h5>
<table class="table table-condensed table-no-border table-auto-width">
    <tr>
        <td>
            <label>' . _('Server Address') . ':</label>
        </td>
        <td>
            <input type="text" size="40" name="address" id="address" value="' . encode_form_val($address) . '" class="form-control" disabled>
        </td>
    </tr>
    <tr>
        <td>
            <label>' . _('Host Name') . ':</label>
        </td>
        <td>
            <input type="text" size="20" name="hostname" id="hostname" value="' . encode_form_val($hostname) . '" class="form-control">
            <div class="subtext">' . _('The host name you\'d like to have associated with this server.') . '</div>
        </td>
    </tr>
</table>

<div style="margin: 20px 0;">
    <h5 class="ul">' . _('Integer Value Checks') . '</h5>
    <p>' . _('Fill in fields to create services that checks the value of field containing an integer.') . '</p>
    <table class="adddeleterow table table-condensed table-no-border table-auto-width" style="margin-bottom: 10px;">
        <thead>
            <tr>
                <th>' . _('Service Description') . '</th>
                <th>' . _('URL') . '</th>
                <th>' . _('Key') . ' <i class="fa fa-question-circle pop" data-content="' . _('The key can be used the same way as a JavaScript variable, some examples:').'<br><code>list[5].host_status</code><br><code>object.health.status_code</code><br><code>temperature</code>"></i></th>
                <th>' . _('Thresholds') . '</th>
                <th>' . _('Additional Header') . '</th>
            </tr>
        </thead>
        <tbody>';

            for ($x = 0; $x < count($services["integer_check"]); $x++) {

                $output .= '<tr>';

                $output .= '<td><input type="text" size="20" name="services[integer_check][' . $x . '][desc]" id="string_check_desc' . $x . '" value="' . encode_form_val($services["integer_check"][$x]["desc"]) . '" class="form-control"></td>';

                $output .= '<td><input type="text" size="50" name="services[integer_check][' . $x . '][url]" id="integer_check_url' . $x . '" value="' . encode_form_val($services["integer_check"][$x]["url"]) . '" class="form-control"></td>';

                $output .= '<td><input type="text" size="30" name="services[integer_check][' . $x . '][key]" id="integer_check_key' . $x . '" value="' . encode_form_val($services["integer_check"][$x]["key"]) . '" class="form-control"></td>';

                $output .= '<td>
                                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>
                                <input type="text" size="6" name="services[integer_check][' . $x . '][warning]" id="integer_check_warning' . $x . '" value="' . encode_form_val($services["integer_check"][$x]["warning"]) . '" class="form-control">
                                <label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>
                                <input type="text" size="6" name="services[integer_check][' . $x . '][critical]" id="integer_check_critical' . $x . '" value="' . encode_form_val($services["integer_check"][$x]["critical"]) . '" class="form-control">
                            </td>';

                $output .= '<td><input type="text" size="30" name="services[integer_check][' . $x . '][header]" id="integer_check_header' . $x . '" value="' . encode_form_val($services["integer_check"][$x]["header"]) . '" class="form-control"></td>';

                $output .= '</tr>';

            }

            $output .= '
        </tbody>
    </table>
</div>

<div style="margin: 20px 0;">
    <h5 class="ul">' . _('String Match Checks') . '</h5>
    <p>' . _('Fill in fields to create a service that checks the value of field containing a string.') . '</p>
    <table class="adddeleterow table table-condensed table-no-border table-auto-width" style="margin-bottom: 10px;">
        <thead>
            <tr>
                <th>' . _('Service Description') . '</th>
                <th>' . _('URL') . '</th>
                <th>' . _('Key') . ' <i class="fa fa-question-circle pop" data-content="' . _('The key can be used the same way as a JavaScript variable, some examples:').'<br><code>list[5].host_status</code><br><code>object.health.status_code</code><br><code>tempurature</code>"></i></th>
                <th>' . _('String') . ' <i class="fa fa-question-circle pop" data-content="' . _('String matches are exact match only. The full string must be found to be a match.').'"></i></th>
                <th>' . _('Match Found') . '</th>
                <th>' . _('Match Not Found') . '</th>
                <th>' . _('Additional Header') . '</th>
            </tr>
        </thead>
        <tbody>';

            for ($x = 0; $x < count($services["string_check"]); $x++) {

                $output .= '<tr>';

                $output .= '<td><input type="text" size="20" name="services[string_check][' . $x . '][desc]" id="string_check_desc' . $x . '" value="' . encode_form_val($services["string_check"][$x]["desc"]) . '" class="form-control"></td>';

                $output .= '<td><input type="text" size="50" name="services[string_check][' . $x . '][url]" id="string_check_url' . $x . '" value="' . encode_form_val($services["string_check"][$x]["url"]) . '" class="form-control"></td>';

                $output .= '<td><input type="text" size="30" name="services[string_check][' . $x . '][key]" id="string_check_key' . $x . '" value="' . encode_form_val($services["string_check"][$x]["key"]) . '" class="form-control"></td>';

                $output .= '<td><input type="text" size="20" name="services[string_check][' . $x . '][string]" id="string_check_string' . $x . '" value="' . encode_form_val($services["string_check"][$x]["string"]) . '" class="form-control"></td>';
                
                $output .= '<td>
                    <select name="services[string_check][' . $x . '][result_code_if_match]" class="form-control">
                        <option value="0" '.is_selected(0, $services["string_check"][$x]["result_code_if_match"]).'>OK</option>
                        <option value="1" '.is_selected(1, $services["string_check"][$x]["result_code_if_match"]).'>WARNING</option>
                        <option value="2" '.is_selected(2, $services["string_check"][$x]["result_code_if_match"]).'>CRITICAL</option>
                        <option value="3" '.is_selected(3, $services["string_check"][$x]["result_code_if_match"]).'>UNKNOWN</option>
                    </select>
                </td>';

                $output .= '<td>
                    <select name="services[string_check][' . $x . '][result_code_if_no_match]" class="form-control">
                        <option value="0" '.is_selected(0, $services["string_check"][$x]["result_code_if_no_match"]).'>OK</option>
                        <option value="1" '.is_selected(1, $services["string_check"][$x]["result_code_if_no_match"]).'>WARNING</option>
                        <option value="2" '.is_selected(2, $services["string_check"][$x]["result_code_if_no_match"]).'>CRITICAL</option>
                        <option value="3" '.is_selected(3, $services["string_check"][$x]["result_code_if_no_match"]).'>UNKNOWN</option>
                    </select>
                </td>';

                $output .= '<td><input type="text" size="30" name="services[string_check][' . $x . '][header]" id="string_check_header' . $x . '" value="' . encode_form_val($services["string_check"][$x]["header"]) . '" class="form-control"></td>';

                $output .= '</tr>';

            }

            $output .= '
        </tbody>
    </table>
</div>';
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:

            // get variables that were passed to us
            $address = grab_array_var($inargs, "address");
            $hostname = grab_array_var($inargs, "hostname");
            $hostname = nagiosccm_replace_user_macros($hostname);

            $services = grab_array_var($inargs, "services");
            $port = grab_array_var($inargs, "port", "");

            // check for errors
            $errors = 0;
            $integer_errors = 0;
            $string_errors = 0;
            
            $errmsg = array();
            $integer_errmsg = array();
            $string_errmsg = array();
            
            $integer_config == NULL;
            $string_config == NULL; 
        
            if (is_valid_host_name($hostname) == false)
                $errmsg[$errors++] = _("Invalid host name.");
            
            // integer_check_
                        
            foreach ($services["integer_check"] as $id => $portarr) {

                $url = grab_array_var($portarr, "url", "");
                $key = grab_array_var($portarr, "key", "");
                $warning = grab_array_var($portarr, "warning", "");
                $critical = grab_array_var($portarr, "critical", "");

                if ( isset($url) || isset($key) || isset($warning) || isset($critical) || isset($header) ) {
                    if ( !isset($url) || !isset($key) || !isset($warning) || !isset($critical) ){
                        $integer_errmsg[$integer_errors++] = _("Invalid integer service check configured.");
                    } else {
                        $integer_config = 1;
                    }
                }
            }
            
            
            // string_check_

            foreach ($services["string_check"] as $id => $portarr) {

                $url = grab_array_var($portarr, "url", "");
                $key = grab_array_var($portarr, "key", "");
                $string = grab_array_var($portarr, "string", "");
                $result_code_if_match = grab_array_var($portarr, "result_code_if_match", "");
                $result_code_if_no_match = grab_array_var($portarr, "result_code_if_no_match", "");
                        
                if ( isset($url) || isset($key) || isset($string) || isset($result_code_if_match) || isset($result_code_if_no_match) || isset($header) ) {
                    if ( !isset($url) || !isset($key) || !isset($string) || !isset($result_code_if_match) || !isset($result_code_if_no_match) ){
                        $string_errmsg[$string_errors++] = _("Invalid string service check configured");
                    } else {
                        $string_config = 1;
                    }
                }
            }
            
            if ($integer_config == NULL && $string_config == NULL ) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = _("Must configure at least one service check");
                $result = 1;
            }
            
            if ($errors > 0 || $integer_errors > 0|| $string_errors > 0 ) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = array_merge($errmsg, $integer_errmsg, $string_errmsg);
                $result = 1;
            }
            
            break;


        case CONFIGWIZARD_MODE_GETSTAGE3HTML:

            // get variables that were passed to us
            $address = grab_array_var($inargs, "address");
            $hostname = grab_array_var($inargs, "hostname");
            $services = grab_array_var($inargs, "services");
            $serviceargs = grab_array_var($inargs, "serviceargs");
            $port = grab_array_var($inargs, "port", "");
            
            $services_serial = grab_array_var($inargs, "services_serial", base64_encode(serialize($services)));
            $serviceargs_serial = grab_array_var($inargs, "serviceargs_serial", base64_encode(serialize($serviceargs)));
            
            $output = '
            
        <input type="hidden" name="address" value="' . encode_form_val($address) . '">
        <input type="hidden" name="hostname" value="' . encode_form_val($hostname) . '">
        <input type="hidden" name="services_serial" value="' . $services_serial . '">
        <input type="hidden" name="serviceargs_serial" value="' . $serviceargs_serial . '">
        <input type="hidden" name="port" value="' . encode_form_val($port) . '">
        
        
            ';
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:

            break;

        case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:

            $output = '
            
            ';
            break;

        case CONFIGWIZARD_MODE_GETOBJECTS:

            $address = grab_array_var($inargs, "address", "");
            $hostname = grab_array_var($inargs, "hostname", "");
            $port = grab_array_var($inargs, "port", "");
            
            $services_serial = grab_array_var($inargs, "services_serial", "");
            $serviceargs_serial = grab_array_var($inargs, "serviceargs_serial", "");

            $services = unserialize(base64_decode($services_serial));
            $serviceargs = unserialize(base64_decode($serviceargs_serial));

            $hostaddress = $address;

            // save data for later use in re-entrance
            $meta_arr = array();
            $meta_arr["hostname"] = $hostname;
            $meta_arr["address"] = $address;
            $meta_arr["services"] = $services;
            $meta_arr["serivceargs"] = $serviceargs;
            $meta_arr["port"] = $port;
            
            save_configwizard_object_meta($wizard_name, $hostname, "", $meta_arr);

            $objs = array();

            if (!host_exists($hostname)) {

                // Choose the port for check_tcp
                $tmp_port = $port;
                if ($port == "") {
                    $tmp_port = "80";
                }

                $objs[] = array(
                    "type" => OBJECTTYPE_HOST,
                    "use" => "xiwizard_json_host",
                    "host_name" => $hostname,
                    "address" => $hostaddress,
                    "icon_image" => "json.png",
                    "statusmap_image" => "json.png",
                    "check_command" => "check_tcp!$tmp_port!",
                    "_xiwizard" => $wizard_name,
                );
            }

            // configure integer checks
            if (array_key_exists("integer_check", $services)) {
                foreach ($services["integer_check"] as $id => $svc_arr) {

                    $url = grab_array_var($svc_arr, "url", "");
                    $key = grab_array_var($svc_arr, "key", "");
                    $desc = grab_array_var($svc_arr, "desc", $key);
                    $warning = grab_array_var($svc_arr, "warning", "");
                    $critical = grab_array_var($svc_arr, "critical", "");
                    $header = grab_array_var($svc_arr, "header", "");

                    if (empty($desc) || empty($url)) {
                        continue;
                    }

                    $args = "-u " . escapeshellarg($url) . " -k " . escapeshellarg($key);
                    if (!empty($header)) {
                        $args .= " -h " . escapeshellarg($header);
                    }

                    $args .= " -w " . intval($warning) . " -c " . intval($critical);

                    $use = "xiwizard_json_service";
                    $check_command = "check_json!" . $args;
                    
                    $objs[] = array(
                        "type" => OBJECTTYPE_SERVICE,
                        "host_name" => $hostname,
                        "service_description" => $desc,
                        "use" => $use,
                        "check_command" => $check_command,
                        "_xiwizard" => $wizard_name,
                    );
                }
            }

            // configure string checks
            if (array_key_exists("string_check", $services)) {
                foreach ($services["string_check"] as $id => $svc_arr) {

                    $url = grab_array_var($svc_arr, "url", "");
                    $key = grab_array_var($svc_arr, "key", "");
                    $desc = grab_array_var($svc_arr, "desc", $key);
                    $string = grab_array_var($svc_arr, "string", "");
                    $result_code_if_match = grab_array_var($svc_arr, "result_code_if_match", 0);
                    $result_code_if_no_match = grab_array_var($svc_arr, "result_code_if_no_match", 0);
                    $header = grab_array_var($svc_arr, "header", "");

                    if (empty($desc) || empty($url)) {
                        continue;
                    }

                    $args = "-u " . escapeshellarg($url) . " -k " . escapeshellarg($key);
                    if (!empty($header)) {
                        $args .= " -h " . escapeshellarg($header);
                    }

                    $args .= " -s " . escapeshellarg($string) . " -r " . intval($result_code_if_match) . " -n " . intval($result_code_if_no_match); 

                    $use = "xiwizard_json_service";
                    $check_command = "check_json!" . $args;
                    
                    $objs[] = array(
                        "type" => OBJECTTYPE_SERVICE,
                        "host_name" => $hostname,
                        "service_description" => $desc,
                        "use" => $use,
                        "check_command" => $check_command,
                        "_xiwizard" => $wizard_name,
                    );
                }
            }
            
            // return the object definitions to the wizard
            $outargs[CONFIGWIZARD_NAGIOS_OBJECTS] = $objs;

            break;

        default:
            break;
    }

    return $output;
}