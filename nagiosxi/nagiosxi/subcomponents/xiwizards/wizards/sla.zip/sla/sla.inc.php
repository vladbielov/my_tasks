<?php
//
// SLA Config Wizard
// Copyright (c) 2016-2018 Nagios Enterprises, LLC. All rights reserved.
//

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');


// Run the initialization function
sla_configwizard_init();


function sla_configwizard_init()
{
    $name = "sla";
    $args = array(
        CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "1.3.4",
        CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
        CONFIGWIZARD_DESCRIPTION => _("Monitor host and service Service Level Agreements (SLA) to ensure they are met."),
        CONFIGWIZARD_DISPLAYTITLE => _("SLA"),
        CONFIGWIZARD_FUNCTION => "sla_configwizard_func",
        CONFIGWIZARD_PREVIEWIMAGE => "sla.png",
        CONFIGWIZARD_FILTER_GROUPS => array('nagios'),
        CONFIGWIZARD_REQUIRES_VERSION => 5500
    );
    register_configwizard($name,$args);
}


/**
 * Check pre-reqs for configuration wizard
 *
 * @return  array   Array of errors
 */
function sla_configwizard_check_prereqs()
{
    $errors = array();
    if (!file_exists("/usr/local/nagios/libexec/check_xi_sla.php")) {
        $errors[] = _('It looks like you are missing check_xi_sla.php on your Nagios XI server. To use this wizard you must install the check_xi_sla.php plugin on your server located in the this wizards plugin directory here: /usr/local/nagios/libexec/');
    }
    return $errors;
}


/**
 * @param   string  $mode
 * @param   null    $inargs
 * @param           $outargs
 * @param           $result
 * @return  string
 */
function sla_configwizard_func($mode = "", $inargs = null, &$outargs, &$result)
{
    global $db_tables;
    $wizard_name = "sla";

    // Initialize return code and output
    $result = 0;
    $output = "";

    // Initialize output args - pass back the same data we got
    $outargs[CONFIGWIZARD_PASSBACK_DATA] = $inargs;

    switch ($mode) {

        case CONFIGWIZARD_MODE_GETSTAGE1HTML:
            $reportperiod = grab_array_var($inargs, "reportperiod", "24h");
            $custom_reportperiod = grab_array_var($inargs, "custom_reportperiod", "");
            $custom_reportperiod_unit = grab_array_var($inargs, "custom_reportperiod_unit", "h");
            $advanced = grab_array_var($inargs, "advanced", array());
            $errors = sla_configwizard_check_prereqs();

            if (!is_array($advanced)) {
                $advanced = unserialize(base64_decode($advanced));
            }

            if ($errors) {

                $output .= '<div class="message"><ul class="errorMessage">';
                foreach($errors as $error) {
                    $output .= "<li><p>$error</p></li>";
                }
                $output .= '</ul></div>';

            } else {

                $services = grab_array_var($inargs, "services", array());
                $serviceargs = grab_array_var($inargs, "serviceargs", array());

                $output = '
                <script type="text/javascript">
                $(document).ready(function() {
                    $("#reportperiodDropdown").change(function() {
                        if ($(this).val() == "custom") {
                            $(".custom-timeperiod").show();
                        } else {
                            $(".custom-timeperiod").hide();
                        }
                    });
                });
                </script>

                <h5 class="ul">' . _('SLA Report Settings') . '</h5>
                <p>' . _('Select the settings for the SLA report to run. Remember, every time you run the check it will use these settings.') . '</p>

                <table class="table table-condensed table-no-border table-auto-width">
                    <tbody>
                        <tr>
                            <td class="vt"><label>' . _("Report Period") . '</label></td>
                            <td>
                                <select id="reportperiodDropdown" name="reportperiod" class="form-control">
                                    <option value="24h"'.($reportperiod == '24h' ? ' selected="selected"' : '').'>' . _("Last 24 Hours") . '</option>
                                    <option value="7d"'.($reportperiod == '7d' ? ' selected="selected"' : '').'>' . _("Last 7 Days") . '</option>
                                    <option value="1M"'.($reportperiod == '1M' ? ' selected="selected"' : '').'>' . _("Last Month") . '</option>
                                    <option value="custom"'.($reportperiod == 'custom' ? ' selected="selected"' : '').'>' . _("Custom") . '</option>
                                </select>
                                <span class="custom-timeperiod'.($reportperiod != 'custom' ? ' hide' : '').'" style="margin-top: 10px;">
                                    <input type="text" name="custom_reportperiod" style="width: 40px;" value="'.$custom_reportperiod.'" class="form-control">
                                    <select name="custom_reportperiod_unit" class="form-control">
                                        <option value="m"'.($custom_reportperiod_unit == 'm' ? ' selected="selected"' : '').'>' . _("Minutes") .'</option>
                                        <option value="h"'.($custom_reportperiod_unit == 'h' ? ' selected="selected"' : '').'>' . _("Hours") .'</option>
                                        <option value="d"'.($custom_reportperiod_unit == 'd' ? ' selected="selected"' : '').'>' . _("Days") .'</option>
                                        <option value="M"'.($custom_reportperiod_unit == 'M' ? ' selected="selected"' : '').'>' . _("Months") .'</option>
                                    </select>
                                </span>
                            </td>
                        </tr>
                    </tbody>
                </table>

                <h5 class="ul">' . _('SLA Report Advanced Settings') . '</h5>
                <p>' . _('These are settings used to manipulate the way SLA data is reported and received. These settings will apply to all services in the wizard') . '.</p>

                <table class="table table-condensed table-no-border table-auto-width form-inline">
                <tbody>
                    <tr>
                        <td>
                            <div class="form-group">
                                ' . _("Assume Initial States") . '
                                <select name="advanced[assumeinitialstates]" class="form-control">
                                    <option value="yes"'.(isset($advanced['assumeinitialstates']) && $advanced["assumeinitialstates"] == "yes" ? ' selected="selected"' : '').'>' . _("Yes") . '</option>
                                    <option value="no"'.(isset($advanced['assumeinitialstates']) && $advanced["assumeinitialstates"] == "no" ? ' selected="selected"' : '').'>' .  _("No") . '</option>
                                </select>
                            </div>
                            <div style="float: left; margin-right: 10px; padding-bottom: 10px;">
                                ' . _("Assume State Retention") . '
                                <select name="advanced[assumestateretention]" class="form-control">
                                    <option value="yes"'.(isset($advanced['assumestateretention']) && $advanced["assumestateretention"] == "yes" ? ' selected="selected"' : '').'>' . _("Yes") . ' </option>
                                    <option value="no"'.(isset($advanced['assumestateretention']) && $advanced["assumestateretention"] == "no" ? ' selected="selected"' : '').'>' . _("No") . ' </option>
                                </select>
                            </div>
                            <div style="float: left; margin-right: 10px; padding-bottom: 10px;">
                                ' . _("Assume States During Program Downtime") . '
                                <select name="advanced[assumestatesduringdowntime]" class="form-control">
                                    <option value="yes"'.(isset($advanced['assumestatesduringdowntime']) && $advanced["assumestatesduringdowntime"] == "yes" ? ' selected="selected"' : '').'>' . _("Yes") . ' </option>
                                    <option value="no"'.(isset($advanced['assumestatesduringdowntime']) && $advanced["assumestatesduringdowntime"] == "no" ? ' selected="selected"' : '').'>' . _("No") . ' </option>
                                </select>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div style="float: left; margin-right: 10px; padding-bottom: 10px;">
                                ' . _("Include Soft States") . '
                                <select name="advanced[includesoftstates]" class="form-control">
                                    <option value="no"'.(isset($advanced['includesoftstates']) && $advanced["includesoftstates"] == "no" ? ' selected="selected"' : '').'>' . _("No") . ' </option>
                                    <option value="yes"'.(isset($advanced['includesoftstates']) && $advanced["includesoftstates"] == "yes" ? ' selected="selected"' : '').'>' . _("Yes") . ' </option>
                                </select>
                            </div>
                            <div style="float: left; margin-right: 10px; padding-bottom: 10px;">
                                ' . _("First Assumed Host State") . '
                                <select name="advanced[assumedhoststate]" class="form-control">
                                    <option value="0"'.(isset($advanced['assumedhoststate']) && $advanced["assumedhoststate"] == 0 ? ' selected="selected"' : '').'>' . _("Unspecified") . ' </option>
                                    <option value="-1"'.(isset($advanced['assumedhoststate']) && $advanced["assumedhoststate"] == -1 ? ' selected="selected"' : '').'>' . _("Current State") . ' </option>
                                    <option value="3"'.(isset($advanced['assumedhoststate']) && $advanced["assumedhoststate"] == 3 ? ' selected="selected"' : '').'>' . _("Host Up") . ' </option>
                                    <option value="4"'.(isset($advanced['assumedhoststate']) && $advanced["assumedhoststate"] == 4 ? ' selected="selected"' : '').'>' . _("Host Down") . ' </option>
                                    <option value="5"'.(isset($advanced['assumedhoststate']) && $advanced["assumedhoststate"] == 5 ? ' selected="selected"' : '').'>' . _("Host Unreachable") . ' </option>
                                </select>
                            </div>
                            <div style="float: left; margin-right: 10px; padding-bottom: 10px;">
                                ' . _("First Assumed Service State") . '
                                <select name="advanced[assumedservicestate]" class="form-control">
                                    <option value="0"'.(isset($advanced['assumedservicestate']) && $advanced["assumedservicestate"] == 0 ? ' selected="selected"' : '').'>' . _("Unspecified") . ' </option>
                                    <option value="-1"'.(isset($advanced['assumedservicestate']) && $advanced["assumedservicestate"] == -1 ? ' selected="selected"' : '').'>' . _("Current State") . ' </option>
                                    <option value="6"'.(isset($advanced['assumedservicestate']) && $advanced["assumedservicestate"] == 6 ? ' selected="selected"' : '').'>' . _("Service Ok") . ' </option>
                                    <option value="7"'.(isset($advanced['assumedservicestate']) && $advanced["assumedservicestate"] == 7 ? ' selected="selected"' : '').'>' . _("Service Warning") . ' </option>
                                    <option value="8"'.(isset($advanced['assumedservicestate']) && $advanced["assumedservicestate"] == 8 ? ' selected="selected"' : '').'>' . _("Service Unknown") . ' </option>
                                    <option value="9"'.(isset($advanced['assumedservicestate']) && $advanced["assumedservicestate"] == 9 ? ' selected="selected"' : '').'>' . _("Service Critical") . ' </option>
                                </select>
                            </div>
                        </td>
                    </tr>
                </tbody>
                </table>';
            }
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:

            // Get variables that were passed to us
            $reportperiod = grab_array_var($inargs, "reportperiod", "24h");
            $custom_reportperiod = grab_array_var($inargs, "custom_reportperiod", "");
            $custom_reportperiod_unit = grab_array_var($inargs, "custom_reportperiod_unit", "");
            $advanced = grab_array_var($inargs, "advanced", array());

            // Check for errors
            $errors = 0;
            $errmsg = array();

            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }

            break;

        case CONFIGWIZARD_MODE_GETSTAGE2HTML:

            // get variables that were passed to us
            $username = grab_array_var($inargs, "username", "");
            $hostname = grab_array_var($inargs, "hostname", _("SLA"));
            $reportperiod = grab_array_var($inargs, "reportperiod", "24h");
            $custom_reportperiod = grab_array_var($inargs, "custom_reportperiod", "");
            $custom_reportperiod_unit = grab_array_var($inargs, "custom_reportperiod_unit", "");
            $advanced = grab_array_var($inargs, "advanced", array());
            $warning = grab_array_var($inargs, "warning", "");
            $critical = grab_array_var($inargs, "critical", "");

            if (!is_array($advanced)) {
                $advanced = unserialize(base64_decode($advanced));
            }

            // Get display report period
            $displayreportperiod = _("Last 24 Hours");
            if ($reportperiod == '7d') {
                $displayreportperiod = _("Last 7 Days");
            } else if ($reportperiod == '1M') {
                $displayreportperiod = _("Last Month");
            } else if ($reportperiod == 'custom') {
                $displayreportperiod = _("Last").' '.$custom_reportperiod;
                if ($custom_reportperiod_unit == "m") {
                    $displayreportperiod .= " "._("Minutes");
                } else if ($custom_reportperiod_unit == "h") {
                    $displayreportperiod .= " "._("Hours");
                } else if ($custom_reportperiod_unit == "d") {
                    $displayreportperiod .= " "._("Days");
                } else {
                    $displayreportperiod .= " "._("Months");
                }
            }

            // Initialize container vars for form
            $host = "";
            $service = "";
            $hostgroup = "";
            $servicegroup = "";

            // If no serialized data, use current request data
            $services = "";
            $services_serial = grab_array_var($inargs, "services_serial", "");

            if (!empty($services_serial))
                $services = unserialize(base64_decode($services_serial));

            $serviceargs = "";
            $serviceargs_serial = grab_array_var($inargs, "serviceargs_serial", "");

            if (!empty($serviceargs_serial)) 
                $serviceargs = unserialize(base64_decode($serviceargs_serial));

            // Check if retention data available
            if (!is_array($services) && !is_array($serviceargs)) {
                // Initialize services array variables
                $services_default = grab_array_var($inargs, "services", array(
                    "host" => array(),
                    "service" => array(),
                    "hostgroup" => array(),
                    "servicegroup" => array()
                ));

                $services = grab_array_var($inargs, "services", $services_default);
                $services_serial = base64_encode(serialize($services));

                // Initialize serviceargs array variables
                $serviceargs_default = array(
                    "host" => array(),
                    "service" => array(),
                    "hostgroup" => array(),
                    "servicegroup" => array(),
                    "advanced" => array(
                        "assumeinitialstates" => "yes",
                        "assumestateretention" => "yes",
                        "assumestatesduringdowntime" => "yes",
                        "includesoftstates" => "no",
                        "asssumehs" => 3,
                        "asssumess" => 6
                    )
                );

                $serviceargs = grab_array_var($inargs, "serviceargs", $serviceargs_default);

                foreach ($services as $svc => $val) {
                    for ($x = 0; $x < 2; $x++) {
                        if (!array_key_exists($x, $services))
                            $services[$svc][$x] = 'off';

                        if (!array_key_exists($x, $services)) {
                            $serviceargs[$svc][$x] = array(
                                $svc => $svc,
                                "username" => $username,
                                "warning" => "",
                                "critical" => ""
                            );
                        }
                    }
                }

                $serviceargs_serial = base64_encode(serialize($serviceargs));
            } else {
                foreach ($services as $svc => $val) {
                    $limiter = count($services[$svc]);
                    for ($x = 0; $x < $limiter; $x++) {
                        if (!array_key_exists($x, $services)) {
                            $services[$svc][$x] = $val;
                        }

                        if (!array_key_exists($x, $serviceargs)) {
                            foreach ($serviceargs[$svc][$x] as $key => $value) {
                                $serviceargs[$svc][$x][$key] = $value;
                            }
                        }
                    }
                }
            }

            $output = '
        <input type="hidden" name="hostname" value="' . encode_form_val($hostname) . '" />
        <input type="hidden" name="username" value="' . $username . '" />
        <input type="hidden" name="reportperiod" value="' . $reportperiod . '" />
        <input type="hidden" name="custom_reportperiod" value="' . $custom_reportperiod . '" />
        <input type="hidden" name="custom_reportperiod_unit" value="' . $custom_reportperiod_unit . '" />
        <input type="hidden" name="advanced" value="' . base64_encode(serialize($advanced)) . '" />
        <input type="hidden" name="warning" value="' . $warning . '" />
        <input type="hidden" name="critical" value="' . $critical . '" />

    <h5 class="ul">' . _('Connection Settings') . '</h5>
    <p>'._('The settings used to connect to the Nagios XI server and the hostname of the server.').'</p>

    <table class="table table-condensed table-no-border table-auto-width">
        <tr>
            <td class="vt">
                <label>' . _('Hostname') . '</label>
            </td>
            <td>
                <input type="text" size="20" name="hostname" id="hostname" value="' . encode_form_val($hostname) . '" class="form-control" />
                <div class="subtext">' . _("The name of the host that the services will be applied to.") . '</div>
            </td>
        </tr>
        <tr>
            <td class="vt">
                <label>' . _("Report Period") . '</label>
            </td>
            <td>
                <input type="text" name="displayreportperiod" id="displayreportperiod" value="' . $displayreportperiod . '" class="form-control" disabled>
                <div class="subtext">' . _("How long to look back for the SLA. Also serves as default check interval.") . '</div>
            </td>
        </tr>
    </table>

<script>
    $(document).ready(function() {
        $("#tabs").tabs();
        var servicetarget = "";
        var current = "";
        var retain = true;

        $(".adddeleterow").on("change", ".hostSList", function () {
            var selected = "";
            $(this).data("oldhost", $(this).data("newhost") || "");
            $(this).data("newhost", $(this).val());

            if ($(this).val() != "") {
                servicetarget = $(this).parents("tr").find(".serviceList");
                selected = servicetarget.val();

                var reload = reload_service_list($(this).data("oldhost"), $(this).data("newhost"));
                update_service_list($(this).val(), servicetarget, selected, reload);
            } else {
                $(this).parents("tr").find(".serviceList").html("<option value=\'\'>" + "Service:" +  "</option>");
            }
        });

        function update_service_list(host, servicetarget, selected, reload) {
            // Check if we have a selection and retain
            if (selected && reload) {
                selected = selected.replace(/\s/g, "+");
                $.get("/nagiosxi/reports/sla.php?mode=getservices&host=" + host + "&service=" + selected, function(data) {
                    servicetarget.html(data);
                });
            } else {
                $.get("/nagiosxi/reports/sla.php?mode=getservices&host=" + host, function(data) {
                    servicetarget.html(data);
                });
            }
        }

        // Do we need to reload services
        function reload_service_list(oldhost, newhost) {
            if (oldhost == "") {
                return true;
            } else {
                return false;
            }
        }

        // Data retention trigger for loaded service list
        if ($(".hostSList").val()) {
            retain = false;
            $(".adddeleterow .hostSList").trigger("change");
        }
    });
</script>

<h5 class="ul">' . _('Check SLA Setup') . '</h5>
    <div class="message" style="max-width:900px;"><ul class="actionMessage">' . _("Warning and Critical support all the thresholds shown in the").' <a target="_blank" href="https://nagios-plugins.org/doc/guidelines.html#THRESHOLDFORMAT">'._("Nagios Plugins guidelines") . '</a>.<br><br>' . _("Normally a threshold is met when a value reaches a certain number, because we are going down from 100%, we need to do the opposite. This wizard automatically places a '@' in front of the warning and critical values to reverse them.") . '</ul>
    </div>

<div id="tabs" style="max-width:700px;">
    <ul>
        <li><a href="#host" id="selecthost">Host</a></li>
        <li><a href="#service" id="selectservice">Service</a></li>
        <li><a href="#hostgroup" id="selecthostgroup">Hostgroup</a></li>
        <li><a href="#servicegroup" id="selectservicegroup">Servicegroup</a></li>
    </ul>
    <div id="host">
            <table class="adddeleterow table table-condensed table-no-border table-auto-width">
                <tr>
                    <th></th>' .
                    '<th>' . _('Target Host') . '</th>' .
                    '<th>' . _('Warning') . '</th>' .
                    '<th>' . _('Critical') . '</th>' .
                '</tr>';

                for ($x = 0; $x < count($serviceargs['host']); $x++) {
                    // Initialize
                    ${"host_" . "{$x}"} = "";
                    ${"warning_" . "{$x}"} = "";
                    ${"critical_" . "{$x}"} = "";

                    if (isset($services['host']) && $services['host'][0][0] == "on") {
                        foreach ($serviceargs['host'][$x] as $key => $val) {
                            $namer = $key . "_" . $x;
                            ${$namer} = $val;
                        }
                    }

                    // Set values
                    $host = encode_form_val(${"host_" . "{$x}"});
                    $warning = encode_form_val(${"warning_" . "{$x}"});
                    $critical = encode_form_val(${"critical_" . "{$x}"});

                    $output .= '
                    <tr>
                        <td>
                            <input type="checkbox" class="checkbox" name="services[host][' . $x . ']" ' . (isset($services['host'][$x]) ? is_checked($services['host'][$x], 1) : '') . '>
                        </td>
                        <td>';
                    $args = array('brevity' => 1, 'orderby' => 'host_name:a');
                    $oxml = get_xml_host_objects($args);

                    $output .= '<select name="serviceargs[host][' . $x . '][host]" class="hostList form-control" style="width: 150px;">
                        <option value="">' . _("Host") . ': </option>';

                    if ($oxml) {
                        foreach ($oxml->host as $hostobject) {
                            if (isset($hostobject->host_name)) {
                                $name = strval($hostobject->host_name);
                            }

                            $output .= "<option value='" . $name . "' " . is_selected($host, $name) . ">$name</option>\n";
                        }
                    }

                    $output .= '</select>';
                    $output .= '
                        </td>
                        <td>
                            <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>&nbsp;@&nbsp;<input type="text" size="6" name="serviceargs[host][' . $x . '][warning]" value="' . $warning . '" class="form-control" />
                        </td>
                        <td>
                            <label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>&nbsp;@&nbsp;<input type="text" size="6" name="serviceargs[host][' . $x . '][critical]" value="' . $critical . '" class="form-control" />
                        </td>
                    </tr>';
                }
        $output .= '
        </table>
    </div> <!-- Closes #host -->

    <div id="service">
        ';
        $output .= '
            <table class="adddeleterow table table-condensed table-no-border table-auto-width">
                <tr>
                    <th></th>' .
                    '<th>' . _('Target Host') . '</th>' .
                    '<th>' . _('Target Service') . '</th>' .
                    '<th>' . _('Warning') . '</th>' .
                    '<th>' . _('Critical') . '</th>' .
                '</tr>';
            for ($x = 0; $x < count($serviceargs['service']); $x++) {
                // Initialize
                ${"service_" . "{$x}"} = "";
                ${"host_" . "{$x}"} = "";
                ${"warning_" . "{$x}"} = "";
                ${"critical_" . "{$x}"} = "";

                if (isset($services['service']) && $services['service'][0][0] == "on") {
                    foreach ($serviceargs['service'][$x] as $key => $val) {
                        $namer = $key . "_" . $x;
                        ${$namer} = $val;
                    }
                }

                // Set values
                $service = encode_form_val(${"service_" . "{$x}"});
                $host = encode_form_val(${"host_" . "{$x}"});
                $warning = encode_form_val(${"warning_" . "{$x}"});
                $critical = encode_form_val(${"critical_" . "{$x}"});

                $output .= '
                <tr>
                    <td>
                        <input type="checkbox" class="checkbox" name="services[service][' . $x . ']" ' . (isset($services['service'][$x]) ? is_checked($services['service'][$x], 1) : '') . '>
                    </td>
                    <td>';
                    $args = array('brevity' => 1, 'orderby' => 'host_name:a');
                    $oxml = get_xml_host_objects($args);

                    $output .= '<select name="serviceargs[service][' . $x . '][host]" class="hostSList form-control" style="width: 150px;">
                    <option value="">' . _("Host") . ': </option>';

                    if ($oxml) {
                        foreach ($oxml->host as $hostobject) {
                            if (isset($hostobject->host_name)) {
                                $hname = strval($hostobject->host_name);
                            }

                            $output .= "<option value='" . $hname . "' " . is_selected($host, $hname) . ">$hname</option>\n";
                        }
                    }

                    $output .= '</select>';
                    $output .= '
                    </td>
                    <td>';
                    $args = array('brevity' => 1, 'host_name' => $host, 'orderby' => 'service_description:a');
                    $oxml = get_xml_service_objects($args);

                    $output .= '<select name="serviceargs[service][' . $x . '][service]" class="serviceList form-control" style="width: 250px;">
                    <option value="">' . _("Service") . ': </option>';

                    if ($oxml) {
                        foreach ($oxml->service as $serviceobject) {
                            if (isset($serviceobject->service_description)) {
                                $sname = strval($serviceobject->service_description);
                            }

                            $sname = strval(isset($serviceobject->service_description));
                            $output .= "<option value='" . $sname . "' " . is_selected($service, $sname) . ">$sname</option>\n";
                        }
                    }

                    $output .= '</select>';
                    $output .= '
                    </td>
                    <td>
                        <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>&nbsp;@&nbsp;<input type="text" size="6" name="serviceargs[service][' . $x . '][warning]" value="' . $warning . '" class="form-control" />
                    </td>
                    <td>
                        <label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>&nbsp;@&nbsp;<input type="text" size="6" name="serviceargs[service][' . $x . '][critical]" value="' . $critical . '" class="form-control" />
                    </td>
                </tr>';
            }
        $output .= '
            </table>
    </div> <!-- Closes #service -->

    <div id="hostgroup">
        ';
        $output .= '
            <table class="adddeleterow table table-condensed table-no-border table-auto-width">
                <tr>
                    <th></th>' .
                    '<th>' . _('Target Hostgroup') . '</th>' .
                    '<th>' . _('Warning') . '</th>' .
                    '<th>' . _('Critical') . '</th>' .
                '</tr>';

                for ($x = 0; $x < count($serviceargs['hostgroup']); $x++) {
                    // Initialize
                    ${"hostgroup_" . "{$x}"} = "";
                    ${"warning_" . "{$x}"} = "";
                    ${"critical_" . "{$x}"} = "";

                    if (isset($services['hostgroup']) && $services['hostgroup'][0][0] == "on") {
                        foreach ($serviceargs['hostgroup'][$x] as $key => $val) {
                            $namer = $key . "_" . $x;
                            ${$namer} = $val;
                        }
                    }

                    // Set values
                    $hostgroup = encode_form_val(${"hostgroup_" . "{$x}"});
                    $warning = encode_form_val(${"warning_" . "{$x}"});
                    $critical = encode_form_val(${"critical_" . "{$x}"});

                    $output .= '
                    <tr>
                        <td>
                            <input type="checkbox" class="checkbox" name="services[hostgroup][' . $x . ']" ' . (isset($services['hostgroup'][$x]) ? is_checked($services['hostgroup'][$x], 1) : '') . '>
                        </td>
                        <td>';
                    $args = array('orderby' => 'hostgroup_name:a');
                    $oxml = get_xml_hostgroup_objects($args);

                    $output .= '<select name="serviceargs[hostgroup][' . $x . '][hostgroup]" class="hostgroupList form-control" style="width: 150px;">
                    <option value="">' . _("Hostgroup") . ': </option>';

                    if ($oxml) {
                        foreach ($oxml->hostgroup as $hg) {
                            if (isset($hg->hostgroup_name)) {
                                $name = strval($hg->hostgroup_name);
                            }

                            $output .= "<option value='" . $name . "' " . is_selected($hostgroup, $name) . ">$name</option>\n";
                        }
                    }

                    $output .= '</select>';
                    $output .= '
                        </td>
                        <td>
                            <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>&nbsp;@&nbsp;<input type="text" size="6" name="serviceargs[hostgroup][' . $x . '][warning]" value="' . $warning . '" class="form-control" />
                        </td>
                        <td>
                            <label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>&nbsp;@&nbsp;<input type="text" size="6" name="serviceargs[hostgroup][' . $x . '][critical]" value="' . $critical . '" class="form-control" />
                        </td>
                    </tr>';
                }
                $output .= '
            </table>
    </div> <!-- Closes #hostgroup -->

    <div id="servicegroup">
        ';
        $output .= '
            <table class="adddeleterow table table-condensed table-no-border table-auto-width">
                <tr>
                    <th></th>' .
                    '<th>' . _('Target Servicegroup') . '</th>' .
                    '<th>' . _('Warning') . '</th>' .
                    '<th>' . _('Critical') . '</th>' .
                '</tr>';

                for ($x = 0; $x < count($serviceargs['servicegroup']); $x++) {
                    // Initialize
                    ${"servicegroup_" . "{$x}"} = "";
                    ${"warning_" . "{$x}"} = "";
                    ${"critical_" . "{$x}"} = "";

                    if (isset($services['servicegroup']) && $services['servicegroup'][0][0] == "on") {
                        foreach ($serviceargs['servicegroup'][$x] as $key => $val) {
                            $namer = $key . "_" . $x;
                            ${$namer} = $val;
                        }
                    }

                    // Set values
                    $servicegroup = encode_form_val(${"servicegroup_" . "{$x}"});
                    $warning = encode_form_val(${"warning_" . "{$x}"});
                    $critical = encode_form_val(${"critical_" . "{$x}"});

                    $output .= '
                    <tr>
                        <td>
                            <input type="checkbox" class="checkbox" name="services[servicegroup][' . $x . ']" ' . (isset($services['servicegroup'][$x]) ? is_checked($services['servicegroup'][$x], 1) : '') . '>
                        </td>
                        <td>';
                    $args = array('orderby' => 'servicegroup_name:a');
                    $oxml = get_xml_servicegroup_objects($args);

                    $output .= '<select name="serviceargs[servicegroup][' . $x . '][servicegroup]" class="servicegroupList form-control" style="width: 150px;">
                    <option value="">' . _("Servicegroup") . ': </option>';

                    if ($oxml) {
                        foreach ($oxml->servicegroup as $sg) {
                            if (isset($sg->servicegroup_name)) {
                                $name = strval($sg->servicegroup_name);
                            }

                            $output .= "<option value='" . $name . "' " . is_selected($servicegroup, $name) . ">$name</option>\n";
                        }
                    }

                    $output .= '</select>';
                    $output .= '
                        </td>
                        <td>
                            <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>&nbsp;@&nbsp;<input type="text" size="6" name="serviceargs[servicegroup][' . $x . '][warning]" value="' . $warning . '" class="form-control" />
                        </td>
                        <td>
                            <label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>&nbsp;@&nbsp;<input type="text" size="6" name="serviceargs[servicegroup][' . $x . '][critical]" value="' . $critical . '" class="form-control" />
                        </td>
                    </tr>';
                }

                $output .= '
            </table>
    </div> <!-- Closes #servicegroup -->
</div> <!-- Closes #tabs -->

            ';

            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:

            // get variables that were passed to us
            $hostname = grab_array_var($inargs, "hostname", "");
            $username = grab_array_var($inargs, "username", "");
            $warning = grab_array_var($inargs, "warning", "");
            $critical = grab_array_var($inargs, "critical", "");
            $advanced = grab_array_var($inargs, "advanced", "");
            $services = grab_array_var($inargs, "services", "");
            $serviceargs = grab_array_var($inargs, "serviceargs", "");

            // Use encoded data if user came back from future screen.
            $services_serial = grab_array_var($inargs, 'services_serial');
            if ($services_serial) {
                $services = unserialize(base64_decode($services_serial));
            }
            $serviceargs_serial = grab_array_var($inargs, 'serviceargs_serial');
            if ($serviceargs_serial) {
                $serviceargs = unserialize(base64_decode($serviceargs_serial));
            }

            // If no serialized data, use current request data if available.
            if (!$services)
                $services = grab_array_var($inargs, 'services');
            if (!$serviceargs)
                $serviceargs = grab_array_var($inargs, 'serviceargs');

            // check for errors
            $errors = 0;
            $errmsg = array();
                
            if ($errors>0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }
                
            break;

        case CONFIGWIZARD_MODE_GETSTAGE3OPTS:

            $hostname = grab_array_var($inargs, "hostname", "SLA");
            $username = grab_array_var($inargs, "username", "");
            $reportperiod = grab_array_var($inargs, "reportperiod", "24h");
            $custom_reportperiod = grab_array_var($inargs, "custom_reportperiod", "");
            $custom_reportperiod_unit = grab_array_var($inargs, "custom_reportperiod_unit", "");
            $warning = grab_array_var($inargs, "warning");
            $critical = grab_array_var($inargs, "critical");
            $advanced = grab_array_var($inargs, "advanced", array());
            $services = grab_array_var($inargs, "services");
            $serviceargs = grab_array_var($inargs, "serviceargs");
            $services_serial = grab_array_var($inargs, "services_serial", base64_encode(serialize($services)));
            $serviceargs_serial = grab_array_var($inargs, "serviceargs_serial", base64_encode(serialize($serviceargs)));

            $check_interval = 24 * 60;
            if ($reportperiod == 'custom') {
                $check_interval = get_minutes_from_reportperiod($custom_reportperiod, $custom_reportperiod_unit);
            }

            $outargs[CONFIGWIZARD_OVERRIDE_OPTIONS]["check_interval"] = $check_interval;
            $outargs[CONFIGWIZARD_OVERRIDE_OPTIONS]["retry_interval"] = floor($check_interval / 5);
            break;

        case CONFIGWIZARD_MODE_GETSTAGE3HTML:

            $hostname = grab_array_var($inargs, "hostname", "SLA");
            $username = grab_array_var($inargs, "username", "");
            $reportperiod = grab_array_var($inargs, "reportperiod", "24h");
            $custom_reportperiod = grab_array_var($inargs, "custom_reportperiod", "");
            $custom_reportperiod_unit = grab_array_var($inargs, "custom_reportperiod_unit", "");
            $warning = grab_array_var($inargs, "warning");
            $critical = grab_array_var($inargs, "critical");
            $advanced = grab_array_var($inargs, "advanced", array());
            $services = grab_array_var($inargs, "services");
            $serviceargs = grab_array_var($inargs, "serviceargs");
            $services_serial = grab_array_var($inargs, "services_serial", base64_encode(serialize($services)));
            $serviceargs_serial = grab_array_var($inargs, "serviceargs_serial", base64_encode(serialize($serviceargs)));

            $output = '
                <input type="hidden" name="hostname" value="' . encode_form_val($hostname) . '" />
                <input type="hidden" name="username" value="' . encode_form_val($username) . '" />
                <input type="hidden" name="warning" value="' . intval($warning) . '" />
                <input type="hidden" name="critical" value="' . intval($critical) . '" />
                <input type="hidden" name="advanced" value="' . encode_form_val($advanced) . '" />
                <input type="hidden" name="services_serial" value="' . $services_serial . '">
                <input type="hidden" name="serviceargs_serial" value="' . $serviceargs_serial . '">
            ';
            break;
            
        case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:
             
            break;
            
        case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:

            break;
            
        case CONFIGWIZARD_MODE_GETOBJECTS:
            $hostname = grab_array_var($inargs, "hostname", "SLA");
            $reportperiod = grab_array_var($inargs, "reportperiod", "24h");
            $custom_reportperiod = grab_array_var($inargs, "custom_reportperiod", "");
            $custom_reportperiod_unit = grab_array_var($inargs, "custom_reportperiod_unit", "");
            $warning = grab_array_var($inargs, "warning");
            $critical = grab_array_var($inargs, "critical");
            $advanced = grab_array_var($inargs, "advanced", array());
            $services = grab_array_var($inargs, "services", array());
            $serviceargs = grab_array_var($inargs, "serviceargs", array());
            $services_serial = grab_array_var($inargs, "services_serial", "");
            $serviceargs_serial = grab_array_var($inargs, "serviceargs_serial", "");

            $advanced = unserialize(base64_decode($advanced));
            $services = unserialize(base64_decode($services_serial));
            $serviceargs = unserialize(base64_decode($serviceargs_serial));

            foreach ($advanced as $k => $v) {
                $advancedoptions[] = $k."=".$v;
            }
            $advancedoptions = implode(',', $advancedoptions);

            // save data for later use in re-entrance
            $meta_arr = array();
            $meta_arr["hostname"] = $hostname;
            $meta_arr["reportperiod"] = $reportperiod;
            $meta_arr["custom_reportperiod"] = $custom_reportperiod;
            $meta_arr["custom_reportperiod_unit"] = $custom_reportperiod_unit;
            $meta_arr["warning"] = $warning;
            $meta_arr["critical"] = $critical;
            $meta_arr["advanced"] = $advanced;
            $meta_arr["services"] = $services;
            $meta_arr["serviceargs"] = $serviceargs;
            save_configwizard_object_meta($wizard_name, "127.0.0.1", "", $meta_arr);

            // Construct service check command variable list
            $argvars = "";

            $objs = array();

            if (!host_exists($hostname)) {
                $objs[] = array(
                    "type" => OBJECTTYPE_HOST,
                    "use" => "xiwizard_generic_host",
                    "host_name" => $hostname,
                    "address" => "127.0.0.1",
                    "icon_image" => "sla.png",
                    "statusmap_image" => "sla.png",
                    "_xiwizard" => $wizard_name,
                );
            }

            // see which services we should monitor
            foreach ($services as $svc => $svcstate) {

                switch ($svc) {

                    case "host":
                        foreach ($svcstate as $i => $v) {
                            // create service for each on checkbox
                            if ($v != "on")
                                continue;

                            $argvars = " -u '".$_SESSION['username']."'";
                            $argvars .= " -h " . escapeshellarg($serviceargs['host'][$i]['host']);
                            $argvars .= " -w @" . $serviceargs['host'][$i]['warning'];
                            $argvars .= " -c @" . $serviceargs['host'][$i]['critical'];
                            $argvars .= " -a '" . $advancedoptions . "'";

                            $objs[] = array(
                                "type" => OBJECTTYPE_SERVICE,
                                "host_name" => $hostname,
                                "use" => "xiwizard_check_sla2",
                                "service_description" => "SLA for " . $serviceargs['host'][$i]['host'],
                                "check_command" => "check_xi_sla2!" . $argvars,
                                "_xiwizard" => $wizard_name,
                            );
                        }
                        break;

                    case "service":
                        foreach ($svcstate as $i => $v) {
                            // create service for each on checkbox
                            if ($v != "on")
                                continue;

                            $service = $serviceargs['service'][$i]['service'];
                            $service_description = $service;

                            $argvars = " -u '".$_SESSION['username']."'";
                            $argvars .= " -h " . escapeshellarg($serviceargs['service'][$i]['host']);

                            if (!empty($service)) {
                                $argvars .= " -s " . escapeshellarg($service);
                            } else {
                                $argvars .= " -A ";
                                $service_description = _("all service average");
                            }

                            $argvars .= " -w @" . $serviceargs['service'][$i]['warning'];
                            $argvars .= " -c @" . $serviceargs['service'][$i]['critical'];
                            $argvars .= " -a '" . $advancedoptions . "'";

                            $objs[] = array(
                                "type" => OBJECTTYPE_SERVICE,
                                "host_name" => $hostname,
                                "use" => "xiwizard_check_sla2",
                                "service_description" => "SLA for " . $serviceargs['service'][$i]['host'] . ' - ' . $service_description,
                                "check_command" => "check_xi_sla2!" . $argvars,
                                "_xiwizard" => $wizard_name,
                            );
                        }
                        break;

                    case "hostgroup":
                        foreach ($svcstate as $i => $v) {
                            // create service for each on checkbox
                            if ($v != "on")
                                continue;

                            $argvars = " -u '".$_SESSION['username']."'";
                            $argvars .= " -g " . escapeshellarg($serviceargs['hostgroup'][$i]['hostgroup']);
                            $argvars .= " -w @" . $serviceargs['hostgroup'][$i]['warning'];
                            $argvars .= " -c @" . $serviceargs['hostgroup'][$i]['critical'];
                            $argvars .= " -a '" . $advancedoptions . "'";

                            $objs[] = array(
                                "type" => OBJECTTYPE_SERVICE,
                                "host_name" => $hostname,
                                "use" => "xiwizard_check_sla2",
                                "service_description" => "SLA for hostgroup " . $serviceargs['hostgroup'][$i]['hostgroup'],
                                "check_command" => "check_xi_sla2!" . $argvars,
                                "_xiwizard" => $wizard_name,
                            );
                        }
                        break;

                    case "servicegroup":
                        foreach ($svcstate as $i => $v) {
                            // create service for each on checkbox
                            if ($v != "on")
                                continue;

                            $argvars = " -u '".$_SESSION['username']."'";
                            $argvars .= " -e " . escapeshellarg($serviceargs['servicegroup'][$i]['servicegroup']);
                            $argvars .= " -w @" . $serviceargs['servicegroup'][$i]['warning'];
                            $argvars .= " -c @" . $serviceargs['servicegroup'][$i]['critical'];
                            $argvars .= " -a '" . $advancedoptions . "'";

                            $objs[] = array(
                                "type" => OBJECTTYPE_SERVICE,
                                "host_name" => $hostname,
                                "use" => "xiwizard_check_sla",
                                "service_description" => "SLA for servicegroup " . $serviceargs['servicegroup'][$i]['servicegroup'],
                                "check_command" => "check_xi_sla2!" . $argvars,
                                "_xiwizard" => $wizard_name,
                            );
                        }
                        break;                        
                }
            }

            // return the object definitions to the wizard
            $outargs[CONFIGWIZARD_NAGIOS_OBJECTS] = $objs;

            break;

        default:
            break;          
        }

    return $output;
}

function get_minutes_from_reportperiod($amount, $unit)
{
    switch ($unit) 
    {
        case 'm':
            $mins = $amount;
            break;

        case 'h':
            $mins = $amount * 60;
            break;

        case 'd':
            $mins = $amount * (24 * 60);
            break;
    
        case 'M':
            $mins = $amount * (30 * 24 * 60);
            break;
    }

    return $mins;
}
