<?php
include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

java_glassfish_configwizard_init();
java_jboss_configwizard_init();
java_jetty_configwizard_init();
java_tomcat_configwizard_init();
java_weblogic_configwizard_init();

function common_args() {
    return array(
        CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
        CONFIGWIZARD_VERSION => '1.1.0',
        CONFIGWIZARD_DATE => _('2019-09-10'),
        CONFIGWIZARD_COPYRIGHT => _("Copyright &copy; 2018 Nagios Enterprises, LLC."),
        CONFIGWIZARD_AUTHOR => _('Nagios Enterprises, LLC.'),
        CONFIGWIZARD_REQUIRES_VERSION => 550,
    );
}

function java_glassfish_configwizard_init(){
    
    /* Name / ID for config wizard */
    $name = 'java_glassfish';
    $common_args = common_args();
    /* Relevant info for wizard */
    $args = array(
        CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_DESCRIPTION => _('Monitor GlassFish JVMs through JMX (uses NCPA or requires Java)') . '<div style="display: none">java</div>',
        CONFIGWIZARD_DISPLAYTITLE => _('GlassFish'),
        CONFIGWIZARD_FUNCTION => 'java_as_configwizard_func',
        CONFIGWIZARD_PREVIEWIMAGE => 'java_glassfish.png',
        );
    $args = array_merge($args, $common_args);
    /* Register wizard with XI */
    register_configwizard($name,$args);
}

function java_jboss_configwizard_init(){
    
    /* Name / ID for config wizard */
    $name = 'java_jboss';
    $common_args = common_args();
    /* Relevant info for wizard */
    $args = array(
        CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_DESCRIPTION => _('Monitor JBoss/WildFly JVMs through JMX (uses NCPA or requires Java)') . '<div style="display: none">java</div>',
        CONFIGWIZARD_DISPLAYTITLE => _('JBoss/WildFly'),
        CONFIGWIZARD_FUNCTION => 'java_as_configwizard_func',
        CONFIGWIZARD_PREVIEWIMAGE => 'java_jboss.png',
        );
    $args = array_merge($args, $common_args);
    /* Register wizard with XI */
    register_configwizard($name,$args);
}

function java_jetty_configwizard_init(){
    
    /* Name / ID for config wizard */
    $name = 'java_jetty';
    $common_args = common_args();
    /* Relevant info for wizard */
    $args = array(
        CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_DESCRIPTION => _('Monitor Jetty JVMs through JMX (uses NCPA or requires Java)') . '<div style="display: none">java</div>',
        CONFIGWIZARD_DISPLAYTITLE => _('Jetty'),
        CONFIGWIZARD_FUNCTION => 'java_as_configwizard_func',
        CONFIGWIZARD_PREVIEWIMAGE => 'java_jetty.png',
        );
    $args = array_merge($args, $common_args);
    /* Register wizard with XI */
    register_configwizard($name,$args);
}

function java_tomcat_configwizard_init(){
    
    /* Name / ID for config wizard */
    $name = 'java_tomcat';
    $common_args = common_args();
    /* Relevant info for wizard */
    $args = array(
        CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_DESCRIPTION => _('Monitor Apache Tomcat JVMs through JMX (uses NCPA or requires Java)') . '<div style="display: none">java</div>',
        CONFIGWIZARD_DISPLAYTITLE => _('Apache Tomcat'),
        CONFIGWIZARD_FUNCTION => 'java_as_configwizard_func',
        CONFIGWIZARD_PREVIEWIMAGE => 'java_tomcat.png',
        );
    $args = array_merge($args, $common_args);
    /* Register wizard with XI */
    register_configwizard($name,$args);
}

/* Not yet */

function java_weblogic_configwizard_init(){
    
    /* Name / ID for config wizard */
    $name = 'java_weblogic';
    $common_args = common_args();
    /* Relevant info for wizard */
    $args = array(
        CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_DESCRIPTION => _('Monitor a WebLogic instance via JMX.') . '<div style="display: none">java</div>',
        CONFIGWIZARD_DISPLAYTITLE => _('WebLogic'),
        CONFIGWIZARD_FUNCTION => 'java_weblogic_configwizard_func',
        CONFIGWIZARD_PREVIEWIMAGE => 'java_weblogic.png',
        );
    $args = array_merge($args, $common_args);
    /* Register wizard with XI */
    register_configwizard($name,$args);
}

/* This function is automatically called by the XI wizard framework when the wizard is run */
function java_as_configwizard_func($mode = '',$inargs = null,&$outargs,&$result){

    /* Define the wizard name */
    $plugin_name = 'check_jvm.jar';
    $wizard_name = $inargs['wizard'];
    switch ($wizard_name) {
        case 'java_tomcat':
            $noun_long = _("Tomcat Server");
            $noun_short = _('Tomcat');
            $doc_name = 'How-to-Monitor-Apache-Tomcat-With-Nagios-XI.pdf';
            $sample_service_url = 'service:jmx:rmi:///jndi/rmi://&lt;host&gt:&lt;port&gt;/jmxrmi';
            break;

        case 'java_jboss':
            $noun_long = _("JBoss Server");
            $noun_short = _('JBoss');
            $doc_name = 'How-to-Monitor-JBoss-With-Nagios-XI.pdf';
            $sample_service_url = 'service:jmx:remote+http://&lt;host&gt:&lt;port&gt;';
            break;

        case 'java_jetty':
            $noun_long = _("Jetty Server");
            $noun_short = _('Jetty');
            $doc_name = 'How-to-Monitor-Jetty-JMX-With-Nagios-XI.pdf';
            $sample_service_url = 'service:jmx:rmi:///jndi/rmi://&lt;host&gt:&lt;port&gt;/jmxrmi';
            break;

        case 'java_glassfish':
            $noun_long = _("Glassfish Server");
            $noun_short = _('Glassfish');
            $doc_name = 'How-to-Monitor-GlassFish-With-Nagios-XI.pdf';
            $sample_service_url = 'service:jmx:rmi://&lt;host&gt:&lt;port&gt;/jndi/rmi://&lt;host&gt:&lt;port&gt;/jmxrmi';
            break;

        default:
            $noun_long = '';
            $plugin_name = '';
            $doc_name = '';
            break;
    }

    /* Prerequisite software */
    $NCPA_download_url = "https://www.nagios.org/ncpa/#downloads";
    $NCPA_docs_url = "https://www.nagios.org/ncpa/#docs";
    $java_as_plugin_url = get_base_uri() . "includes/configwizards/java-as/plugins/$plugin_name";
    $java_as_docs_url = "https://assets.nagios.com/downloads/nagiosxi/docs/$doc_name";

    /* Initialize return code and output */
    $result = 0;
    $output = '';
    
    /* Initialize output args */
    $outargs[CONFIGWIZARD_PASSBACK_DATA] = $inargs;

    switch ($mode) {
        case CONFIGWIZARD_MODE_GETSTAGE1HTML:
            /* This defines $nextstep variable, used for determining if the user did not */
            /* provide correct information when the user was on CONFIGWIZARD_MODE_GETSTAGE1HTML */
            $nextstep = htmlentities(grab_array_var($_POST,'nextstep',false),ENT_QUOTES);

            /* Determine if this is the first wizard run */
            if ($nextstep == '') {
                /* Clear the session array to be sure it is blank */
                unset($_SESSION[$wizard_name]); 
            }

            /* Fresh Wizard Run */
            /* OR */
            /* Continuing from CONFIGWIZARD_MODE_VALIDATESTAGE1DATA due to user error */
            
            if (!isset($_POST['address'])) {
                /* Fresh Wizard Run */
                
                $_SESSION[$wizard_name] = array(); 
                
                $remote = '';
                $port = '5693';
                $token = '';
                $service_url = '';
                $ncpa_address = '';
                $username = '';
                $password = '';
            }
            else {

                /* General */
                $remote_session = grab_array_var($_SESSION[$wizard_name],'remote',''); // only used in the next line
                $remote = grab_array_var($inargs,'remote', $remote_session);
                $address = grab_array_var($_SESSION[$wizard_name], 'address', '');
                $address = grab_array_var($inargs, 'address', $hostname_session);

                /* NCPA-specific */
                $port_session = grab_array_var($_SESSION[$wizard_name], 'port', '5693');
                $port = grab_array_var($inargs, 'port', $port_session);
                $token_session = grab_array_var($_SESSION[$wizard_name], 'token', '');
                $token = grab_array_var($inargs, 'token', $port_session);

                /* Java-specific */
                $service_url_session = grab_array_var($_SESSION[$wizard_name], 'service_url', '');
                $service_url = grab_array_var($inargs, 'service_url', $service_url_session);
                $username_session = grab_array_var($_SESSION[$wizard_name], 'username', '');
                $username = grab_array_var($inargs, 'username', $username_session);
                $password_session = grab_array_var($_SESSION[$wizard_name], 'password', '');
                $password = grab_array_var($inargs, 'password', $password_session);
            }
                
            
            
            /* Now we are creating the HTML for CONFIGWIZARD_MODE_GETSTAGE1HTML */ 
            $output = '
            <h5 class="ul">' . _('Plugin and Agent Setup') . '</h5>
            <p>' . _('If you use a direct JMX connection between Nagios XI and your application server, you will only need to ensure that your server is remote-JMX-capable.
                Otherwise, you will need to install NCPA and the Application Server Plugin on your application server.') . '</p>
            <ul style="padding: 0 0 0 30px;">
                <li><a href="' . $NCPA_download_url . '" target="_blank">' . _('Download and install the latest version of NCPA') . '</a></li>
                <li><a href="' . $java_as_plugin_url . '" target="_blank">' . _('Install the Java Application Server Plugin') . '</a></li>
                <li>' . _('Additional documentation for ') . '<a href="' . $NCPA_docs_url . '" target="_blank">' . _('NCPA') . '</a>
                    ' . _(' and for ') . '<a href="' . $java_as_docs_url . '" target="_blank">' . _('monitoring application servers.') . '</a></li>
            </ul>
            <h5 class="ul">' . $noun_long . _(' Information') . '</h5>
            <table class="table table-condensed table-no-border table-auto-width">
                <tr>
                    <td>
                        <label for="address">' . _('IP Address') . ':</label>
                    </td>
                    <td>
                        <input type="text" size="40" name="address" id="address" value="' . encode_form_val($address) . '" class="textfield form-control">
                    </td>
                </tr>
                <tr>
                    <td class="vt">
                        <label for="remote">' . sprintf(_('Access %s via:'), $noun_long) . '</label>
                    </td>
                    <td>
                        <select name="remote" id="remote" class="form-control">
                            <option value="JMX" ' . is_selected($remote, "JMX") . '>' . _('JMX') . '</option>
                            <option value="NCPA" ' . is_selected($remote, "NCPA") . '>' . _('Remote Agent (NCPA)') . '</option>
                        </select>
                    </td>
                </tr>
                <tr class="ncpa-only">
                    <td class="vt">
                        <label for="">' . _("NCPA Listener Port") . '</label>
                    </td>
                    <td>
                        <input type="text" size="40" name="port" id="port" value="'.encode_form_val($port).'" class="form-control">
                    </td>
                </tr>
                <tr class="ncpa-only">
                    <td class="vt">
                        <label for="">' . _("NCPA Token") . '</label>
                    </td>
                    <td>
                        <input type="text" size="40" name="token" id="token" value="'.encode_form_val($token).'" class="form-control">
                    </td>
                </tr>
                <tr>
                    <td class="vt">
                        <label for="service_url">' . _('Service URL:') . '</label>
                    </td>
                    <td>
                        <input type="text" size="40" name="service_url" id="service_url" value="'.encode_form_val($service_url).'" class="form-control">
                        <div class="subtext">' . _('The full JMX service URL.') . ' Ex: "'. $sample_service_url . '"</div>
                    </td>
                </tr>
                <tr>
                    <td class="vt">
                        <label for="username">' . sprintf(_('%s Username'), $noun_short) . '</label>
                    </td>
                    <td>
                        <input type="text" size="40" name="username" id="username" value="'.encode_form_val($username).'" class="form-control">
                        <div class="subtext">' . sprintf(_('The %s user with JMX privileges.'), $noun_short) . ' </div>
                    </td>
                </tr>
                <tr>
                    <td class="vt">
                        <label for="password">' . sprintf(_('%s Password'), $noun_short) . '</label>
                    </td>
                    <td>
                        <input type="password" size="40" name="password" id="password" value="'.encode_form_val($password).'" class="form-control">
                        <div class="subtext">' . sprintf(_('The password for the %s user above.'), $noun_short) . ' </div>
                    </td>
                </tr>
            </table>';

            if (java_as_java_not_installed()) {
                $output .='
            <div class="jmx-only">
                <p><b style="color: red">' . _('To access the JMX ports directly from this server, please install Java.') . '<br/>' .
                _('You will also need to edit the CCM command definition for check_xi_java_as to include the absolute path of the java binary.') . '</b></p>
            </div>';
            }

            $output .='
            <script>
            $(document).ready(function () {
                $("#remote").change(function () {
                    if ($(this).val() === "JMX") {
                        // using JMX directly.
                        $(".jmx-only").show();
                        $(".ncpa-only").hide();
                    }
                    else { 
                        // using NCPA 
                        $(".jmx-only").hide();
                        $(".ncpa-only").show();
                    }
                });

                // Initialize
                if ($("#remote").val() === "JMX") {
                    $(".ncpa-only").hide();
                    $(".jmx-only").show();
                }
                else { 
                    $(".ncpa-only").show();
                    $(".jmx-only").hide();
                }

            });
            </script>
            ';
            break;

            
        /* Form validation for CONFIGWIZARD_MODE_GETSTAGE1HTML */
        case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:      
            $back = htmlentities(grab_array_var($_POST,'backButton',false),ENT_QUOTES);     
            
            if ($back) break;   

            /* General */
            $remote_session = grab_array_var($_SESSION[$wizard_name],'remote','');
            $remote = grab_array_var($inargs,'remote', $remote_session);
            $address_session = grab_array_var($_SESSION[$wizard_name], 'address', '');
            $address = grab_array_var($inargs, 'address', $address_session);
            $hostname_session = grab_array_var($_SESSION[$wizard_name], 'hostname', gethostbyaddr($address));
            $hostname = grab_array_var($inargs, 'hostname', $hostname_session);

            /* NCPA-specific */
            $port_session = grab_array_var($_SESSION[$wizard_name], 'port', '5693');
            $port = grab_array_var($inargs, 'port', $port_session);
            $port = intval($port);
            $token_session = grab_array_var($_SESSION[$wizard_name], 'token', '');
            $token = grab_array_var($inargs, 'token', $port_session);

            /* Java-specific */
            $service_url_session = grab_array_var($_SESSION[$wizard_name], 'service_url', '');
            $service_url = grab_array_var($inargs, 'service_url', $service_url_session);
            $username_session = grab_array_var($_SESSION[$wizard_name], 'username', '');
            $username = grab_array_var($inargs, 'username', $username_session);
            $password_session = grab_array_var($_SESSION[$wizard_name], 'password', '');
            $password = grab_array_var($inargs, 'password', $password_session);
            
            $errors = 0;
            $errmsg = array();
            if (have_value($service_url) == false)
                $errmsg[$errors++] = _('Please specify a JMX service URL');

            if ($remote === "NCPA") {
                if (!have_value($token)) {
                    $errmsg[$errors++] = _("Please specify a token when using NCPA");
                }

                if (!have_value($address)) {
                    $errmsg[$errors++] = _("Please specify the IP address of your Java Application Server");
                }

                // Check that the plugin is installed.
                $ncpa_full_url = "https://" . $address . ":" . $port . "/api/plugins?token=" . $token;
                $cmd = ''; // debug only
                $result = java_as_ncpa_plugin_check($ncpa_full_url, $plugin_name, $cmd); // defined at end of file
                if ($result > 0) {
                    if ($result === 1) {
                        $errmsg[$errors++] = _("cURL call to verify NCPA installation failed.");
                    } 
                    else if ($result === 2) {
                        $errmsg[$errors++] = _("cURL call to NCPA port did not return JSON data.");
                    }
                    else if ($result === 3) {
                        $errmsg[$errors++] = _("cURL call to NCPA port returned invalid JSON.");
                    }
                    else if ($result === 4) {
                        $errmsg[$errors++] = sprintf(_("%s is not installed on the remote machine."), $plugin_name);
                    }
                    else {
                        $errmsg[$errors++] = _("cURL-related error: ") . htmlentities($result);
                    }
                }
            }

            if ($remote === "JMX") {

                if (java_as_java_not_installed()) {
                    $errmsg[$errors++] = _("Please install Java to use JMX directly");
                    $errmsg[$errors++] = _("Also make sure to edit the CCM definition for check_xi_java_as to include java's absolute path.");
                }
            }

            /* Check to see if the $errors array contains errors */
            if ($errors>0){
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }
            else {
                $_SESSION[$wizard_name]['remote'] = $remote;
                $_SESSION[$wizard_name]['address'] = $address;
                $_SESSION[$wizard_name]['port'] = $port;
                $_SESSION[$wizard_name]['token'] = $token;
                $_SESSION[$wizard_name]['service_url'] = $service_url;
                $_SESSION[$wizard_name]['username'] = $username;
                $_SESSION[$wizard_name]['password'] = $password;
            }
            
            /* The next line ends CONFIGWIZARD_MODE_VALIDATESTAGE1DATA */
            break;


            
        case CONFIGWIZARD_MODE_GETSTAGE2HTML:
            /* This defines $back variable, used for determining if the Back button */
            /* was clicked when the user was on CONFIGWIZARD_MODE_GETSTAGE3HTML */
            $back = htmlentities(grab_array_var($_POST,'backButton',false),ENT_QUOTES);
            
            if (isset($_POST['ncpa_address'])) {
                $service_description = sprintf(_("%s JVM Statistics"), $noun_short);

                $combine = 'on';
            }
            else {
                $sd_session = grab_array_var($_SESSION[$wizard_name], 'service_description', sprintf(_("%s JVM Statistics"), $noun_short));
                $service_description = grab_array_var($inargs, 'service_description', $sd_session);

                $combine = grab_array_var($_SESSION[$wizard_name], 'combine', "on");
                $combine = grab_array_var($inargs, 'combine', 'on');
            }
            // Old variables. These should not change for the rest of the wizard, so it shouldn't matter whether we're going forwards or backwards.

            $address = $_SESSION[$wizard_name]['address'];
            $ncpa_address = $_SESSION[$wizard_name]['ncpa_address'];
            $hostname = grab_array_var($_SESSION[$wizard_name], 'hostname', gethostbyaddr($address));
            $remote = $_SESSION[$wizard_name]['remote'];
            
            // New variable. This should also just kinda work.
            $serviceargs = grab_array_var($_SESSION[$wizard_name], 'serviceargs', array());
                
            /* Now we are creating the HTML for CONFIGWIZARD_MODE_GETSTAGE2HTML */ 
            $output = '
            <h5 class="ul">' . _('Remote Host Details') . '</h5>
            <table class="table table-condensed table-no-border table-auto-width table-padded">
                <tr>
                    <td>
                        <label for="address">' . _('IP Address') . ':</label>
                    </td>
                    <td>
                        <input type="text" size="40" name="address" id="address" value="' . encode_form_val($address) . '" class="textfield form-control" readonly>
                    </td>
                </tr>
                <tr>
                    <td class="vt">
                        <label for="hostname">' . _("Host Name") . '</label>
                    </td>
                    <td>
                        <input type="text" size="40" name="hostname" id="hostname" value="' . encode_form_val($hostname) . '" class="textfield form-control">
                        <div class="subtext">' . _("The host name you want associated with this check.") . '</div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="service_description">' . _('Service Description') . ':</label>
                    </td>
                    <td>
                        <input type="text" size="40" name="service_description" id="service_description" value="'. encode_form_val($service_description) .'" class="textfield form-control">
                    </td>
                </tr>';
            if ($remote === "JMX") {
                $output .= '
                <tr>
                    <td>
                        <label for="classpath">' . _('Classpath') . ':</label>
                    </td>
                    <td>
                        <input type="text" size="40" name="classpath" id="classpath" value="'. encode_form_val($classpath) .'" class="textfield form-control">
                        <div class="subtext">' . _('If you need to manually set the classpath, do so here.') . '</div>
                    </td>
                </tr>';
            }
            $output .= '
            </table>
            <table class="table table-condensed table-no-border table-auto-width table-padded">
                <tr>
                    <td class="vt">
                        <input type="checkbox" class="checkbox" id="combine" name="combine"' . is_checked($combine, 'on') . '>
                    </td>
                    <td>
                        <label for="combine" class="select-cf-option">'. _('Combine into one service') . '</label>
                        <br/>' . _('This allows you to perform all checks on a single JVM, rather than spooling one JVM per check.') . '
                    </td>
                </tr>
            </table>';

            $MemorySimpleHeap = array('enabled' => 'on', 'warning' => '16', 'critical' => '30', 'unit' => '1073741824');
            if (array_key_exists('MemorySimpleHeap',$serviceargs)) {
                $MemorySimpleHeap = $serviceargs['MemorySimpleHeap'];
            }

            $MemoryEden = array('enabled' => '', 'warning' => '', 'critical' => '');
            if (array_key_exists('MemoryEden',$serviceargs)) {
                $MemoryEden = $serviceargs['MemoryEden'];
            }

            $MemorySurvivor = array('enabled' => '', 'warning' => '', 'critical' => '');
            if (array_key_exists('MemorySurvivor',$serviceargs)) {
                $MemorySurvivor = $serviceargs['MemorySurvivor'];
            }

            $MemoryOld = array('enabled' => '', 'warning' => '', 'critical' => '');
            if (array_key_exists('MemoryOld',$serviceargs)) {
                $MemoryOld = $serviceargs['MemoryOld'];
            }

            $output .= '
            <h5 class="ul">' . _("Heap-Allocated Memory") . '</h5>
            <table class="table table-no-border table-auto-width table-padded">
                <label for="heap-unit" class="select-cf-option" style="margin-right:5px;">'. _('Measure these statistics in: ') . '</label>
                <select class="form-control" id="heap-unit" name="serviceargs[MemorySimpleHeap][unit]">
                    <option value="1073741824" ' . is_selected($MemorySimpleHeap['unit'], '1073741824') . '> ' . _("GiB") . '</option>
                    <option value="1048576" ' . is_selected($MemorySimpleHeap['unit'], '1048576') . '> ' . _("MiB") . '</option>
                    <option value="1024" ' . is_selected($MemorySimpleHeap['unit'], '1024') . '> ' . _("KiB") . '</option>
                    <option value="1" ' . is_selected($MemorySimpleHeap['unit'], '1') . '> ' . _("Bytes") . '</option>
                </select>
                <tbody>
                    <tr class="vt">
                        <td class="vt">
                            <input type="checkbox" class="checkbox" id="simple-heap-enable" name="serviceargs[MemorySimpleHeap][enabled]"' . is_checked($MemorySimpleHeap['enabled'], 'on') . '>
                        </td>
                        <td>
                            <label for="simple-heap-enable" class="select-cf-option">'. _('Heap-Allocated Memory') . '</label>
                            <br/>' . _('Measures the memory usage of the entire heap.') . '
                            <div class="pad-t5">
                                <label><img src="/nagiosxi/images/error.png" class="tt-bind" title="Warning Threshold"></label>
                                <input type="text" size="7" name="serviceargs[MemorySimpleHeap][warning]" value="' . encode_form_val($MemorySimpleHeap['warning']) . '" class="textfield form-control condensed">
                                &nbsp;
                                <label><img src="/nagiosxi/images/critical_small.png" class="tt-bind" title="Critical Threshold"></label>
                                <input type="text" size="7" name="serviceargs[MemorySimpleHeap][critical]" value="' . encode_form_val($MemorySimpleHeap['critical']) . '" class="textfield form-control condensed">
                            </div>
                        </td>
                    </tr>
                    <tr class="vt">
                        <td class="vt">
                            <input type="checkbox" class="checkbox" id="eden-heap-enable" name="serviceargs[MemoryEden][enabled]"' . is_checked($MemoryEden['enabled'], 'on') . '>
                        </td>
                        <td>
                            <label for="eden-heap-enable" class="select-cf-option">'. _('Eden Space') . '</label>
                            <br/>' . _('Measures the memory usage of objects which haven\'t yet seen garbage collection.') . '
                            <div class="pad-t5">
                                <label><img src="/nagiosxi/images/error.png" class="tt-bind" title="Warning Threshold"></label>
                                <input type="text" size="7" name="serviceargs[MemoryEden][warning]" value="' . encode_form_val($MemoryEden['warning']) . '" class="textfield form-control condensed">
                                &nbsp;
                                <label><img src="/nagiosxi/images/critical_small.png" class="tt-bind" title="Critical Threshold"></label>
                                <input type="text" size="7" name="serviceargs[MemoryEden][critical]" value="' . encode_form_val($MemoryEden['critical']) . '" class="textfield form-control condensed">
                            </div>
                        </td>
                    </tr>
                    <tr class="vt">
                        <td class="vt">
                            <input type="checkbox" class="checkbox" id="survivor-heap-enable" name="serviceargs[MemorySurvivor][enabled]"' . is_checked($MemorySurvivor['enabled'], 'on') . '>
                        </td>
                        <td>
                            <label for="survivor-heap-enable" class="select-cf-option">'. _('Survivor/Tenured Space') . '</label>
                            <br/>' . _('Measures the memory usage of the objects which have survived at least one garbage collection cycle.') . '
                            <div class="pad-t5">
                                <label><img src="/nagiosxi/images/error.png" class="tt-bind" title="Warning Threshold"></label>
                                <input type="text" size="7" name="serviceargs[MemorySurvivor][warning]" value="' . encode_form_val($MemorySurvivor['warning']) . '" class="textfield form-control condensed">
                                &nbsp;
                                <label><img src="/nagiosxi/images/critical_small.png" class="tt-bind" title="Critical Threshold"></label>
                                <input type="text" size="7" name="serviceargs[MemorySurvivor][critical]" value="' . encode_form_val($MemorySurvivor['critical']) . '" class="textfield form-control condensed">
                            </div>
                        </td>
                    </tr>
                    <tr class="vt">
                        <td class="vt">
                            <input type="checkbox" class="checkbox" id="oldgen-heap-enable" name="serviceargs[MemoryOld][enabled]"' . is_checked($MemoryOld['enabled'], 'on') . '>
                        </td>
                        <td>
                            <label for="oldgen-heap-enable" class="select-cf-option">'. _('Old Gen') . '</label>
                            <br/>' . _('Measures the memory usage of the objects which have been moved out of Survivor Space but are still in use.') . '
                            <div class="pad-t5">
                                <label><img src="/nagiosxi/images/error.png" class="tt-bind" title="Warning Threshold"></label>
                                <input type="text" size="7" name="serviceargs[MemoryOld][warning]" value="' . encode_form_val($MemoryOld['warning']) . '" class="textfield form-control condensed">
                                &nbsp;
                                <label><img src="/nagiosxi/images/critical_small.png" class="tt-bind" title="Critical Threshold"></label>
                                <input type="text" size="7" name="serviceargs[MemoryOld][critical]" value="' . encode_form_val($MemoryOld['critical']) . '" class="textfield form-control condensed">
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>';

            $MemorySimpleNonHeap = array('enabled' => '', 'warning' => '', 'critical' => '', 'unit' => '1073741824');
            if (array_key_exists('MemorySimpleNonHeap',$serviceargs)) {
                $MemorySimpleNonHeap = $serviceargs['MemorySimpleNonHeap'];
            }

            $MemoryCodeCache =  array('enabled' => '', 'warning' => '', 'critical' => '');
            if (array_key_exists('MemoryCodeCache',$serviceargs)) {
                $MemoryCodeCache = $serviceargs['MemoryCodeCache'];
            }

            $MemoryCompressedClass =  array('enabled' => '', 'warning' => '', 'critical' => '');
            if (array_key_exists('MemoryCompressedClass',$serviceargs)) {
                $MemoryCompressedClass = $serviceargs['MemoryCompressedClass'];
            }

            $MemoryMetaspace =  array('enabled' => 'on', 'warning' => '32', 'critical' => '64');
            if (array_key_exists('MemoryMetaspace',$serviceargs)) {
                $MemoryMetaspace = $serviceargs['MemoryMetaspace'];
            }

            $output .= '

            <h5 class="ul">' . _("Non-Heap-Allocated Memory") . '</h5>
            <table class="table table-no-border table-auto-width table-padded">
                <label for="nonheap-unit" class="select-cf-option" style="margin-right:5px;">'. _('Measure these statistics in: ') . '</label>
                <select class="form-control" id="nonheap-unit" name="serviceargs[MemorySimpleNonHeap][unit]">
                    <option value="1073741824" ' . is_selected($MemorySimpleNonHeap['unit'], '1073741824') . '> ' . _("GiB") . '</option>
                    <option value="1048576" ' . is_selected($MemorySimpleNonHeap['unit'], '1048576') . '> ' . _("MiB") . '</option>
                    <option value="1024" ' . is_selected($MemorySimpleNonHeap['unit'], '1024') . '> ' . _("KiB") . '</option>
                    <option value="1" ' . is_selected($MemorySimpleNonHeap['unit'], '1') . '> ' . _("Bytes") . '</option>
                </select>
                <tbody>
                    <tr class="vt">
                        <td class="vt">
                            <input type="checkbox" class="checkbox" id="simple-nonheap-enable" name="serviceargs[MemorySimpleNonHeap][enabled]"' . is_checked($MemorySimpleNonHeap['enabled'], 'on') . '>
                        </td>
                        <td>
                            <label for="simple-nonheap-enable" class="select-cf-option">'. _('Simple Non-Heap-Allocated Memory') . '</label>
                            <br/>' . _('Measures the memory usage of everything not on the heap.') . '
                            <div class="pad-t5">
                                <label><img src="/nagiosxi/images/error.png" class="tt-bind" title="Warning Threshold"></label>
                                <input type="text" size="7" name="serviceargs[MemorySimpleNonHeap][warning]" value="' . encode_form_val($MemorySimpleNonHeap['warning']) . '" class="textfield form-control condensed">
                                &nbsp;
                                <label><img src="/nagiosxi/images/critical_small.png" class="tt-bind" title="Critical Threshold"></label>
                                <input type="text" size="7" name="serviceargs[MemorySimpleNonHeap][critical]" value="' . encode_form_val($MemorySimpleNonHeap['critical']) . '" class="textfield form-control condensed">
                            </div>
                        </td>
                    </tr>
                    <tr class="vt">
                        <td class="vt">
                            <input type="checkbox" class="checkbox" id="codecache-nonheap-enable" name="serviceargs[MemoryCodeCache][enabled]"' . is_checked($MemoryCodeCache['enabled'], 'on') . '>
                        </td>
                        <td>
                            <label for="codecache-nonheap-enable" class="select-cf-option">'. _('Code Cache') . '</label>
                            <br/>' . _('Measures the memory usage of the JIT-compiled code.') . '
                            <div class="pad-t5">
                                <label><img src="/nagiosxi/images/error.png" class="tt-bind" title="Warning Threshold"></label>
                                <input type="text" size="7" name="serviceargs[MemoryCodeCache][warning]" value="' . encode_form_val($MemoryCodeCache['warning']) . '" class="textfield form-control condensed">
                                &nbsp;
                                <label><img src="/nagiosxi/images/critical_small.png" class="tt-bind" title="Critical Threshold"></label>
                                <input type="text" size="7" name="serviceargs[MemoryCodeCache][critical]" value="' . encode_form_val($MemoryCodeCache['critical']) . '" class="textfield form-control condensed">
                            </div>
                        </td>
                    </tr>
                    <tr class="vt">
                        <td class="vt">
                            <input type="checkbox" class="checkbox" id="compressedclass-nonheap-enable" name="serviceargs[MemoryCompressedClass][enabled]"' . is_checked($MemoryCompressedClass['enabled'], 'on') . '>
                        </td>
                        <td>
                            <label for="compressedclass-nonheap-enable" class="select-cf-option">'. _('Compressed Class Space') . '</label>
                            <br/>' . sprintf(_('Measures the memory usage of the compressed classes in your %s instance.'), $noun_short) . '
                            <div class="pad-t5">
                                <label><img src="/nagiosxi/images/error.png" class="tt-bind" title="Warning Threshold"></label>
                                <input type="text" size="7" name="serviceargs[MemoryCompressedClass][warning]" value="' . encode_form_val($MemoryCompressedClass['warning']) . '" class="textfield form-control condensed">
                                &nbsp;
                                <label><img src="/nagiosxi/images/critical_small.png" class="tt-bind" title="Critical Threshold"></label>
                                <input type="text" size="7" name="serviceargs[MemoryCompressedClass][critical]" value="' . encode_form_val($MemoryCompressedClass['critical']) . '" class="textfield form-control condensed">
                            </div>
                        </td>
                    </tr>
                    <tr class="vt">
                        <td class="vt">
                            <input type="checkbox" class="checkbox" id="metaspace-nonheap-enable" name="serviceargs[MemoryMetaspace][enabled]"' . is_checked($MemoryMetaspace['enabled'], 'on') . '>
                        </td>
                        <td>
                            <label for="metaspace-nonheap-enable" class="select-cf-option">'. _('Metaspace') . '</label>
                            <br/>' . sprintf(_('Measures the memory usage of the class metadata in your %s instance.'), $noun_short) . '
                            <div class="pad-t5">
                                <label><img src="/nagiosxi/images/error.png" class="tt-bind" title="Warning Threshold"></label>
                                <input type="text" size="7" name="serviceargs[MemoryMetaspace][warning]" value="' . encode_form_val($MemoryMetaspace['warning']) . '" class="textfield form-control condensed">
                                &nbsp;
                                <label><img src="/nagiosxi/images/critical_small.png" class="tt-bind" title="Critical Threshold"></label>
                                <input type="text" size="7" name="serviceargs[MemoryMetaspace][critical]" value="' . encode_form_val($MemoryMetaspace['critical']) . '" class="textfield form-control condensed">
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>';

            if ($wizard_name === 'java_tomcat') {

                $requestproc = 0;
                if (array_key_exists("requestproc", $serviceargs)) {
                    $requestproc = $serviceargs['requestproc'];
                }

                $output .= '

                <h5 class="ul">' . _("Global Request Processors") . '</h5>
                <p>'. sprintf(_("To find your global request processors' MBean Names, access the %s instance with jconsole."), $noun_short) . '
                <table class="table table-no-border table-auto-width table-padded adddeleterow">
                    <thead>
                        <tr>
                        <th>
                            ' . _('Request Processor MBean Name') . '
                        </th>
                        <th>
                            ' . _('Check Type') .'
                        </th>
                        <th>
                            ' . _('Warning Threshold') .'
                        </th>
                        <th>
                            ' . _('Critical Threshold') .'
                        </th>
                        </tr>
                    </thead>
                    <tbody>

                    ';
                    if (is_array($requestproc)) {
                        foreach($requestproc as $index => $value_array) {
                            $output .='
                        <tr class="vt">
                            <td>
                                <input type="text" size="30" name="serviceargs[requestproc][' . $index . '][on]" value="' . $value_array['on'] . '" class="textfield form-control">
                            </td>
                            <td>
                                <select name="serviceargs[requestproc][' . $index . '][type]" class="form-control">
                                    <option value="RequestsPerMinute" ' . is_selected($value_array['type'], 'RequestsPerMinute') . '>' . _('Requests Per Minute') . '</option>
                                    <option value="BytesPerMinute" ' . is_selected($value_array['type'], 'BytesPerMinute') . '>' . _('Bytes Per Minute') . '</option>
                                    <option value="BytesPerRequest" ' . is_selected($value_array['type'], 'BytesPerRequest') . '>' . _('Bytes Per Request') . '</option>
                                    <option value="ErrorsPerMinute" ' . is_selected($value_array['type'], 'ErrorsPerMinute') . '>' . _('Errors Per Minute') . '</option>
                                    <option value="ProcessingTimePerRequest" ' . is_selected($value_array['type'], 'ProcessingTimePerRequest') . '>' . _('Processing Time Per Request') . '</option>

                                </select>
                            </td>
                            <td>
                                <input type="text" size="10" name="serviceargs[requestproc][' . $index . '][warning]" value="' . $value_array['warning'] . '" class="textfield form-control">
                            </td>
                            <td>
                                <input type="text" size="10" name="serviceargs[requestproc][' . $index . '][critical]" value="' . $value_array['critical'] . '" class="textfield form-control">
                            </td>
                        </tr>
                            ';
                        }
                    }
                    else {
                        $output .= '
                        <tr class="vt">
                            <td>
                                <input type="text" size="35" name="serviceargs[requestproc][0][on]" value="" class="textfield form-control">
                            </td>
                            <td>
                                <select name="serviceargs[requestproc][0][type]" id="" class="form-control">
                                    <option value="RequestsPerMinute">' . _('Requests Per Minute') . '</option>
                                    <option value="BytesPerMinute">' . _('Bytes Per Minute') . '</option>
                                    <option value="BytesPerRequest">' . _('Bytes Per Request') . '</option>
                                    <option value="ErrorsPerMinute">' . _('Errors Per Minute') . '</option>
                                    <option value="ProcessingTimePerRequest">' . _('Processing Time Per Request') . '</option>

                                </select>
                            </td>
                            <td>
                                <input type="text" size="15" name="serviceargs[requestproc][0][warning]" value="" class="textfield form-control">
                            </td>
                            <td>
                                <input type="text" size="15" name="serviceargs[requestproc][0][critical]" value="" class="textfield form-control">
                            </td>
                        </tr>
                        ';
                    }
                    $output .= '
                    </tbody>
                </table>
                <br>';
            }

            $ProcessCPUUsage = array('enabled' => 'on', 'warning' => '50', 'critical' => '70');
            if (array_key_exists('ProcessCPUUsage',$serviceargs)) {
                $ProcessCPUUsage = $serviceargs['ProcessCPUUsage'];
            }

            $SystemCPUUsage =  array('enabled' => 'on', 'warning' => '70', 'critical' => '90');
            if (array_key_exists('SystemCPUUsage',$serviceargs)) {
                $SystemCPUUsage = $serviceargs['SystemCPUUsage'];
            }

            $Uptime =  array('enabled' => 'on', 'warning' => '1500:', 'critical' => '300:');
            if (array_key_exists('Uptime',$serviceargs)) {
                $Uptime = $serviceargs['Uptime'];
            }

            $ClassCount =  array('enabled' => '', 'warning' => '10000', 'critical' => '50000');
            if (array_key_exists('ClassCount',$serviceargs)) {
                $ClassCount = $serviceargs['ClassCount'];
            }

            $ThreadCount =  array('enabled' => '', 'warning' => '150', 'critical' => '190');
            if (array_key_exists('ThreadCount',$serviceargs)) {
                $ThreadCount = $serviceargs['ThreadCount'];
            }

            $output .= '

            <h5 class="ul">' . _("Other System Statistics") . '</h5>
            <table class="table table-no-border table-auto-width table-padded">
                <tbody>
                    <tr class="vt">
                        <td class="vt">
                            <input type="checkbox" class="checkbox" id="ProcessCPUUsage-enable" name="serviceargs[ProcessCPUUsage][enabled]"' . is_checked($ProcessCPUUsage['enabled'], 'on') . '>
                        </td>
                        <td>
                            <label for="ProcessCPUUsage-enable" class="select-cf-option">'. _('JVM CPU Usage') . '</label>
                            <br/>' . _('Measures the CPU Usage incurred by the JVM alone (values are between 0 and 100)') . '
                            <div class="pad-t5">
                                <label><img src="/nagiosxi/images/error.png" class="tt-bind" title="Warning Threshold"></label>
                                <input type="text" size="6" name="serviceargs[ProcessCPUUsage][warning]" value="' . encode_form_val($ProcessCPUUsage['warning']) . '" class="textfield form-control condensed"> &percnt;
                                &nbsp;
                                <label><img src="/nagiosxi/images/critical_small.png" class="tt-bind" title="Critical Threshold"></label>
                                <input type="text" size="6" name="serviceargs[ProcessCPUUsage][critical]" value="' . encode_form_val($ProcessCPUUsage['critical']) . '" class="textfield form-control condensed"> &percnt;
                            </div>
                        </td>
                    </tr>
                    <tr class="vt">
                        <td class="vt">
                            <input type="checkbox" class="checkbox" id="SystemCPUUsage-enable" name="serviceargs[SystemCPUUsage][enabled]"' . is_checked($SystemCPUUsage['enabled'], 'on') . '>
                        </td>
                        <td>
                            <label for="SystemCPUUsage-enable" class="select-cf-option">'. _('System CPU Usage') . '</label>
                            <br/>' . _('Measures the CPU Usage of the system as a whole (values are between 0 and 100).') . '
                            <div class="pad-t5">
                                <label><img src="/nagiosxi/images/error.png" class="tt-bind" title="Warning Threshold"></label>
                                <input type="text" size="6" name="serviceargs[SystemCPUUsage][warning]" value="' . encode_form_val($SystemCPUUsage['warning']) . '" class="textfield form-control condensed"> &percnt;
                                &nbsp;
                                <label><img src="/nagiosxi/images/critical_small.png" class="tt-bind" title="Critical Threshold"></label>
                                <input type="text" size="6" name="serviceargs[SystemCPUUsage][critical]" value="' . encode_form_val($SystemCPUUsage['critical']) . '" class="textfield form-control condensed"> &percnt;
                            </div>
                        </td>
                    </tr>
                    <tr class="vt">
                        <td class="vt">
                            <input type="checkbox" class="checkbox" id="Uptime-enable" name="serviceargs[Uptime][enabled]"' . is_checked($Uptime['enabled'], 'on') . '>
                        </td>
                        <td>
                            <label for="eden-heap-enable" class="select-cf-option">'. _('Uptime') . '</label>
                            <br/>' . _('Measures the uptime of the JVM in seconds.') . '
                            <div class="pad-t5">
                                <label><img src="/nagiosxi/images/error.png" class="tt-bind" title="Warning Threshold"></label>
                                <input type="text" size="7" name="serviceargs[Uptime][warning]" value="' . encode_form_val($Uptime['warning']) . '" class="textfield form-control condensed">
                                &nbsp;
                                <label><img src="/nagiosxi/images/critical_small.png" class="tt-bind" title="Critical Threshold"></label>
                                <input type="text" size="7" name="serviceargs[Uptime][critical]" value="' . encode_form_val($Uptime['critical']) . '" class="textfield form-control condensed">
                            </div>
                        </td>
                    </tr>
                    <tr class="vt">
                        <td class="vt">
                            <input type="checkbox" class="checkbox" id="ClassCount-enable" name="serviceargs[ClassCount][enabled]"' . is_checked($ClassCount['enabled'], 'on') . '>
                        </td>
                        <td>
                            <label for="ClassCount-enable" class="select-cf-option">'. _('Class Count') . '</label>
                            <br/>' . _('Measures the number of currently-loaded classes in the JVM.') . '
                            <div class="pad-t5">
                                <label><img src="/nagiosxi/images/error.png" class="tt-bind" title="Warning Threshold"></label>
                                <input type="text" size="7" name="serviceargs[ClassCount][warning]" value="' . encode_form_val($ClassCount['warning']) . '" class="textfield form-control condensed">
                                &nbsp;
                                <label><img src="/nagiosxi/images/critical_small.png" class="tt-bind" title="Critical Threshold"></label>
                                <input type="text" size="7" name="serviceargs[ClassCount][critical]" value="' . encode_form_val($ClassCount['critical']) . '" class="textfield form-control condensed">
                            </div>
                        </td>
                    </tr>
                    <tr class="vt">
                        <td class="vt">
                            <input type="checkbox" class="checkbox" id="ThreadCount-enable" name="serviceargs[ThreadCount][enabled]"' . is_checked($ThreadCount['enabled'], 'on') . '>
                        </td>
                        <td>
                            <label for="ThreadCount-enable" class="select-cf-option">'. _('Thread Count') . '</label>
                            <br/>' . _('Measures the number of active threads in the JVM.') . '
                            <div class="pad-t5">
                                    <label><img src="/nagiosxi/images/error.png" class="tt-bind" title="Warning Threshold"></label>
                                    <input type="text" size="7" name="serviceargs[ThreadCount][warning]" value="' . encode_form_val($ThreadCount['warning']) . '" class="textfield form-control condensed">
                                    &nbsp;
                                    <label><img src="/nagiosxi/images/critical_small.png" class="tt-bind" title="Critical Threshold"></label>
                                    <input type="text" size="7" name="serviceargs[ThreadCount][critical]" value="' . encode_form_val($ThreadCount['critical']) . '" class="textfield form-control condensed">
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
            ';
            /* The quote and semicolon ends HTML for CONFIGWIZARD_MODE_GETSTAGE2HTML */ 
            /* $output will be passed back to XI framework and rendered to browser */
            /* The next line ends CONFIGWIZARD_MODE_GETSTAGE2HTML */
            break;

        /* Form validation for CONFIGWIZARD_MODE_GETSTAGE2HTML */ 
        case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:
            /* This defines $back variable, used for determining if the Back button */
            /* was clicked when the user was on CONFIGWIZARD_MODE_GETSTAGE4HTML */
            $back = array_key_exists("backButton", $_POST);         
            /* If the user came back from CONFIGWIZARD_MODE_GETSTAGE3HTML then we don't need to revalidate and check for errors */
            if ($back) break;
            

            $hostname_session = grab_array_var($_SESSION, 'hostname', '');
            $hostname = grab_array_var($inargs, 'hostname', $hostname_session);

            $address_session = grab_array_var($_SESSION, 'address', '');
            $address = grab_array_var($inargs, 'address', $address_session);

            $remote = grab_array_var($_SESSION, 'remote', '');

            $serviceargs = grab_array_var($_SESSION[$wizard_name], 'serviceargs', array());
            $serviceargs = grab_array_var($inargs, 'serviceargs', $serviceargs);

            $service_description = grab_array_var($_SESSION[$wizard_name], 'service_description', '');
            $service_description = grab_array_var($inargs, 'service_description', $service_description);

            $classpath = grab_array_var($_SESSION[$wizard_name], 'classpath', '.');
            $classpath = grab_array_var($inargs, 'classpath', $classpath);

            $combine = grab_array_var($_SESSION[$wizard_name], 'combine', 'off');
            $combine = grab_array_var($inargs, 'combine', $combine);

            $_SESSION[$wizard_name]['classpath'] = $classpath;

            $valid_types = array(
                "MemorySimpleHeap",
                "MemoryEden",
                "MemorySurvivor",
                "MemoryOld",
                "MemorySimpleNonHeap",
                "MemoryCodeCache",
                "MemoryCompressedClass",
                "MemoryMetaspace",
                "requestproc",
                "ProcessCPUUsage",
                "SystemCPUUsage",
                "Uptime",
                "ClassCount",
                "ThreadCount",
            );

            foreach($serviceargs as $type => $values) {
                if (!in_array($type, $valid_types)) {
                    $errmsg[$errors++] = _("Check type ") . encode_form_val($type) . _(" is invalid.");
                }
            }

            if ($wizard_name === 'java_tomcat') {

                $valid_types = array(
                    "RequestsPerMinute",
                    "BytesPerMinute",
                    "BytesPerRequest",
                    "ErrorsPerMinute",
                    "ProcessingTimePerRequest",
                );

                foreach ($serviceargs['requestproc'] as $index => $values) {
                    if (!in_array($values['type'], $valid_types)) {
                        $errmsg[$errors++] = _("Check type ") . encode_form_val($values['type']) . _(" is invalid.");
                    }
                }
            }

            if (!have_value($combine))
                $combine = "off";

            if (!have_value($hostname)) {
                $errmsg[$errors++] = _("No host name specified.");
            }
            elseif (!is_valid_host_name($hostname)) {
                $errmsg[$errors++] = _("Invalid host name.");
            }
            $_SESSION[$wizard_name]['hostname'] = $hostname;

            if (!have_value($address)) {
                $errmsg[$errors++] = _("No IP Address specified");
            }
            $_SESSION[$wizard_name]['address'] = $address;
            

            if (!have_value($service_description)) {
                $errmsg[$errors++] = _("No service description specified.");
            } 

            $_SESSION[$wizard_name]['service_description'] = $service_description;

            if (empty($serviceargs)) {
                $errmsg[$errors++] = _("serviceargs is empty. This error should never be reached. Please contact the config wizard maintainer.");
            }

            if ($errors>0){
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
                if (!array_key_exists('serviceargs', $_SESSION[$wizard_name])) {
                    // If we've never assigned serviceargs to SESSION, it's fine to overwrite even if they're not valid. Same for combine.
                    $_SESSION[$wizard_name]['serviceargs'] = $serviceargs;
                    $_SESSION[$wizard_name]['combine'] = $combine;
                }
            }
            else {
                $_SESSION[$wizard_name]['serviceargs'] = $serviceargs;
                $_SESSION[$wizard_name]['combine'] = $combine;
            }

            /* The next line ends CONFIGWIZARD_MODE_VALIDATESTAGE2DATA */
            break;

        
        case CONFIGWIZARD_MODE_GETSTAGE3HTML:
            $back = array_key_exists('backButton', $_POST);
            $output = '';
            break;
            
            
        case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:

            $back = array_key_exists("backButton", $_POST);
            if ($back) {
                break;
            }

            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }

            break;
    
        case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:

            $output = '';
            break;
        
        
        case CONFIGWIZARD_MODE_GETOBJECTS:
            $remote = $_SESSION[$wizard_name]['remote'];
            $address = $_SESSION[$wizard_name]['address'];
            $hostname = $_SESSION[$wizard_name]['hostname'];
            $service_url = $_SESSION[$wizard_name]['service_url'];
            $username = $_SESSION[$wizard_name]['username'];
            $password = $_SESSION[$wizard_name]['password'];
            $service_description = $_SESSION[$wizard_name]['service_description'];
            $classpath = $_SESSION[$wizard_name]['classpath'];
            $combine = $_SESSION[$wizard_name]['combine'];

            if ($remote === "NCPA") {     
                $token = $_SESSION[$wizard_name]['token'];
                $port = $_SESSION[$wizard_name]['port'];
            }

            $serviceargs = $_SESSION[$wizard_name]['serviceargs'];

            $objs = array();
            if (!host_exists($hostname)) {

                $objs[] = array(
                    "type" => OBJECTTYPE_HOST,
                    "use" => 'xiwizard_java_as_host',
                    "host_name" => $hostname,
                    'icon_image' =>  $wizard_name . '.png',
                    "address" => $address,
                    "_xiwizard" => $wizard_name,
                );
            }

            $service_url_switch = "-s " . $service_url;

            if (have_value($username)) {
                $username_switch = "-u '$username'";    
            }

            if (have_value($password)) {
                $password_switch = "-p '$password'";
            }

            $server_type_switch = "-t " . substr($wizard_name, 5); // i.e. 'java_tomcat' --> '-t tomcat'

            $first_one = true;

            $check_name = "";
            $warning = "";
            $critical = "";
            if ($combine === "off") {
                $check_name = array();
                $warning = array();
                $critical = array();
            }

            // Plugin wants bytes
            $heap_allocated = array('MemorySimpleHeap', 'MemoryEden', 'MemorySurvivor', 'MemoryOld');
            if (is_array($serviceargs['MemorySimpleHeap']) && isset($serviceargs['MemorySimpleHeap']['unit'])) {
                foreach ($heap_allocated as $statistic) {
                    $serviceargs[$statistic]['warning'] = java_as_scale_threshold($serviceargs[$statistic]['warning'], $serviceargs['MemorySimpleHeap']['unit']);
                    $serviceargs[$statistic]['critical'] = java_as_scale_threshold($serviceargs[$statistic]['critical'], $serviceargs['MemorySimpleHeap']['unit']);
                }
            }

            $non_heap_allocated = array('MemorySimpleNonHeap', 'MemoryCompressedClass', 'MemoryCodeCache', 'MemoryMetaspace');
            if (is_array($serviceargs['MemorySimpleNonHeap']) && isset($serviceargs['MemorySimpleNonHeap']['unit'])) {
                foreach ($non_heap_allocated as $statistic) {
                    $serviceargs[$statistic]['warning'] = java_as_scale_threshold($serviceargs[$statistic]['warning'], $serviceargs['MemorySimpleNonHeap']['unit']);
                    $serviceargs[$statistic]['critical'] = java_as_scale_threshold($serviceargs[$statistic]['critical'], $serviceargs['MemorySimpleNonHeap']['unit']);
                }
            }

            // Plugin wants ms
            if (is_array($serviceargs['Uptime'])) {
                $serviceargs['Uptime']['warning'] = java_as_scale_threshold($serviceargs['Uptime']['warning'], 1000);
                $serviceargs['Uptime']['critical'] = java_as_scale_threshold($serviceargs['Uptime']['critical'], 1000);
            }

            foreach ($serviceargs as $type => $value) {
                if ($type !== "requestproc" && $value['enabled'] === "on") {
                    if ($combine === "on") {
                        if ($first_one) {
                            $check_name .= $type;
                            $warning .= $value['warning'];
                            $critical .= $value['critical'];
                            $first_one = !$first_one;
                        }
                        else {
                            $check_name .= ",$type";
                            $warning .= "," . $value['warning'];
                            $critical .= "," . $value['critical'];
                        }
                    }
                    else {
                        $check_name[] = $type;
                        $warning[] = $value['warning'];
                        $critical[] = $value['critical'];
                    }
                }
                else if ($wizard_name === 'java_tomcat' && $type === "requestproc") {

                    // rp_filter just checks that all indices have values.
                    $serviceargs[$type] = array_filter($value, 'java_as_rp_filter', ARRAY_FILTER_USE_BOTH);

                    if (have_value($serviceargs[$type])) {
                        if ($combine === 'on') {
                            if ($first_one) {
                                $check_name .= implode(",", $serviceargs[$type]['on']);
                                $warning .= implode(",", $serviceargs[$type]['warning']);
                                $critical .= implode(",", $serviceargs[$type]['critical']);
                                $first_one = !$first_one;
                            }
                            else {
                                $check_name .= "," . implode(",", $serviceargs[$type]['on']);
                                $warning .= "," . implode(",", $serviceargs[$type]['warning']);
                                $critical .= "," . implode(",", $serviceargs[$type]['critical']);
                            }
                        }
                        else {
                            $check_name = array_merge($check_name, $serviceargs[$type]['on']);
                            $warning = array_merge($warning, $serviceargs[$type]['warning']);
                            $critical = array_merge($critical, $serviceargs[$type]['critical']);
                        }
                    }
                }
            }

            if ($combine === 'on') {
                $check_name = array($check_name);
                $warning = array($warning);
                $critical = array($critical);
            }
            foreach ($check_name as $index => $not_used) {
                $plugin_opts = array($service_url_switch, $username_switch, $password_switch, $server_type_switch, "-C '" . $check_name[$index] . "'", "-w '" . $warning[$index] . "'", "-c '" . $critical[$index] . "'");
                if ($remote === "NCPA") {
                    foreach ($plugin_opts as $key => $value) {
                        $tmp = trim($value);
                        if (!empty($tmp)) {
                            $plugin_opts[$key] = "args=" . $value;
                        }
                        else {
                            unset($plugin_opts[$key]);
                        }
                    }
                    $plugin_opts = implode(",", $plugin_opts);
                    $all_options = "-t " . $token . " -P ". $port . " -M plugins/$plugin_name -q \"";
                    $all_options .= $plugin_opts . "\"";
                    $all_options = java_as_escape_exclamation_dollar($all_options);
                    $full_check_command = "check_xi_ncpa!$all_options";
                }
                else {
                    $plugin_opts = implode(" ", $plugin_opts);
                    $plugin_opts = java_as_escape_exclamation_dollar($plugin_opts);
                    $classpath = java_as_escape_exclamation_dollar($classpath);
                    $full_check_command = "check_xi_java_as!$plugin_opts!$classpath!";
                }

                $service_description_full = $service_description;
                if ($combine === "off") {
                    $service_description_full .= " " . $check_name[$index];
                }

                $objs[] = array(
                    'type'                  => OBJECTTYPE_SERVICE,
                    'host_name'             => $hostname,
                    'service_description'   => $service_description_full,
                    'icon_image'            => $wizard_name . '.png',
                    'check_command'         => $full_check_command,
                    '_xiwizard'             => $wizard_name,
                );
            }

            /* Return the object definitions to the wizard */
            $outargs[CONFIGWIZARD_NAGIOS_OBJECTS] = $objs;
            
            /* clear the session variables for this wizard run */
            unset($_SESSION[$wizard_name]); 
            
            /* The next line ends CONFIGWIZARD_MODE_GETOBJECTS */
            break;
            
        default:
            break;          
    };        
    return $output;
}

function java_weblogic_configwizard_func($mode = '',$inargs = null,&$outargs,&$result){

    /* Define the wizard name */
    $wizard_name = 'java_weblogic';

    /* Prerequisite software */
    $NCPA_download_url = "https://www.nagios.org/ncpa/#downloads";
    $NCPA_docs_url = "https://www.nagios.org/ncpa/#docs";
    $wlsagent_package = "/nagiosxi/includes/configwizards/java-as/plugins/wlsagent.tar.gz";
    $java_weblogic_plugin_url = "/nagiosxi/includes/configwizards/java-as/plugins/check_wlsagent.sh";
    $java_weblogic_docs_url = "https://assets.nagios.com/downloads/nagiosxi/docs/How-to-Monitor-WebLogic-With-Nagios-XI.pdf"; 
    /* rip in peace my sweet nrpe */
    // $agent_url = "https://assets.nagios.com/downloads/nagiosxi/agents/linux-nrpe-agent.tar.gz";
    // $agent_doc_url = "https://assets.nagios.com/downloads/nagiosxi/docs/Installing_The_XI_Linux_Agent.pdf";

    /* Initialize return code and output */
    $result = 0;
    $output = '';
    
    /* Initialize output args */
    $outargs[CONFIGWIZARD_PASSBACK_DATA] = $inargs;

    switch ($mode) {
        case CONFIGWIZARD_MODE_GETSTAGE1HTML:
            /* This defines $nextstep variable, used for determining if the user did not */
            /* provide correct information when the user was on CONFIGWIZARD_MODE_GETSTAGE1HTML */
            $nextstep = htmlentities(grab_array_var($_POST,'nextstep',false),ENT_QUOTES);

            /* Determine if this is the first wizard run */
            if ($nextstep == '') {
                /* Clear the session array to be sure it is blank */
                unset($_SESSION[$wizard_name]); 
            }

            /* Fresh Wizard Run */
            /* OR */
            /* Continuing from CONFIGWIZARD_MODE_VALIDATESTAGE1DATA due to user error */
            
            if (!isset($_POST['address'])) {
                /* Fresh Wizard Run */
                
                $_SESSION[$wizard_name] = array(); 
                
                $remote = '';
                $hostname = '';
                $IP = '';
                $WLSAgent_port = '9090';
                $JMX_T3_port = '7001';
                $username = '';
                $password = '';
            }
            else {

                /* General */
                $remote_session = grab_array_var($_SESSION[$wizard_name], 'remote', '');
                $remote = grab_array_var($inargs, 'remote', $remote_session);
                $hostname_session = grab_array_var($_SESSION[$wizard_name], 'hostname', '');
                $hostname = grab_array_var($inargs, 'hostname', $hostname_session);
                $IP_session = grab_array_var($_SESSION[$wizard_name], 'IP', '');
                $IP = grab_array_var($inargs, 'IP', $hostname_session);
                $WLSAgent_port_session = grab_array_var($_SESSION[$wizard_name], 'WLSAgent_port', '9090');
                $WLSAgent_port = grab_array_var($inargs, 'WLSAgent_port', $port_session);
                $JMX_T3_port_session = grab_array_var($_SESSION[$wizard_name], 'JMX_T3_port', '7001');
                $JMX_T3_port = grab_array_var($inargs, 'JMX_T3_port', $port_session);

                /* Credentials */
                $username_session = grab_array_var($_SESSION[$wizard_name], 'username', '');
                $username = grab_array_var($inargs, 'username', $username_session);
                $password_session = grab_array_var($_SESSION[$wizard_name], 'password', '');
                $password = grab_array_var($inargs, 'password', $password_session);
            }
                
            
            
            /* Now we are creating the HTML for CONFIGWIZARD_MODE_GETSTAGE1HTML */ 
            $output = '
            <h5 class="ul">' . _('Plugin and Agent Setup') . '</h5>
            <p>' . _('You will need to set up WLSAgent on your WebLogic server in order to monitor it. You may or may not also need NCPA installed on the server, depending on your monitoring preferences.') . '</p>
            <ul style="padding: 0 0 0 30px;">
                <li><a href="' . $wlsagent_package . '" target="_blank">' . _("Download the WLS Agent") . '</a></li>
                <li class="ncpa-only"><a href="' . $NCPA_download_url . '" target="_blank">' . _('Download and install the latest version of NCPA') . '</a></li>
                <li class="ncpa-only"><a href="' . $java_weblogic_plugin_url . '" target="_blank">' . _('Install the Java Application Server Plugin') . '</a></li>
                <li>' . _('Additional documentation for ') . '<a href="' . $NCPA_docs_url . '" target="_blank">' . _('NCPA') . '</a>
                    ' . _(' and for ') . '<a href="' . $java_weblogic_docs_url . '" target="_blank">' . _('monitoring application servers.') . '</a></li>
            </ul>
            <h5 class="ul">' . _('WebLogic Server Information') . '</h5>
            <table class="table table-condensed table-no-border table-auto-width">
                <tr>
                    <td class="vt">
                        <label for="remote">' . _('Access WebLogic via:') . '</label>
                    </td>
                    <td>
                        <select name="remote" id="remote" class="form-control">
                            <option value="wget" ' . is_selected($remote, "wget") . '>' . _('Direct HTTP connection') . '</option>
                            <option value="NCPA" ' . is_selected($remote, "NCPA") . '>' . _('Remote Agent (NCPA)') . '</option>
                        </select>
                    </td>
                <tr>
                    <td class="vt">
                        <label for="hostname">' . _("Nagios Hostname") . '</label>
                    </td>
                    <td>
                        <input type="text" size="40" name="hostname" id="hostname" value="' . encode_form_val($hostname) . '" class="form-control">
                        <div class="subtext">' . _("The host name you want associated with this check.") . '</div>
                    </td>
                </tr>
                <tr>
                    <td class="vt">
                        <label for="IP">' . _("DNS Hostname/IP Address") . '</label>
                    </td>
                    <td>
                        <input type="text" size="40" name="IP" id="IP" value="' . encode_form_val($IP) . '" class="form-control">
                        <div class="subtext">' . _("The hostname/IP address of your WebLogic instance.") . '</div>
                    </td>
                </tr>
                <tr>
                    <td class="vt">
                        <label for="WLSAgent_port">' . _("WLSAgent Port") . '</label>
                    </td>
                    <td>
                        <input type="text" size="40" name="WLSAgent_port" id="WLSAgent_port" value="'.encode_form_val($WLSAgent_port).'" class="form-control">
                    </td>
                </tr>
                <tr>
                    <td class="vt">
                        <label for="JMX_T3_port">' . _("JMX T3 Port") . '</label>
                    </td>
                    <td>
                        <input type="text" size="40" name="JMX_T3_port" id="JMX_T3_port" value="'.encode_form_val($JMX_T3_port).'" class="form-control">
                    </td>
                </tr>
                <tr>
                    <td class="vt">
                        <label for="username">' . _('WebLogic Username') . '</label>
                    </td>
                    <td>
                        <input type="text" size="40" name="username" id="username" value="'.encode_form_val($username).'" class="form-control">
                        <div class="subtext">' . _('The username for the WebLogic domain to monitor.') . ' </div>
                    </td>
                </tr>
                <tr>
                    <td class="vt">
                        <label for="password">' . _('WebLogic Password') . '</label>
                    </td>
                    <td>
                        <input type="password" size="40" name="password" id="password" value="'.encode_form_val($password).'" class="form-control">
                        <div class="subtext">' . _('The password for the WebLogic user above.') . ' </div>
                    </td>
                </tr>
            </table>

            <h5 class="ncpa-only"> ' . _("NCPA Information") . '</h5>
            <table class="ncpa-only table table-condensed table-no-border table-auto-width">
                <tr>
                    <td class="vt">
                        <label for="port">' . _("NCPA Listener Port") . '</label>
                    </td>
                    <td>
                        <input type="text" size="40" name="port" id="port" value="'.encode_form_val($port).'" class="form-control">
                    </td>
                </tr>
                <tr class="ncpa-only">
                    <td class="vt">
                        <label for="token">' . _("NCPA Token") . '</label>
                    </td>
                    <td>
                        <input type="text" size="40" name="token" id="token" value="'.encode_form_val($token).'" class="form-control">
                    </td>
                </tr>
            </table>


            <script>
            $(document).ready(function () {
                $("#remote").change(function () {
                    if ($(this).val() === "wget") {
                        $(".ncpa-only").hide();
                    }
                    else { 
                        // using NCPA 
                        $(".ncpa-only").show();
                    }
                });

                // Initialize
                if($("#remote").val() === "wget") {
                    $(".ncpa-only").hide();
                }
                else { 
                    $(".ncpa-only").show();
                }

            });
            </script>
                ';
            break;

            
        /* Form validation for CONFIGWIZARD_MODE_GETSTAGE1HTML */
        case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:      
            $back = htmlentities(grab_array_var($_POST,'backButton',false),ENT_QUOTES);     
            
            if ($back) break;   

            /* General */
            $remote_session = grab_array_var($_SESSION[$wizard_name], 'remote', '');
            $remote = grab_array_var($inargs, 'remote', $remote_session);
            $hostname_session = grab_array_var($_SESSION[$wizard_name], 'hostname', '');
            $hostname = grab_array_var($inargs, 'hostname', $host_name_session);
            $IP_session = grab_array_var($_SESSION[$wizard_name], 'IP', '');
            $IP = grab_array_var($inargs, 'IP', $IP_session);

            $WLSAgent_port_session = grab_array_var($_SESSION[$wizard_name], 'WLSAgent_port', '5693');
            $WLSAgent_port = grab_array_var($inargs, 'WLSAgent_port', $port_session);
            $WLSAgent_port = intval($WLSAgent_port);
            $JMX_T3_port_session = grab_array_var($_SESSION[$wizard_name], 'JMX_T3_port', '5693');
            $JMX_T3_port = grab_array_var($inargs, 'JMX_T3_port', $port_session);
            $JMX_T3_port = intval($JMX_T3_port);

            $username_session = grab_array_var($_SESSION[$wizard_name], 'username', '');
            $username = grab_array_var($inargs, 'username', $username_session);
            $password_session = grab_array_var($_SESSION[$wizard_name], 'password', '');
            $password = grab_array_var($inargs, 'password', $password_session);

            $port_session = grab_array_var($_SESSION[$wizard_name], 'port', '');
            $port = grab_array_var($inargs, 'port', $port_session);
            $token_session = grab_array_var($_SESSION[$wizard_name], 'token', '');
            $token = grab_array_var($inargs, 'token', $token_session);
            
            $errors = 0;
            $errmsg = array();
            if (!have_value($hostname))
                $errmsg[$errors++] = _('Please specify a nagios host name.');
            if (!have_value($IP))
                $errmsg[$errors++] = _('Please specify a DNS Hostname/IP Address');

            if (!have_value($WLSAgent_port)) // Shouldn't be possible to trigger this.
                $errmsg[$errors++] = _('Please specify the port of your WLS Agent.'); 
            if (!have_value($JMX_T3_port)) // Or this.
                $errmsg[$errors++] = _('Please specify the JMX T3 port of your WebLogic server');

            if ($remote === "NCPA" && !have_value($port))
                $errmsg[$errors++] = _('Please specify the NCPA Listener port');
            if ($remote === "NCPA" && !have_value($token))
                $errmsg[$errors++] = _('Please specify the NCPA API token.');

            /* TODO: 
             * Include a thing to test the JMX connection? 
             * Should be doable since the check is now just doing wget. */

            /* Check to see if the $errors array contains errors */
            if ($errors>0){
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }
            else {
                $_SESSION[$wizard_name]['remote'] = $remote;
                $_SESSION[$wizard_name]['hostname'] = $hostname;
                $_SESSION[$wizard_name]['IP'] = $IP;
                $_SESSION[$wizard_name]['WLSAgent_port'] = $WLSAgent_port;
                $_SESSION[$wizard_name]['JMX_T3_port'] = $JMX_T3_port;
                $_SESSION[$wizard_name]['username'] = $username;
                $_SESSION[$wizard_name]['password'] = $password;
                $_SESSION[$wizard_name]['port'] = $port;
                $_SESSION[$wizard_name]['token'] = $token;

            }
            
            /* The next line ends CONFIGWIZARD_MODE_VALIDATESTAGE1DATA */
            break;


            
        case CONFIGWIZARD_MODE_GETSTAGE2HTML:
            /* This defines $back variable, used for determining if the Back button */
            /* was clicked when the user was on CONFIGWIZARD_MODE_GETSTAGE3HTML */
            $back = htmlentities(grab_array_var($_POST,'backButton',false),ENT_QUOTES);
            
            $service_description = grab_array_var($_SESSION[$wizard_name], 'service_description', _("WebLogic Statistics"));
            $service_description = grab_array_var($inargs, 'service_description', $service_description);

            $combine = grab_array_var($_SESSION[$wizard_name], 'combine', 'on');
            $combine = grab_array_var($inargs, 'combine', $combine);

            $serviceargs = grab_array_var($_SESSION[$wizard_name], 'serviceargs', array());
             
            $output = '
            <h5 class="ul">' . _("Service Information") .' </h5>
            <table class="table table-no-border table-auto-width table-padded">
                <tbody>
                    <tr>
                        <td class="vt">
                            <label for="service_description">' . _("Service Description (Prefix):") . '</label>
                        </td>
                        <td>
                            <input type="text" size="40" name="service_description" id="service_description" value="' . encode_form_val($service_description) . '" class="form-control">
                            <div class="subtext">' . _("The prefix associated with each service produced .") . '</div>
                        </td>
                    </tr>
                </tbody>
            </table>
            <table class="table table-no-border table-auto-width table-padded">
                <tbody>
                    <tr>
                        <td class="vt">
                            <input type="checkbox" class="checkbox" id="combine" name="combine"' . is_checked($combine, 'on') . '>
                        </td>
                        <td>
                            <label for="combine" class="select-cf-option">'. _('Combine checks into one service') . '</label>
                            <br/>' . _("Combines all of the checks below into one service/check.") . '
                        </td>
                    </tr>
                </tbody>
            </table>
            ';

            $jvm = array('enabled' => 'on', 'warning' => '90', 'critical' => '95');
            if (array_key_exists('jvm',$serviceargs)) {
                $jvm = $serviceargs['jvm'];
            }
            $jta = array('enabled' => 'on', 'warning' => '20', 'critical' => '40');
            if (array_key_exists('jta', $serviceargs)) {
                $jta = $serviceargs['jta'];
            }
            $jms_runtime = array('enabled' => 'on', 'warning' => '500', 'critical' => '1000');
            if (array_key_exists('jms_runtime', $serviceargs)) {
                $jms_runtime = $serviceargs['jms_runtime'];
            }
            $thread_pool = array('enabled' => 'on', 'warning' => '5', 'critical' => '10');
            if (array_key_exists('thread_pool', $serviceargs)) {
                $thread_pool = $serviceargs['thread_pool'];
            }

            $output .= '
            <h5 class="ul">' . _("Metrics") . '</h5>
            <table class="table table-no-border table-auto-width table-padded">
                <tbody>
                    <tr class="vt">
                        <td class="vt">
                            <input type="checkbox" class="checkbox" id="jvm-enable" name="serviceargs[jvm][enabled]"' . is_checked($jvm['enabled'], 'on') . '>
                        </td>
                        <td>
                            <label for="jvm-enable" class="select-cf-option">'. _('Heap Memory Usage') . '</label>
                            <div class="pad-t5">
                                <label><img src="/nagiosxi/images/error.png" class="tt-bind" title="Warning Threshold"></label>
                                <input type="text" size="7" name="serviceargs[jvm][warning]" value="' . encode_form_val($jvm['warning']) . '" class="textfield form-control condensed"> %
                                &nbsp;
                                <label><img src="/nagiosxi/images/critical_small.png" class="tt-bind" title="Critical Threshold"></label>
                                <input type="text" size="7" name="serviceargs[jvm][critical]" value="' . encode_form_val($jvm['critical']) . '" class="textfield form-control condensed"> %
                            </div>
                        </td>
                    </tr>
                    <tr class="vt">
                        <td class="vt">
                            <input type="checkbox" class="checkbox" id="jta-enable" name="serviceargs[jta][enabled]"' . is_checked($jta['enabled'], 'on') . '>
                        </td>
                        <td>
                            <label for="jta-enable" class="select-cf-option">'. _('JTA Active Connections') . '</label>
                            <div class="pad-t5">
                                <label><img src="/nagiosxi/images/error.png" class="tt-bind" title="Warning Threshold"></label>
                                <input type="text" size="7" name="serviceargs[jta][warning]" value="' . encode_form_val($jta['warning']) . '" class="textfield form-control condensed">
                                &nbsp;
                                <label><img src="/nagiosxi/images/critical_small.png" class="tt-bind" title="Critical Threshold"></label>
                                <input type="text" size="7" name="serviceargs[jta][critical]" value="' . encode_form_val($jta['critical']) . '" class="textfield form-control condensed">
                            </div>
                        </td>
                    </tr>
                    <tr class="vt">
                        <td class="vt">
                            <input type="checkbox" class="checkbox" id="jms-enable" name="serviceargs[jms_runtime][enabled]"' . is_checked($jms_runtime['enabled'], 'on') . '>
                        </td>
                        <td>
                            <label for="jms-enable" class="select-cf-option">'. _('JMS Runtime Connections') . '</label>
                            <div class="pad-t5">
                                <label><img src="/nagiosxi/images/error.png" class="tt-bind" title="Warning Threshold"></label>
                                <input type="text" size="7" name="serviceargs[jms_runtime][warning]" value="' . encode_form_val($jms_runtime['warning']) . '" class="textfield form-control condensed">
                                &nbsp;
                                <label><img src="/nagiosxi/images/critical_small.png" class="tt-bind" title="Critical Threshold"></label>
                                <input type="text" size="7" name="serviceargs[jms_runtime][critical]" value="' . encode_form_val($jms_runtime['critical']) . '" class="textfield form-control condensed">
                            </div>
                        </td>
                    </tr>
                    <tr class="vt">
                        <td class="vt">
                            <input type="checkbox" class="checkbox" id="thread-pool-enable" name="serviceargs[thread_pool][enabled]"' . is_checked($thread_pool['enabled'], 'on') . '>
                        </td>
                        <td>
                            <label for="thread-pool-enable" class="select-cf-option">'. _('Stuck Threads') . '</label>
                            <div class="pad-t5">
                                <label><img src="/nagiosxi/images/error.png" class="tt-bind" title="Warning Threshold"></label>
                                <input type="text" size="7" name="serviceargs[thread_pool][warning]" value="' . encode_form_val($thread_pool['warning']) . '" class="textfield form-control condensed">
                                &nbsp;
                                <label><img src="/nagiosxi/images/critical_small.png" class="tt-bind" title="Critical Threshold"></label>
                                <input type="text" size="7" name="serviceargs[thread_pool][critical]" value="' . encode_form_val($thread_pool['critical']) . '" class="textfield form-control condensed">
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>';

            $jdbc = 0;
            if (array_key_exists("jdbc", $serviceargs)) {
                $jdbc = $serviceargs['jdbc'];
            }

            $output .= '

            <h5 class="ul">' . _("JDBC Waiting Connections") . '</h5>
            <p>'. _("Each name is the datasource's JNDI name. Enter the wildcard (*) to apply the same warning/critical thresholds to all datasources.") . '
            <table class="table table-no-border table-auto-width table-padded adddeleterow">
                <thead>
                    <tr>
                    <th>
                        ' . _('Datasource Name') . '
                    </th>
                    <th>
                        ' . _('Warning Threshold') .'
                    </th>
                    <th>
                        ' . _('Critical Threshold') .'
                    </th>
                    </tr>
                </thead>
                <tbody>

                ';
                if(is_array($jdbc['on'])) {
                    foreach($jdbc["on"] as $index => $not_used) {
                        $output .='
                    <tr>
                        <td>
                            <input type="text" size="30" name="serviceargs[jdbc][' . $index . '][on]" value="' . $jdbc['on'][$index] . '" class="textfield form-control">
                        </td>
                        <td>
                            <input type="text" size="10" name="serviceargs[jdbc][' . $index . '][warning]" value="' . $jdbc['warning'][$index] . '" class="textfield form-control">
                        </td>
                        <td>
                            <input type="text" size="10" name="serviceargs[jdbc][' . $index . '][critical]" value="' . $jdbc['critical'][$index] . '" class="textfield form-control">
                        </td>
                    </tr>
                        ';
                    }
                }
                else {
                    $output .= '
                    <tr>
                        <td>
                            <input type="text" size="35" name="serviceargs[jdbc][0][on]" value="" class="textfield form-control">
                        </td>
                        <td>
                            <input type="text" size="15" name="serviceargs[jdbc][0][warning]" value="" class="textfield form-control">
                        </td>
                        <td>
                            <input type="text" size="15" name="serviceargs[jdbc][0][critical]" value="" class="textfield form-control">
                        </td>
                    </tr>
                    ';
                }
                $output .= '
                </tbody>
            </table>';

            $component = 0;
            if (array_key_exists("component", $serviceargs)) {
                $component = $serviceargs['component'];
            }

            $output .= '

            <h5 class="ul">' . _("Component HTTP Sessions") . '</h5>
            <p>'. _("Each application name is its exact context root. Enter the wildcard (*) to set the same warning/critical thresholds for all applications.") . '
            <table class="table table-no-border table-auto-width table-padded adddeleterow">
                <thead>
                    <tr>
                    <th>
                        ' . _('Application Name') . '
                    </th>
                    <th>
                        ' . _('Warning Threshold') .'
                    </th>
                    <th>
                        ' . _('Critical Threshold') .'
                    </th>
                    </tr>
                </thead>
                <tbody>

                ';
                if(is_array($component['on'])) {
                    foreach($component["on"] as $index => $not_used) {
                        $output .='
                    <tr>
                        <td>
                            <input type="text" size="30" name="serviceargs[component][' . $index . '][on]" value="' . $component['on'][$index] . '" class="textfield form-control">
                        </td>
                        <td>
                            <input type="text" size="10" name="serviceargs[component][' . $index . '][warning]" value="' . $component['warning'][$index] . '" class="textfield form-control">
                        </td>
                        <td>
                            <input type="text" size="10" name="serviceargs[component][' . $index . '][critical]" value="' . $component['critical'][$index] . '" class="textfield form-control">
                        </td>
                    </tr>
                        ';
                    }
                }
                else {
                    $output .= '
                    <tr>
                        <td>
                            <input type="text" size="35" name="serviceargs[component][0][on]" value="" class="textfield form-control">
                        </td>
                        <td>
                            <input type="text" size="15" name="serviceargs[component][0][warning]" value="" class="textfield form-control">
                        </td>
                        <td>
                            <input type="text" size="15" name="serviceargs[component][0][critical]" value="" class="textfield form-control">
                        </td>
                    </tr>
                    ';
                }
                $output .= '
                </tbody>
            </table>';

            $jms_queue = 0;
            if (array_key_exists("jms_queue", $serviceargs)) {
                $jms_queue = $serviceargs['jms_queue'];
            }

            $output .= '

            <h5 class="ul">' . _("JMS Queue Message Count") . '</h5>
            <p>'. _("Each queue name is a JMS resource's WebLogic Name. Enter the wildcard (*) to apply the same warning/critical thresholds to all datasources.") . '
            <table class="table table-no-border table-auto-width table-padded adddeleterow">
                <thead>
                    <tr>
                    <th>
                        ' . _('Queue Name') . '
                    </th>
                    <th>
                        ' . _('Warning Threshold') .'
                    </th>
                    <th>
                        ' . _('Critical Threshold') .'
                    </th>
                    </tr>
                </thead>
                <tbody>

                ';
                if(is_array($jms_queue['on'])) {
                    foreach($jms_queue["on"] as $index => $not_used) {
                        $output .='
                    <tr>
                        <td>
                            <input type="text" size="30" name="serviceargs[jms_queue][' . $index . '][on]" value="' . $jms_queue['on'][$index] . '" class="textfield form-control">
                        </td>
                        <td>
                            <input type="text" size="10" name="serviceargs[jms_queue][' . $index . '][warning]" value="' . $jms_queue['warning'][$index] . '" class="textfield form-control">
                        </td>
                        <td>
                            <input type="text" size="10" name="serviceargs[jms_queue][' . $index . '][critical]" value="' . $jms_queue['critical'][$index] . '" class="textfield form-control">
                        </td>
                    </tr>
                        ';
                    }
                }
                else {
                    $output .= '
                    <tr>
                        <td>
                            <input type="text" size="35" name="serviceargs[jms_queue][0][on]" value="" class="textfield form-control">
                        </td>
                        <td>
                            <input type="text" size="15" name="serviceargs[jms_queue][0][warning]" value="" class="textfield form-control">
                        </td>
                        <td>
                            <input type="text" size="15" name="serviceargs[jms_queue][0][critical]" value="" class="textfield form-control">
                        </td>
                    </tr>
                    ';
                }
                $output .= '
                </tbody>
            </table>';
            break;

        /* Form validation for CONFIGWIZARD_MODE_GETSTAGE2HTML */ 
        case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:
            /* This defines $back variable, used for determining if the Back button */
            /* was clicked when the user was on CONFIGWIZARD_MODE_GETSTAGE4HTML */
            $back = array_key_exists("backButton", $_POST);         
            /* If the user came back from CONFIGWIZARD_MODE_GETSTAGE3HTML then we don't need to revalidate and check for errors */
            if ($back) break;

            $serviceargs = grab_array_var($_SESSION[$wizard_name], 'serviceargs', array());
            $serviceargs = grab_array_var($inargs, 'serviceargs', $serviceargs);

            $service_description = grab_array_var($_SESSION[$wizard_name], 'service_description', '');
            $service_description = grab_array_var($inargs, 'service_description', $service_description);

            $combine = grab_array_var($_SESSION[$wizard_name], 'combine', 'off');
            $combine = grab_array_var($inargs, 'combine', $combine);

            $simple_types = array(
                "jvm",
                "jta",
                "jms_runtime",
                "thread_pool",
            );

            $complex_types = array(
                "jdbc",
                "component",
                "jms_queue",
            );

            foreach($serviceargs as $type => $values) {
                if (!in_array($type, $simple_types)) {
                    if (!in_array($type, $complex_types)) {
                        $errmsg[$errors++] = _("Check type ") . encode_form_val($type) . _(" is invalid.");
                    }
                    else {
                        foreach($serviceargs[$type] as $index => $subvalues) {
                            $serviceargs[$type][$index]['on'] = str_replace("'", " ", $serviceargs[$type][$index]['on']);
                            // Thresholds aren't handled by the plugin, so we can convert to integer.
                            $serviceargs[$type][$index]['warning'] = intval($subvalues['warning']);
                            $serviceargs[$type][$index]['critical'] = intval($subvalues['critical']);
                        }
                    }
                }
                else {
                    $serviceargs[$type]['warning'] = intval($values['warning']);
                    $serviceargs[$type]['critical'] = intval($values['critical']);
                }
            }


            if (!have_value($combine)) {
                $combine = "off";
            }

            if (!have_value($service_description)) {
                $errmsg[$errors++] = _("No service description specified.");
            } 

            $_SESSION[$wizard_name]['service_description'] = $service_description;

            if (empty($serviceargs)) {
                $errmsg[$errors++] = _("serviceargs is empty. This error should never be reached. Please contact the config wizard maintainer.");
            }

            if ($errors>0){
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
                if (!array_key_exists('serviceargs', $_SESSION[$wizard_name])) {
                    // If we've never assigned serviceargs to SESSION, it's fine to overwrite even if they're not valid. Same for combine.
                    $_SESSION[$wizard_name]['serviceargs'] = $serviceargs;
                    $_SESSION[$wizard_name]['combine'] = $combine;
                }
            }
            else {
                $_SESSION[$wizard_name]['serviceargs'] = $serviceargs;
                $_SESSION[$wizard_name]['combine'] = $combine;
            }

            /* The next line ends CONFIGWIZARD_MODE_VALIDATESTAGE2DATA */
            break;

        
        case CONFIGWIZARD_MODE_GETSTAGE3HTML:
            $back = array_key_exists('backButton', $_POST);


            $output = '
            ';
            /* The next line ends CONFIGWIZARD_MODE_GETSTAGE3HTML */
            break;
            
            
        case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:

            $back = array_key_exists("backButton", $_POST);
            if($back) {
                break;
            }

            if($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }

            break;
    
        case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:
            $output = '';
            break;
        
        
        case CONFIGWIZARD_MODE_GETOBJECTS:
            $remote = $_SESSION[$wizard_name]['remote'];
            $IP = $_SESSION[$wizard_name]['IP'];
            $hostname = $_SESSION[$wizard_name]['hostname'];
            $username = $_SESSION[$wizard_name]['username'];
            $password = $_SESSION[$wizard_name]['password'];
            $service_description = $_SESSION[$wizard_name]['service_description'];
            $combine = $_SESSION[$wizard_name]['combine'];
            $WLSAgent_port = $_SESSION[$wizard_name]['WLSAgent_port'];
            $JMX_T3_port = $_SESSION[$wizard_name]['JMX_T3_port'];
            $port = $_SESSION[$wizard_name]['port'];
            $token = $_SESSION[$wizard_name]['token'];

            $serviceargs = $_SESSION[$wizard_name]['serviceargs'];

            $objs = array();
            if (!host_exists($hostname)) {

                $objs[] = array(
                    "type" => OBJECTTYPE_HOST,
                    "use" => "xiwizard_java_as_host",
                    "host_name" => $hostname,
                    'icon_image' => 'java_weblogic.png',
                    "address" => $IP,
                    "_xiwizard" => $wizard_name,
                );
            }

            $simple_types = array(
                "jvm",
                "jta",
                "jms_runtime",
                "thread_pool",
            );

            $complex_types = array(
                "jdbc",
                "component",
                "jms_queue",
            );

            $type_argname_map = array(
                "jvm" => "jvm=UsedMemory",
                "jta" => "jta=ActiveTransactions",
                "jms_runtime" => "jms-runtime=CurrentConnections",
                "thread_pool" => "thread-pool=ThreadStuckCount",
                "jdbc" => "jdbc=",
                "component" => "component=",
                "jms_queue" => "jms-queue=",
            );

            $args_array = array(); // Associative if combine is off, else indexed.

            $standard_options = array(
                "username=" . urlencode($username),
                "password=" . urlencode($password),
                "hostname=localhost",
                "port=" . $JMX_T3_port, // already an integer

            );

            if($combine === "on") {
                $args_array = $standard_options;
            }

            foreach ($serviceargs as $type => $value) {
                if (in_array($type, $simple_types) && $value['enabled'] === "on") {
                    if ($combine === "on") {
                        $args_array[] = implode(",", array($type_argname_map[$type], $value['warning'], $value['critical']));
                    }
                    else {
                        $args_array[$type] = $standard_options;
                        $args_array[$type][] = implode(",", array($type_argname_map[$type], $value['warning'], $value['critical']));
                    }
                }
                else if (in_array($type, $complex_types)) {
                    foreach($serviceargs[$type] as $subvalues) {
                        if ($combine === "on") {
                            $args_array[] = implode(",", array($type_argname_map[$type] . $subvalues['on'], $subvalues['warning'], $subvalues['critical']));
                        }
                        else {
                            $args_array[$type] = $standard_options;
                            $args_array[$type][] = implode(",", array($type_argname_map[$type] . $subvalues['on'], $subvalues['warning'], $subvalues['critical']));
                        }   
                    }
                }
            }

            if ($combine === "on") {
                $args = implode("&", $args_array);
                $args = str_replace("'", "", $args);
                if ($remote === "wget") {
                    $args = "$IP $WLSAgent_port '$args'";
                    $full_check_command = "check_xi_java_weblogic!" . $args . "!";
                }
                else {
                    $full_check_command = "check_xi_ncpa!-t " . $token . ' -P ' . $port . ' -M plugins/check_wlsagent.sh -q \'';
                    $full_check_command .= "args=$IP,args=$WLSAgent_port,args=\"$args\"'";
                }

                $objs[] = array(
                    'type'                  => OBJECTTYPE_SERVICE,
                    'host_name'             => $hostname,
                    'service_description'   => $service_description,
                    'icon_image'            => 'java_weblogic.png',
                    'check_command'         => $full_check_command,
                    '_xiwizard'             => $wizard_name,
                );
            }
            else {
                foreach ($args_array as $type => $subarray) {
                    $args = implode("&", $subarray);
                    $args = str_replace("'", "", $args);
                    if ($remote === "wget") {
                        $args = "$IP $WLSAgent_port '$args'";
                        $full_check_command = "check_xi_java_weblogic!" . $args . "!";
                    }
                    else {
                        $full_check_command = "check_xi_ncpa!-t " . $token . ' -P ' . $port . ' -M plugins/check_wlsagent.sh -q "';
                        $full_check_command .= "args=$IP,args=$WLSAgent_port,args='$args'\"";
                    }

                    $objs[] = array(
                        'type'                  => OBJECTTYPE_SERVICE,
                        'host_name'             => $hostname,
                        'service_description'   => $service_description . ": " . $type,
                        'icon_image'            => 'java_weblogic.png',
                        'check_command'         => $full_check_command,
                        '_xiwizard'             => $wizard_name,
                    );       
                }
            }

            /* Return the object definitions to the wizard */
            $outargs[CONFIGWIZARD_NAGIOS_OBJECTS] = $objs;
            
            /* clear the session variables for this wizard run */
            unset($_SESSION[$wizard_name]); 
            
            /* The next line ends CONFIGWIZARD_MODE_GETOBJECTS */
            break;

        default:
            break;          
    };        
    return $output;
}


function java_as_ncpa_plugin_check($url, $plugin_name, &$cmd) {
    $url = escapeshellarg($url);
    $cmd = "curl " . $url . " -g -f -k --connect-timeout 10";

    $ret = 0;
    exec($cmd, $data, $ret);
    $data = implode("", $data);

    if ($ret)
        return 1; // cURL-specific error

    $data = json_decode($data, true);

    if (!$data) {
        return 2; // Not JSON data
    }

    if (!array_key_exists('plugins', $data)) {
        return 3; // Not the correct json data
    }

    $missing = 4; // If not changed, plugin not installed.
    foreach($data['plugins'] as $plugin) {
        if ($plugin === $plugin_name) {
            $missing = 0; // Everything is good.
            break;
        }
    }

    return $missing;
}

function java_as_java_not_installed() {
    $cmd = "which java";
    $output = "";
    $ret = 0;
    exec($cmd, $output, $ret);
    return $ret;
}

function java_as_scale_threshold($threshold, $scalar) {
    if (!is_string($threshold))
        return $threshold;

    $flipped = false;
    if ($threshold[0] === '@') {
        $flipped = true;
        $threshold = trim($threshold, '@');
    }
    
    $threshold = explode(":", $threshold);
    foreach ($threshold as $index => $bound) {
        $threshold[$index] = floatval($scalar) * floatval($bound);
        if ($threshold[$index] == 0) {
            $threshold[$index] = "";
        }
    }
    $threshold = implode(":", $threshold);
    
    if ($flipped)
        $threshold = '@' . $threshold;
    return $threshold;
}

function java_as_rp_filter($in) {
    if (!is_array($in))
        return $in;
    return have_value($in['on']) && have_value($in['type']) && have_value($in['warning']) && have_value($in['critical']);
}

function java_as_escape_exclamation_dollar($input) {
    $search = array('!', '$');
    $replace = array('\!', '\$');
    return str_replace($search, $replace, $input);
}
?>
