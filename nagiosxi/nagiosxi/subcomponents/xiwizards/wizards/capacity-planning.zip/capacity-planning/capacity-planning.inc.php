<?php
include_once(dirname(__FILE__) . '/../configwizardhelper.inc.php');
include_once(dirname(__FILE__) . '/../../components/capacityplanning/cp-wizard.inc.php');

capacity_planning_configwizard_init();

function capacity_planning_configwizard_init(){
    
    /* Name / ID for config wizard */
    $name = 'capacity-planning';
    
    /* Relevant info for wizard */
    $args = array(
        CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
        CONFIGWIZARD_DESCRIPTION => _('Alert based on metrics produced by the Capacity Planning report.'),
        CONFIGWIZARD_DISPLAYTITLE => _('Capacity Planning'),
        CONFIGWIZARD_FUNCTION => 'capacity_planning_configwizard_func',
        CONFIGWIZARD_PREVIEWIMAGE => 'capacity_planning.png',
        CONFIGWIZARD_VERSION => '1.0.2',
        CONFIGWIZARD_DATE => '05/25/2020',
        CONFIGWIZARD_COPYRIGHT => _("Copyright &copy; 2019-2020 Nagios Enterprises, LLC."),
        CONFIGWIZARD_AUTHOR => _('Nagios Enterprises, LLC.'),
        CONFIGWIZARD_REQUIRES_VERSION => 560,
        );
    /* Register wizard with XI */
    register_configwizard($name,$args);
}
