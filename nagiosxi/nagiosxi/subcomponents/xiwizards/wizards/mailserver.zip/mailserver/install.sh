#!/bin/bash 

if [ `command -v yum` ]; then
	yum install perl-Net-DNS -y
else
	cpan install Net::DNS ||:
fi
exit 0
