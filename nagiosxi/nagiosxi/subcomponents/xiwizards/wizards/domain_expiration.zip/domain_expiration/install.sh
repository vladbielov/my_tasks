#!/bin/bash

if [ `command -v yum` ]; then
    yum install jwhois -y
else
    apt-get install -y whois
fi
exit 0
