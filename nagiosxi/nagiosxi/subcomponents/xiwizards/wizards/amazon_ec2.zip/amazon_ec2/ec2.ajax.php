<?php 
//
// Copyright (c) 2018-2019 Nagios Enterprises, LLC. All rights reserved.
//

include_once(dirname(__FILE__) . '/../configwizardhelper.inc.php');

// Initialization stuff
pre_init();
init_session();

// Grab GET or POST variables and do prereq and auth checks
grab_request_vars();
check_prereqs();
check_authentication();

route_request();

function route_request()
{
    global $request;

    $mode = grab_request_var("mode", "");

    switch ($mode) {

        case'getinstances':
            get_ec2_instances();
            break;

        case'getregions':
            get_regions();

        default:
            echo "The EC2 Utils file was called but no mode was passed.";
            exit;

    }
}

function get_ec2_instances()
{
    global $request;

    $accesskeyid = grab_request_var("accesskeyid", "");
    $accesskey = grab_request_var("accesskey", "");
    $staticcreds = grab_request_var("staticcreds", "");
    $credsfilepath = grab_request_var("credsfilepath", "");

    $accesskeyid = base64_decode($accesskeyid);
    $accesskey = base64_decode($accesskey);

    if ($staticcreds == "on") {
        $cmd = "/usr/local/nagios/libexec/check_ec2.py --getinstances --credfile '" . $credsfilepath . "'";
    } else {
        $cmd = "/usr/local/nagios/libexec/check_ec2.py --getinstances --accesskeyid='" . $accesskeyid . "' --secretaccesskey=" . $accesskey;
    }
    $cmd = escapeshellcmd($cmd);

    $instance_list = shell_exec($cmd);

    $_SESSION['instancelist'] = json_decode($instance_list);

    echo "$instance_list";
}