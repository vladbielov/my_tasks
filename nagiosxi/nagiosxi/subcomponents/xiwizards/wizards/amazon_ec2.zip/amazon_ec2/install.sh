#!/bin/bash

# Load configuration file

BASEDIR=$(dirname $(readlink -f $0))
cfgfile="$BASEDIR/../../../../xi-sys.cfg"
cfgfile_installed="/usr/local/nagiosxi/var/xi-sys.cfg"

if [ -f $cfgfile ]; then
    . $cfgfile
elif [ -f $cfgfile_installed ]; then
    . $cfgfile_installed
fi

# Check if boto3 is installed and try to install it

ret=$(python -c "import boto3")
if [ $? == 1 ]; then
	if [ $dist == "el6" ]; then
		# Install old version that supports python 2.6
		pip install boto3==1.10.50
	else
		pip install boto3
	fi
fi