<?php
//
// HyperV Config Wizard
// Copyright (c) 2019 Nagios Enterprises, LLC. All rights reserved.
//

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');


hyperv_configwizard_init();


function hyperv_configwizard_init()
{
    $name = 'hyperv';

    $args = array(
        CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
        CONFIGWIZARD_DESCRIPTION => _('Monitor your Hyper-V server via NCPA.'),
        CONFIGWIZARD_DISPLAYTITLE => _('Hyper-V'),
        CONFIGWIZARD_FUNCTION => 'hyperv_configwizard_func',
        CONFIGWIZARD_PREVIEWIMAGE => 'hyperv.png',
        CONFIGWIZARD_VERSION => '1.0.2',
        CONFIGWIZARD_DATE => '11/06/2019',
        CONFIGWIZARD_COPYRIGHT => _("Copyright &copy; 2019 Nagios Enterprises, LLC."),
        CONFIGWIZARD_AUTHOR => _('Nagios Enterprises, LLC.'),
        CONFIGWIZARD_REQUIRES_VERSION => 550
    );

    register_configwizard($name, $args);
}


/* This function is automatically called by the XI wizard framework when the wizard is run */
function hyperv_configwizard_func($mode = '', $inargs = null, &$outargs, &$result)
{
    $wizard_name = 'hyperv';

    /* Initialize return code and output */
    $result = 0;
    $output = '';
    
    /* Initialize output args */
    $outargs[CONFIGWIZARD_PASSBACK_DATA] = $inargs;

    switch ($mode) {

        case CONFIGWIZARD_MODE_GETSTAGE1HTML:
            // Allow debugging before proper output starts
            $output = '';

            /* This defines $nextstep variable, used for determining if the user did not */
            /* provide correct information when the user was on CONFIGWIZARD_MODE_GETSTAGE1HTML */
            $nextstep = encode_form_val(grab_array_var($_POST, 'nextstep', false), ENT_QUOTES);

            /* Determine if this is the first wizard run */
            if ($nextstep == '') {
                /* Clear the session array to be sure it is blank */
                unset($_SESSION[$wizard_name]); 
            }
            if (!isset($_POST['ip_address'])) {
                /* Fresh Wizard Run */
                /* Define the session array to hold data from different stages */
                $_SESSION[$wizard_name] = array(); 
                
                // NCPA Stuff
                $address = '';
                $port = '5693';
                $token = '';

            }
            else {
                /* Continuing from CONFIGWIZARD_MODE_VALIDATESTAGE1DATA due to user error */
                $address_session = grab_array_var($_SESSION[$wizard_name],'ip_address','');
                $address = grab_array_var($inargs,'ip_address', $address_session);
                $port_session = grab_array_var($_SESSION[$wizard_name], 'port', '5693');
                $port = grab_array_var($inargs, 'port', $port_session);
                $token_session = grab_array_var($_SESSION[$wizard_name], 'token', '');
                $token = grab_array_var($inargs, 'token', $token_session);

            }

            /* Now we are creating the HTML for CONFIGWIZARD_MODE_GETSTAGE1HTML */ 
            $output .= '
            <h5 class="ul">' . _('Setup NCPA') . '</h5>
            <p><i>' . _('The agent should be installed before running this wizard.') . '</i></p>
            <ul style="padding: 0 0 0 30px;">
                <li><a href="https://www.nagios.org/ncpa#downloads" target="_blank">' . _('Download the latest version of NCPA') . '</a> ' . _('for the system you would like to monitor') . '</li>
                <li>' . _('Follow the') . ' <a href="https://www.nagios.org/ncpa/getting-started.php" target="_blank">' . _('installation instructions') . '</a> (<a href="https://assets.nagios.com/downloads/ncpa/docs/Installing-NCPA.pdf" target="_blank">' . _('PDF version') . '</a>) ' . _('and configure the token for the agent') . '</li>
            </ul>

            <h5 class="ul">' . _('NCPA Connection') . '</h5>
            <table class="table table-condensed table-no-border table-auto-width">
                <tr>
                    <td class="vt">
                        <label for="ip_address">' . _('IP Address/FQDN') . ':</label>
                    </td>
                    <td>
                        <input type="text" size="40" name="ip_address" id="ip_address" value="'.$address.'" class="form-control">
                    </td>
                </tr>
                <tr>
                    <td class="vt">
                        <label for="">' . _("NCPA Port") . ':</label>
                    </td>
                    <td>
                        <input type="text" size="6" name="port" id="port" value="'.$port.'" class="form-control">
                    </td>
                </tr>
                <tr>
                    <td class="vt">
                        <label for="">' . _("NCPA Token") . ':</label>
                    </td>
                    <td>
                        <input type="text" size="30" name="token" id="token" value="'.$token.'" class="form-control" autocomplete="off">
                    </td>
                </tr>
            </table>

            ';
            /* The quote and semicolon ends HTML for CONFIGWIZARD_MODE_GETSTAGE1HTML */ 
            /* $output will be passed back to XI framework and rendered to browser */
            /* The next line ends CONFIGWIZARD_MODE_GETSTAGE1HTML */
            break;

            
        /* Form validation for CONFIGWIZARD_MODE_GETSTAGE1HTML */
        case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:      
            /* This defines $back variable, used for determining if the Back button */
            /* was clicked when the user was on CONFIGWIZARD_MODE_GETSTAGE2HTML */
            $back = array_key_exists("backButton", $_POST);         
            
            /* If the user came back from CONFIGWIZARD_MODE_GETSTAGE3HTML then we don't need to revalidate and check for errors */
            if ($back) {
                break;
            }
            
            /* Get variables that were passed to us */
            $address_session = grab_array_var($_SESSION[$wizard_name], 'ip_address', '');
            $address = grab_array_var($inargs,'ip_address',$address_session);
            $port_session = grab_array_var($_SESSION[$wizard_name], 'port', '');
            $port = grab_array_var($inargs, 'port', $port_session);
            $port = intval($port);
            $token_session = grab_array_var($_SESSION[$wizard_name], 'token', '');
            $token = grab_array_var($inargs, 'token', $token_session);

            /* Start actual validation */
            $errors = 0;
            $errmsg = array();

            if ($address === "debugging" && $token === "debugging") {
                $_SESSION[$wizard_name]['ip_address'] = $address;
                $_SESSION[$wizard_name]['port'] = $port;
                $_SESSION[$wizard_name]['token'] = $token;
                break;
            }

            if (have_value($address) == false) {
                /* address field was blank, add an error message to the array and increment the $errors count */
                $errmsg[$errors++] = _('No address specified.');
            }

            $ncpa_full_url = "https://" . $address . ":" . $port . "/api/windowscounters/Hyper-V%20Hypervisor%20Logical%20Processor(_Total)/%25%20Total%20Run%20Time?sleep=1&token=" . $token;
            $cmd = '';
            $result = hyperv_ncpa_installed_check($ncpa_full_url, $cmd); // defined at end of file

            if ($result > 0) {
                if ($result == 1) {
                    $errmsg[$errors++] = _("cURL call to verify NCPA installation failed.");
                } 
                else if($result == 2) {
                    $errmsg[$errors++] = _("cURL call to NCPA port did not return JSON data.");
                }
                else if($result == 3) {
                    $errmsg[$errors++] = _("cURL call to NCPA port returned invalid JSON.");
                }
                else if($result == 4) {
                    $errmsg[$errors++] = _("Hyper-V performance counters not installed on remote machine.");
                }
                else {
                    $errmsg[$errors++] = sprintf(_("cURL-related error: %s"), "$result");
                }
            }
           
            /* Check to see if the $errors array contains errors */
            if ($errors>0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }
            else {
                $_SESSION[$wizard_name]['ip_address'] = $address;
                $_SESSION[$wizard_name]['port'] = $port;
                $_SESSION[$wizard_name]['token'] = $token;
            }
            
            /* The next line ends CONFIGWIZARD_MODE_VALIDATESTAGE1DATA */
            break;


            
        case CONFIGWIZARD_MODE_GETSTAGE2HTML:

            /* This defines $back variable, used for determining if the Back button */
            /* was clicked when the user was on CONFIGWIZARD_MODE_GETSTAGE3HTML */
            $back = encode_form_val(grab_array_var($_POST,'backButton',false),ENT_QUOTES);
            
            if (isset($_POST['ip_address'])) {
                /* Continuing from CONFIGWIZARD_MODE_GETSTAGE1HTML */
                
                /* Grab array variables from CONFIGWIZARD_MODE_GETSTAGE1HTML */
                $address = $_SESSION[$wizard_name]['ip_address'];

                /* The following function queries DNS using $addess to see if it can determine a FQDN for the object */
                $hostname = gethostbyaddr($address);
            }
            else {
                /* Continuing from CONFIGWIZARD_MODE_VALIDATESTAGE2DATA due to user error */

                $hostname_session = grab_array_var($_SESSION[$wizard_name], 'hostname', '');
                $hostname = grab_array_var($inargs, 'hostname', $hostname_session);

                $address = grab_array_var($_SESSION[$wizard_name], 'ip_address', '');
            }
            // Pull Old variables from $_SESSION. These should not change for the rest of the wizard, so logic is performed outside of any conditionals.
            $port = grab_array_var($_SESSION[$wizard_name], 'port', '');
            $token = grab_array_var($_SESSION[$wizard_name], 'token', '');

            // New variable. This should also just kinda work.
            $serviceargs = grab_array_var($_SESSION[$wizard_name], 'serviceargs', array());

            /* Now we are creating the HTML for CONFIGWIZARD_MODE_GETSTAGE2HTML */ 
            $output = '
            <script src="../includes/configwizards/hyperv/hyperv.inc.js"></script>
            <div class="hide" id="instance-ok">
                <img src="' . theme_image('ok_small.png') . '"></img> ' . _("Instance verified! Current value is ") . '
            </div>
            <div class="hide" id="instance-pending">
                <img src="' . theme_image('pending_small.png') . '"></img> ' . _("Verifying instance...") . '
            </div>
            <div class="hide" id="instance-critical">
                <img src="' . theme_image('critical_small.png') . '"></img> ' . _("Invalid endpoint. Either the instance name is incorrect or this Windows performance endpoint isn't installed.") . '
            </div>
            <div class="hide" id="token">'.$token.'</div>
            <div class="hide" id="port">'.$port.'</div>
            <div class="hide" id="sample-row">

            </div>

            <h5 class="ul">' . _('Remote Host Details') . '</h5>
            <table class="table table-condensed table-no-border table-auto-width table-padded">
                <tr>
                    <td>
                        <label for="ip_address">' . _('IP Address') . ':</label>
                    </td>
                    <td>
                        <input type="text" size="40" name="ip_address" id="ip_address" value="' . encode_form_val($address) . '" class="textfield form-control" readonly>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="hostname">' . _('Host Name') . ':</label>
                    </td>
                    <td>
                        <input type="text" size="40" name="hostname" id="hostname" value="'. encode_form_val($hostname) .'" class="textfield form-control">
                    </td>
                </tr>
            </table>';

            $cpu_endpoints = array(
                array(
                    'object' => "Hyper-V Hypervisor Logical Processor",
                    'instance' => "_Total",
                    'counter' => '% Total Run Time',
                    'warning' => '85',
                    'critical' => '90',
                    'description' => _("The total physical CPU usage for the host server"),
                    'on' => true,
                    'sleepy' => true,
                    'factor' => '0'),
                array(
                    'object' => "Hyper-V Hypervisor Root Virtual Processor",
                    'instance' => "_Total",
                    'counter' => "% Guest Run Time",
                    'warning' => '',
                    'critical' => '',
                    'description' => _("The total CPU usage spent on guest VMs"),
                    'sleepy' => true,
                    'factor' => '0'),
                array(
                    'object' => "Hyper-V Hypervisor Logical Processor",
                    'instance' => "_Total",
                    'counter' => "Context Switches/sec",
                    'warning' => '',
                    'critical' => '',
                    'description' => _("A general health indicator for the server. Should usually be <200,000 per processor."),
                    'sleepy' => true,
                    'factor' => '0'),
                array(
                    'object' => "Hyper-V Hypervisor Virtual Processor",
                    'instance' => "*", 
                    'counter' => "% Guest Run Time",
                    'warning' => '',
                    'critical' => '',
                    'description' => _("CPU usage for each virtual processor on each VM."),
                    'sleepy' => true,
                    'factor' => '0')
            );

            $form_element_counter = 0;
            $section = 'cpu';

            $output .= '
            <h5 class="ul">' . _("CPU Counters") . '</h5>
            <table class="table table-condensed table-no-border table-auto-width table-padded section-' . $section . '">';

            if (isset($serviceargs[$section]) && !empty($serviceargs[$section])) {
                $cpu_endpoints = $serviceargs[$section];
            }

            foreach ($cpu_endpoints as $endpoint) {
                
                $element_id = strval($form_element_counter++);

                $output .= hyperv_build_form_element($element_id, $endpoint, $section);
            }

            $output .= '
            </table>';

            $memory_endpoints = array(
                array(
                    'object' => "Hyper-V Dynamic Memory Balancer", 
                    'instance' => '*', 
                    'counter' => 'Available Memory', 
                    'warning' => '4000:', 
                    'critical' => '2000:',
                    'description' => _("The amount of memory available for VMs (in MB)."), 
                    'on' => true,
                    'factor' => '0'),
                array(
                    'object' => "Hyper-V Dynamic Memory VM", 
                    'instance' => '*', 
                    'counter' => 'Average Pressure', 
                    'warning' => '75', 
                    'critical' => '85',
                    'description' => _("The proportion of memory committed versus allocated for each VM"),
                    'factor' => '0'),
                array(
                    'object' => "Hyper-V Dynamic Memory VM", 
                    'instance' => '*', 
                    'counter' => 'Physical Memory', 
                    'warning' => '', 
                    'critical' => '', 
                    'description' => _("The amount of allocated memory for each machine (in MB)."),
                    'factor' => '0')/*,
                array(
                    'object' => "Hyper-V VM Vid Partition",
                    'instance' => '', 
                    'counter' => 'Remote Physical Pages', 
                    'warning' => '', 
                    'critical' => '', 
                    'description' => _("This is really hard to monitor with the way things are set up currently. We want to make sure the counter increases by less than 100/hr."))*/
            );

            $form_element_counter = 0;
            $section = 'memory';

            $output .= '
            <h5 class="ul">' . _("Memory Counters") . '</h5>
            <table class="table table-condensed table-no-border table-auto-width table-padded section-' . $section . '">';

            if (isset($serviceargs[$section]) && !empty($serviceargs[$section])) {
                $memory_endpoints = $serviceargs[$section];
            }

            foreach ($memory_endpoints as $endpoint) {
                
                $element_id = strval($form_element_counter++);

                $output .= hyperv_build_form_element($element_id, $endpoint, $section);
            }

            $output .= '
            </table>';
            $networking_endpoints = array(
                array(
                    'object' => "Network Interface", 
                    'instance' => '*', 
                    'counter' => 'Bytes Total/sec', 
                    'warning' => '', 
                    'critical' => '',
                    'description' => _("Shows the network usage for each physical NIC"), 
                    'on' => true,
                    'sleepy' => true,
                    'factor' => '0'),
                array(
                    'object' => "Hyper-V Virtual Network Adapter", 
                    'instance' => '*', 
                    'counter' => 'Bytes/sec', 
                    'warning' => '', 
                    'critical' => '',
                    'description' => _("Shows the network usage for each VM network adapter"),
                    'sleepy' => true,
                    'factor' => '0'),
            );

            $form_element_counter = 0;
            $section = 'networking';

            $output .= '
            <h5 class="ul">' . _("Networking Counters") . '</h5>
            <table class="table table-condensed table-no-border table-auto-width table-padded section-' . $section . '">';

            if (isset($serviceargs[$section]) && !empty($serviceargs[$section])) {
                $networking_endpoints = $serviceargs[$section];
            }

            foreach ($networking_endpoints as $endpoint) {
                
                $element_id = strval($form_element_counter++);

                $output .= hyperv_build_form_element($element_id, $endpoint, $section);
            }

            $output .= '
            </table>';

            // TODO: 
            $local_storage_endpoints = array(
                array(
                    'object' => "LogicalDisk", 
                    'instance' => '*', 
                    'counter' => 'Avg. Disk sec/Transfer', 
                    'warning' => '20', 
                    'critical' => '25',
                    'description' => _("Measures disk latency for the virtual machine data. Multiplying by 10^3 gives latency in milliseconds"),
                    'on' => true,
                    'sleepy' => true,
                    'factor' => '3'),
                array(
                    'object' => "LogicalDisk",
                    'instance' => '*',
                    'counter' => '% Idle Time',
                    'warning' => '60:',
                    'critical' => '50:',
                    'description' => _("Shows the amount of time where the disk is in an idle state. This is a general indicator of VM responsiveness, and performance will be dramatically reduced after the thresholds shown here."),
                    'sleepy' => true,
                    'factor' => '0'),
                array(
                    'object' => "LogicalDisk",
                    'instance' => '*',
                    'counter' => 'Free Megabytes',
                    'warning' => '',
                    'critical' => '',
                    'description' => _("The amount of free space on a disk. Low disk space can result in VM outages."),
                    'factor' => '0'),
                array(
                    'object' => "LogicalDisk",
                    'instance' => '*',
                    'counter' => 'Disk Bytes/sec',
                    'warning' => '',
                    'critical' => '',
                    'description' => _("Shows disk throughput for the host instance"),
                    'sleepy' => true,
                    'factor' => '0'),
                array(
                    'object' => "LogicalDisk",
                    'instance' => '*',
                    'counter' => 'Disk Transfers/sec',
                    'warning' => '',
                    'critical' => '',
                    'description' => _("The IOPS counter for local disks. Typically used for capacity planning rather than threshold checking."),
                    'sleepy' => true,
                    'factor' => '0')
            );

            $form_element_counter = 0;
            $section = 'local-storage';

            $output .= '
            <h5 class="ul">' . _("Local Storage Counters") . '</h5>
            <table class="table table-condensed table-no-border table-auto-width table-padded section-' . $section . '">';

            if (isset($serviceargs[$section]) && !empty($serviceargs[$section])) {
                $local_storage_endpoints = $serviceargs[$section];
            }

            foreach ($local_storage_endpoints as $endpoint) {
                
                $element_id = strval($form_element_counter++);

                $output .= hyperv_build_form_element($element_id, $endpoint, $section);
            }

            $output .= '
            </table>';

            $virtual_storage_endpoints = array(
                array(
                    'object' => "Hyper-V Virtual Storage Device",
                    'instance' => '*',
                    'counter' => 'Read Bytes/sec',
                    'warning' => '',
                    'critical' => '',
                    'description' => _("Shows virtual disk output for a particular VM"),
                    'sleepy' => true,
                    'factor' => '0'),
                array(
                    'object' => "Hyper-V Virtual Storage Device",
                    'instance' => '*',
                    'counter' => 'Write Bytes/sec',
                    'warning' => '',
                    'critical' => '',
                    'description' => _("Shows virtual disk input for a particular VM"),
                    'sleepy' => true,
                    'factor' => '0'),
                array(
                    'object' => "Hyper-V Virtual Storage Device",
                    'instance' => '*',
                    'counter' => 'Read Operations/sec',
                    'warning' => '',
                    'critical' => '',
                    'description' => _("The IOPS output counter for a particular VM"),
                    'sleepy' => true,
                    'factor' => '0'),
                array(
                    'object' => "Hyper-V Virtual Storage Device",
                    'instance' => '*',
                    'counter' => 'Write Operations/sec',
                    'warning' => '',
                    'critical' => '',
                    'description' => _("The IOPS input counter for a particular VM"),
                    'sleepy' => true,
                    'factor' => '0')
            );

            $form_element_counter = 0;
            $section = 'virtual-storage';

            $output .= '
            <h5 class="ul">' . _("Virtual Storage Counters") . '</h5>
            <table class="table table-condensed table-no-border table-auto-width table-padded section-' . $section . '">';

            if (isset($serviceargs[$section]) && !empty($serviceargs[$section])) {
                $virtual_storage_endpoints = $serviceargs[$section];
            }

            foreach ($virtual_storage_endpoints as $endpoint) {
                
                $element_id = strval($form_element_counter++);

                $output .= hyperv_build_form_element($element_id, $endpoint, $section);
            }

            $output .= '
            </table>';

            $ha_storage_endpoints = array(
                array(
                    'object' => "Cluster CSV File System",
                    'instance' => '*',
                    'counter' => 'Read Latency',
                    'warning' => '',
                    'critical' => '',
                    'description' => _("Disk Latency for reading from CSV Disks"),
                    'sleepy' => true,
                    'factor' => '0'),
                array(
                    'object' => "Cluster CSV File System",
                    'instance' => '*',
                    'counter' => 'Write Latency',
                    'warning' => '',
                    'critical' => '',
                    'description' => _("Disk Latency for writing to CSV Disks"),
                    'sleepy' => true,
                    'factor' => '0'),
                array(
                    'object' => "Cluster CSV File System",
                    'instance' => '*',
                    'counter' => 'IO Read Bytes/sec',
                    'warning' => '',
                    'critical' => '',
                    'description' => _("Disk Throughput for reading from CSV Disks"),
                    'sleepy' => true,
                    'factor' => '0'),
                array(
                    'object' => "Cluster CSV File System",
                    'instance' => '*',
                    'counter' => 'IO Write Bytes/sec',
                    'warning' => '',
                    'critical' => '',
                    'description' => _("Disk Throughput for writing to CSV Disks"),
                    'sleepy' => true,
                    'factor' => '0'),
                array(
                    'object' => "Cluster CSV File System",
                    'instance' => '*',
                    'counter' => 'IO Reads/sec',
                    'warning' => '',
                    'critical' => '',
                    'description' => _("The IOPS counter for reading from CSV Disks"),
                    'sleepy' => true,
                    'factor' => '0'),
                array(
                    'object' => "Cluster CSV File System",
                    'instance' => '*',
                    'counter' => 'IO Writes/sec',
                    'warning' => '',
                    'critical' => '',
                    'description' => _("The IOPS counter for writing to CSV Disks"),
                    'sleepy' => true,
                    'factor' => '0'),
                array(
                    'object' => "SMB Client Shares",
                    'instance' => '*',
                    'counter' => 'Avg. sec/Data Request',
                    'warning' => '',
                    'critical' => '',
                    'description' => _("Disk Latency for SMB shares. Multiplying by 10^3 gives latency in milliseconds."),
                    'sleepy' => true,
                    'factor' => '3'),
                array(
                    'object' => "SMB Client Shares",
                    'instance' => '*',
                    'counter' => 'Data Bytes/sec',
                    'warning' => '',
                    'critical' => '',
                    'description' => _("Disk throughput for SMB Shares"),
                    'sleepy' => true,
                    'factor' => '0'),
                array(
                    'object' => "SMB Client Shares",
                    'instance' => '*',
                    'counter' => 'Data Requests/sec',
                    'warning' => '',
                    'critical' => '',
                    'description' => _("The IOPS counter for SMB Shares"),
                    'sleepy' => true,
                    'factor' => '0')
            );

            $form_element_counter = 0;
            $section = 'ha-storage';

            $output .= '
            <h5 class="ul">' . _("High-Availability Storage Counters") . '</h5>
            <table class="table table-condensed table-no-border table-auto-width table-padded section-' . $section . '">';

            if (isset($serviceargs[$section]) && !empty($serviceargs[$section])) {
                $ha_storage_endpoints = $serviceargs[$section];
            }

            foreach ($ha_storage_endpoints as $endpoint) {
                
                $element_id = strval($form_element_counter++);

                $output .= hyperv_build_form_element($element_id, $endpoint, $section);
            }

            $output .= '
            </table>';

            break;

        /* Form validation for CONFIGWIZARD_MODE_GETSTAGE2HTML */ 
        case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:
            $back = array_key_exists("backButton", $_POST);         
            if ($back) break;

            $hostname_session = grab_array_var($_SESSION, 'hostname', '');
            $hostname = grab_array_var($inargs, 'hostname', $hostname_session);

            $serviceargs = grab_array_var($_SESSION[$wizard_name], 'serviceargs', array());
            $serviceargs = grab_array_var($inargs, 'serviceargs', $serviceargs);

            if(!have_value($hostname)) {
                $errmsg[$errors++] = _("No host name specified.");
            }
            else if(!is_valid_host_name($hostname)) {
                $errmsg[$errors++] = _("Invalid host name.");
            }
            
            $_SESSION[$wizard_name]['hostname'] = $hostname;

            if (empty($serviceargs)) {
                $errmsg[$errors++] = _("serviceargs is empty. This error should never be reached. Please contact the config wizard maintainer.");
            }

            foreach ($serviceargs as $section) {

                foreach ($section as $check) {

                    $endpoint = $check['object'] . (isset($check['object']) ? "({$check['instance']})" : '') . "\\{$check['counter']}";
                    if (isset($check['on']) && isset($check['invalid'])) {
                        $errmsg[$errors++] = sprintf(_("Windows Performance Counter %s could not be found."), $endpoint);
                    }
                }
            }

            if ($errors > 0){
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
                if (!array_key_exists('serviceargs', $_SESSION[$wizard_name])) {
                    // If we've never assigned serviceargs to SESSION, it's fine to overwrite even if they're not valid.
                    $_SESSION[$wizard_name]['serviceargs'] = $serviceargs;
                }
            }
            else {
                $_SESSION[$wizard_name]['serviceargs'] = $serviceargs;
            }

            /* The next line ends CONFIGWIZARD_MODE_VALIDATESTAGE2DATA */
            break;

        
        case CONFIGWIZARD_MODE_GETSTAGE3HTML:
            $back = array_key_exists('backButton', $_POST);


            $output = '
            ';
            /* The next line ends CONFIGWIZARD_MODE_GETSTAGE3HTML */
            break;
            
            
        case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:

            $back = array_key_exists("backButton", $_POST);
            if($back) {
                break;
            }

            if($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }

            break;
    
        case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:
            $output = '';
            break;
        
        
        case CONFIGWIZARD_MODE_GETOBJECTS:
            $address = $_SESSION[$wizard_name]['ip_address'];
            $hostname = $_SESSION[$wizard_name]['hostname'];

            $token = escapeshellarg($_SESSION[$wizard_name]['token']);
            $port = $_SESSION[$wizard_name]['port'];

            $serviceargs = $_SESSION[$wizard_name]['serviceargs'];

            $objs = array();

            if (!host_exists($hostname)) {
                $objs[] = array(
                    "type" => OBJECTTYPE_HOST,
                    "use" => "xiwizard_windowsserver_host",
                    "host_name" => $hostname,
                    'icon_image' => 'hyperv.png',
                    "address" => $address,
                    "_xiwizard" => $wizard_name,
                    "_ncpa_token" => $token,
                    "_ncpa_port" => $port
                );
            } else {
                /* Just add free variables */
                $objs[] = array(
                    "type" => OBJECTTYPE_HOST,
                    "host_name" => $hostname,
                    "_ncpa_token" => $token,
                    "_ncpa_port" => $port
                );
            }

            foreach ($serviceargs as $section) {

                foreach ($section as $new_check_arguments) {

                    if (!isset($new_check_arguments['on']) || !$new_check_arguments['on']) {
                        continue;
                    }

                    $warning = escapeshellarg($new_check_arguments['warning']);
                    if (empty($new_check_arguments['warning'])) {
                        $warning = '0:';
                    }

                    $critical = escapeshellarg($new_check_arguments['critical']);
                    if (empty($new_check_arguments['critical'])) {
                        $critical = '0:';
                    }

                    $service_description = "{$new_check_arguments['object']}({$new_check_arguments['instance']})\\{$new_check_arguments['counter']}";

                    $endpoint = "windowscounters/";
                    $endpoint .= $new_check_arguments['object'];
                    if ($new_check_arguments['instance']) {
                        $endpoint .= "({$new_check_arguments['instance']})";
                    }
                    $endpoint .= "/{$new_check_arguments['counter']}";
                    $endpoint = escapeshellarg($endpoint);

                    $queryargs = array();
                    if (isset($new_check_arguments['sleepy'])) {
                        $queryargs[] = 'sleep=1';
                    }

                    if (isset($new_check_arguments['factor'])) {
                        $queryargs[] = 'factor=' . intval($new_check_arguments['factor']);
                    }

                    if (!empty($queryargs)) {
                        $queryargs = " -q " . escapeshellarg(implode(',', $queryargs));
                        $endpoint .= $queryargs;
                    }

                    $full_check_command = "check_xi_hyperv!$endpoint!$warning!$critical";

                    $objs[] = array(
                        'type'                  => OBJECTTYPE_SERVICE,
                        'host_name'             => $hostname,
                        'service_description'   => $service_description,
                        'icon_image'            => 'hyperv.png',
                        'check_command'         => $full_check_command,
                        '_xiwizard'             => $wizard_name,
                    );
                }
            }
            
            /* Return the object definitions to the wizard */
            $outargs[CONFIGWIZARD_NAGIOS_OBJECTS] = $objs;
            
            /* clear the session variables for this wizard run */
            unset($_SESSION[$wizard_name]); 
            
            /* The next line ends CONFIGWIZARD_MODE_GETOBJECTS */
            break;
            
        default:
            break;          
    };        
    return $output;
}

function hyperv_ncpa_installed_check($url, &$cmd) {
    $url = escapeshellarg($url);
    $cmd = "curl " . $url . " -g -f -k --connect-timeout 10";

    $ret = 0;
    exec($cmd, $data, $ret);
    $data = implode("", $data);

    if ($ret) {
        return 1; // cURL-specific error
    }

    $data = json_decode($data, true);

    if (!$data) {
        return 2; // Not JSON data
    }

    if(!array_key_exists('windowscounters', $data)) {
        return 3; // Not the correct json data
    }

    $found_it = 0; // If this isn't changed, then the output is probably correct
    foreach($data['windowscounters'] as $datum) {
        if (strpos($datum, "Error") !== false) {
            $found_it = 4; // NCPA couldn't access the counter, probably because it didn't exist (Hyper-V not installed).
            break;
        }
    }

    return $found_it;
}

function hyperv_build_form_element($element_id, $data_array, $section) {

    $instance_display = '(<input type="text" class="textfield form-control condensed instance-name" name="serviceargs[' . $section . '][' . $element_id . '][instance]" value="'. $data_array['instance'] .'">)';
    if ($data_array['instance'] === '<no instances>') {
        $instance_display = '<input type="hidden" name="serviceargs[' . $section . '][' . $element_id . '][instance] value="' . $data_array['instance'] . '">';
    }

    $sleepy_display = '';

    if (isset($data_array['sleepy'])) {
        $sleepy_display = '<input type="hidden" id="' . $section . '-' . $element_id . '-sleepy" name="serviceargs[' . $section . '][' . $element_id . '][sleepy] value="true">';
    }

    $factor_form_element = '<input type="text" id="' . $section . '-' . $element_id .'-factor" class="form-control condensed" size="2" value="'. $data_array['factor'] .'" name="serviceargs[' . $section .'][' . $element_id . '][factor]">';

    $ret = '<tr>
        <td style="vertical-align: top;">
            <input type="checkbox" id="' . $section . '-' . $element_id .'-onoff" class="form-control condensed enable-windows-perf-counter" name="serviceargs[' . $section . '][' . $element_id . '][on]" ' . is_checked($data_array['on']) . '>
        </td>
        <td>
            <label>'. $data_array['object'] . $instance_display . '\\' . $data_array['counter'] . '</label>
            <p>' . $data_array['description'] . '</p>
            <span class="instance-status" data-sa-index="' . $element_id . '" data-sa-section="' . $section . '">'. _("To verify the instance name, finish editing it or check the checkbox.").'</span>
            <div class="pad-t5">
                '. sprintf(_('Multiply result by 10^%s'), $factor_form_element) . '
            </div>
            <div class="pad-t5">
                <label><img src="' . theme_image('error.png') . '" class="tt-bind" title="' . _('Warning Threshold') . '"></label> <input type="text" size="4" name="serviceargs[' . $section . '][' . $element_id . '][warning]" value="' . encode_form_val($data_array['warning']) . '" class="textfield form-control condensed"> &nbsp; <label><img src="' . theme_image('critical_small.png') . '" class="tt-bind" title="' . _('Critical Threshold') . '"></label> <input type="text" size="4" name="serviceargs[' . $section . '][' . $element_id . '][critical]" value="' . encode_form_val($data_array['critical']) . '" class="textfield form-control condensed">
            </div>
            <div>
                <a class="hyperv-new-counter">+ ' ._("Monitor another instance with this counter") . '</a>
            </div>
        </td>
        <input type="hidden" id="' . $section . '-' . $element_id .'-object" value="'. $data_array['object'] .'" name="serviceargs[' . $section . ']['. $element_id . '][object]">
        <input type="hidden" id="' . $section . '-' . $element_id .'-counter" value="'. $data_array['counter'] .'" name="serviceargs[' . $section . ']['. $element_id .'][counter]"> 
        <input type="hidden" id="' . $section . '-' . $element_id .'-description" value="'.$data_array['description'] .'" name="serviceargs[' . $section .'][' . $element_id . '][description]">
        ' . $sleepy_display . '
    </tr>';

    return $ret;
}
?>
