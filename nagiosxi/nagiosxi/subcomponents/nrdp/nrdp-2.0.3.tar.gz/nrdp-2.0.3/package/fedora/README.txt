This is a package source for Fedora and EPEL (RedHat/CentOS), the configuration files
included should work out of the box with Nagios provided in Fedora/EPEL.
