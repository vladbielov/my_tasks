# Nagios XI Map Component

This component allows users to view hosts and services - along with their corresponding statuses - in an interactive map.

In order for this component to work properly, the user must specify geographic coordinates in the form of longitude and latidude. This must be specified in the 'Notes' section of the host/service objects.

### Coordinate Syntax

Coordinates may be specified using one of two syntaxes:

If the user has no other contents in the 'Notes' field, they may simply specify the coordinates in the following manner:

`latitude, longitude`

If the user has other notes along side the coordinates, they must wrap the coordinates in parenthesis in order for the parser to properly read them:

`Some example notes along side the coordinates (latitude, longitude)`