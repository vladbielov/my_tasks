#!/bin/sh


BASEDIR=$(dirname $(readlink -f $0))
cd $BASEDIR

. $BASEDIR/../../../../var/xi-sys.cfg

chmod 775 $proddir/html/sounds/ -R 
$chownbin $apacheuser:$nagiosgroup $proddir/html/sounds/ -R
